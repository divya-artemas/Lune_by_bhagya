# WordPress MySQL database migration
#
# Generated: Thursday 14. November 2024 14:01 UTC
# Hostname: localhost
# Database: `luneby2024`
# URL: //localhost/luna/site
# Path: \\\\
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wfblockediplog, wp_wfblocks7, wp_wfconfig, wp_wfcrawlers, wp_wffilechanges, wp_wffilemods, wp_wfhits, wp_wfhoover, wp_wfissues, wp_wfknownfilelist, wp_wflivetraffichuman, wp_wflocs, wp_wflogins, wp_wfls_2fa_secrets, wp_wfls_role_counts, wp_wfls_settings, wp_wfnotifications, wp_wfpendingissues, wp_wfreversecache, wp_wfsnipcache, wp_wfstatus, wp_wftrafficrates, wp_wfwaffailures, wp_wpfm_backup, wp_yoast_indexable, wp_yoast_indexable_hierarchy, wp_yoast_migrations, wp_yoast_primary_term, wp_yoast_seo_links
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, blogs, customize_changeset, nav_menu_item, outfit, page, post, wpcf7_contact_form
# Protocol: https
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-10-18 07:11:46', '2024-10-18 07:11:46', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=2005 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'cron', 'a:17:{i:1731593512;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1731593689;a:1:{s:21:"wordfence_ls_ntp_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1731593798;a:1:{s:21:"wordfence_hourly_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1731611538;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1731615090;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1731616890;a:1:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1731618691;a:1:{s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1731654710;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1731654737;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1731654812;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1731654998;a:1:{s:20:"wordfence_daily_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1731655280;a:1:{s:13:"wpseo-reindex";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1731655284;a:1:{s:31:"wpseo_permalink_structure_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1731741110;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1731945600;a:1:{s:31:"wordfence_email_activity_report";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1732183242;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'on'),
(2, 'siteurl', 'https://localhost/luna/site', 'on'),
(3, 'home', 'https://localhost/luna/site', 'on'),
(4, 'blogname', 'Lune by Bhagya', 'on'),
(5, 'blogdescription', 'We see personal style as more than mere clothing—it&#039;s a language of its own, a silent yet powerful expression of who you are and how you move through the world.', 'on'),
(6, 'users_can_register', '0', 'on'),
(7, 'admin_email', 'deepsonart@gmail.com', 'on'),
(8, 'start_of_week', '1', 'on'),
(9, 'use_balanceTags', '0', 'on'),
(10, 'use_smilies', '1', 'on'),
(11, 'require_name_email', '1', 'on'),
(12, 'comments_notify', '1', 'on'),
(13, 'posts_per_rss', '10', 'on'),
(14, 'rss_use_excerpt', '0', 'on'),
(15, 'mailserver_url', 'mail.example.com', 'on'),
(16, 'mailserver_login', 'login@example.com', 'on'),
(17, 'mailserver_pass', 'password', 'on'),
(18, 'mailserver_port', '110', 'on'),
(19, 'default_category', '1', 'on'),
(20, 'default_comment_status', 'open', 'on'),
(21, 'default_ping_status', 'open', 'on'),
(22, 'default_pingback_flag', '0', 'on'),
(23, 'posts_per_page', '10', 'on'),
(24, 'date_format', 'F j, Y', 'on'),
(25, 'time_format', 'g:i a', 'on'),
(26, 'links_updated_date_format', 'F j, Y g:i a', 'on'),
(27, 'comment_moderation', '0', 'on'),
(28, 'moderation_notify', '1', 'on'),
(29, 'permalink_structure', '/%postname%/', 'on'),
(30, 'rewrite_rules', 'a:141:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:39:"index.php?yoast-sitemap-xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:8:"blogs/?$";s:25:"index.php?post_type=blogs";s:38:"blogs/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=blogs&feed=$matches[1]";s:33:"blogs/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=blogs&feed=$matches[1]";s:25:"blogs/page/([0-9]{1,})/?$";s:43:"index.php?post_type=blogs&paged=$matches[1]";s:9:"outfit/?$";s:26:"index.php?post_type=outfit";s:39:"outfit/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?post_type=outfit&feed=$matches[1]";s:34:"outfit/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?post_type=outfit&feed=$matches[1]";s:26:"outfit/page/([0-9]{1,})/?$";s:44:"index.php?post_type=outfit&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:33:"blogs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"blogs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"blogs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"blogs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"blogs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"blogs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"blogs/([^/]+)/embed/?$";s:38:"index.php?blogs=$matches[1]&embed=true";s:26:"blogs/([^/]+)/trackback/?$";s:32:"index.php?blogs=$matches[1]&tb=1";s:46:"blogs/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?blogs=$matches[1]&feed=$matches[2]";s:41:"blogs/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?blogs=$matches[1]&feed=$matches[2]";s:34:"blogs/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?blogs=$matches[1]&paged=$matches[2]";s:41:"blogs/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?blogs=$matches[1]&cpage=$matches[2]";s:30:"blogs/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?blogs=$matches[1]&page=$matches[2]";s:22:"blogs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"blogs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"blogs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"blogs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"blogs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"blogs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"outfit/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"outfit/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"outfit/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"outfit/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"outfit/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"outfit/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"outfit/([^/]+)/embed/?$";s:39:"index.php?outfit=$matches[1]&embed=true";s:27:"outfit/([^/]+)/trackback/?$";s:33:"index.php?outfit=$matches[1]&tb=1";s:47:"outfit/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?outfit=$matches[1]&feed=$matches[2]";s:42:"outfit/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?outfit=$matches[1]&feed=$matches[2]";s:35:"outfit/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?outfit=$matches[1]&paged=$matches[2]";s:42:"outfit/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?outfit=$matches[1]&cpage=$matches[2]";s:31:"outfit/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?outfit=$matches[1]&page=$matches[2]";s:23:"outfit/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"outfit/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"outfit/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"outfit/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"outfit/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:29:"outfit/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'on'),
(31, 'hack_file', '0', 'on'),
(32, 'blog_charset', 'UTF-8', 'on'),
(33, 'moderation_keys', '', 'off'),
(34, 'active_plugins', 'a:8:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:33:"classic-editor/classic-editor.php";i:2;s:36:"contact-form-7/wp-contact-form-7.php";i:3;s:38:"post-duplicator/m4c-postduplicator.php";i:4;s:23:"wordfence/wordfence.php";i:5;s:24:"wordpress-seo/wp-seo.php";i:6;s:39:"wp-file-manager/file_folder_manager.php";i:7;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'on'),
(35, 'category_base', '', 'on'),
(36, 'ping_sites', 'http://rpc.pingomatic.com/', 'on'),
(37, 'comment_max_links', '2', 'on'),
(38, 'gmt_offset', '0', 'on'),
(39, 'default_email_category', '1', 'on'),
(40, 'recently_edited', 'a:5:{i:0;s:41:"\\\\/wp-content/themes/luna/css/default.css";i:1;s:35:"\\\\/wp-content/themes/luna/style.css";i:2;s:45:"\\\\/wp-content/themes/luna/template-outfit.php";i:3;s:46:"\\\\/wp-content/themes/luna/template-styling.php";i:4;s:43:"\\\\/wp-content/themes/luna/single-outfit.php";}', 'off'),
(41, 'template', 'luna', 'on'),
(42, 'stylesheet', 'luna', 'on'),
(43, 'comment_registration', '0', 'on'),
(44, 'html_type', 'text/html', 'on'),
(45, 'use_trackback', '0', 'on'),
(46, 'default_role', 'subscriber', 'on'),
(47, 'db_version', '58975', 'on'),
(48, 'uploads_use_yearmonth_folders', '1', 'on'),
(49, 'upload_path', '', 'on'),
(50, 'blog_public', '0', 'on'),
(51, 'default_link_category', '2', 'on'),
(52, 'show_on_front', 'page', 'on'),
(53, 'tag_base', '', 'on'),
(54, 'show_avatars', '1', 'on'),
(55, 'avatar_rating', 'G', 'on'),
(56, 'upload_url_path', '', 'on'),
(57, 'thumbnail_size_w', '150', 'on'),
(58, 'thumbnail_size_h', '150', 'on'),
(59, 'thumbnail_crop', '1', 'on'),
(60, 'medium_size_w', '300', 'on'),
(61, 'medium_size_h', '300', 'on'),
(62, 'avatar_default', 'mystery', 'on'),
(63, 'large_size_w', '1024', 'on'),
(64, 'large_size_h', '1024', 'on'),
(65, 'image_default_link_type', 'none', 'on'),
(66, 'image_default_size', '', 'on'),
(67, 'image_default_align', '', 'on'),
(68, 'close_comments_for_old_posts', '0', 'on'),
(69, 'close_comments_days_old', '14', 'on'),
(70, 'thread_comments', '1', 'on'),
(71, 'thread_comments_depth', '5', 'on'),
(72, 'page_comments', '0', 'on'),
(73, 'comments_per_page', '50', 'on'),
(74, 'default_comments_page', 'newest', 'on'),
(75, 'comment_order', 'asc', 'on'),
(76, 'sticky_posts', 'a:0:{}', 'on'),
(77, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(78, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(79, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(80, 'uninstall_plugins', 'a:1:{s:24:"wordpress-seo/wp-seo.php";s:14:"__return_false";}', 'off'),
(81, 'timezone_string', '', 'on'),
(82, 'page_for_posts', '2', 'on'),
(83, 'page_on_front', '6', 'on'),
(84, 'default_post_format', '0', 'on'),
(85, 'link_manager_enabled', '0', 'on'),
(86, 'finished_splitting_shared_terms', '1', 'on'),
(87, 'site_icon', '214', 'on'),
(88, 'medium_large_size_w', '768', 'on'),
(89, 'medium_large_size_h', '0', 'on'),
(90, 'wp_page_for_privacy_policy', '3', 'on'),
(91, 'show_comments_cookies_opt_in', '1', 'on'),
(92, 'admin_email_lifespan', '1744787491', 'on'),
(93, 'disallowed_keys', '', 'off'),
(94, 'comment_previously_approved', '1', 'on'),
(95, 'auto_plugin_theme_update_emails', 'a:0:{}', 'off'),
(96, 'auto_update_core_dev', 'enabled', 'on'),
(97, 'auto_update_core_minor', 'enabled', 'on'),
(98, 'auto_update_core_major', 'enabled', 'on'),
(99, 'wp_force_deactivated_plugins', 'a:0:{}', 'off'),
(100, 'wp_attachment_pages_enabled', '0', 'on') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'initial_db_version', '57155', 'on'),
(102, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:38:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;s:23:"view_site_health_checks";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}}', 'auto'),
(103, 'fresh_site', '0', 'off'),
(104, 'user_count', '1', 'off'),
(105, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'auto'),
(106, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'auto'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(124, 'recovery_keys', 'a:0:{}', 'off'),
(134, 'finished_updating_comment_type', '1', 'auto'),
(146, 'theme_mods_twentytwentyfour', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1729235626;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'off'),
(147, 'current_theme', 'Luna', 'auto'),
(148, 'theme_mods_luna', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:3:{s:6:"header";i:2;s:6:"footer";i:3;s:9:"top_right";i:4;}s:18:"custom_css_post_id";i:-1;}', 'on'),
(149, 'theme_switched', '', 'auto'),
(153, 'recently_activated', 'a:0:{}', 'off'),
(154, 'wpcf7', 'a:2:{s:7:"version";s:5:"5.7.7";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1729235652;s:7:"version";s:5:"5.7.7";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'auto'),
(164, 'yoast_migrations_free', 'a:1:{s:7:"version";s:6:"19.7.1";}', 'auto'),
(165, 'wordfence_ls_version', '1.1.2', 'auto'),
(166, 'wfls_last_role_change', '1729235680', 'off'),
(167, 'wordfence_version', '7.9.3', 'auto'),
(168, 'wordfence_case', '1', 'auto'),
(169, 'wordfence_installed', '1', 'auto'),
(171, 'wpseo', 'a:96:{s:8:"tracking";b:0;s:22:"license_server_version";b:0;s:15:"ms_defaults_set";b:0;s:40:"ignore_search_engines_discouraged_notice";b:0;s:19:"indexing_first_time";b:1;s:16:"indexing_started";b:0;s:15:"indexing_reason";s:23:"home_url_option_changed";s:29:"indexables_indexing_completed";b:1;s:13:"index_now_key";s:0:"";s:7:"version";s:6:"19.7.1";s:16:"previous_version";s:0:"";s:20:"disableadvanced_meta";b:1;s:30:"enable_headless_rest_endpoints";b:1;s:17:"ryte_indexability";b:0;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:34:"inclusive_language_analysis_active";b:0;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:16:"enable_index_now";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1729235798;s:13:"myyoast-oauth";b:0;s:26:"semrush_integration_active";b:1;s:14:"semrush_tokens";a:0:{}s:20:"semrush_country_code";s:2:"us";s:19:"permalink_structure";s:12:"/%postname%/";s:8:"home_url";s:27:"https://localhost/luna/site";s:18:"dynamic_permalinks";b:0;s:17:"category_base_url";s:0:"";s:12:"tag_base_url";s:0:"";s:21:"custom_taxonomy_slugs";a:0:{}s:29:"enable_enhanced_slack_sharing";b:1;s:25:"zapier_integration_active";b:0;s:19:"zapier_subscription";a:0:{}s:14:"zapier_api_key";s:0:"";s:23:"enable_metabox_insights";b:1;s:23:"enable_link_suggestions";b:1;s:26:"algolia_integration_active";b:0;s:14:"import_cursors";a:0:{}s:13:"workouts_data";a:1:{s:13:"configuration";a:1:{s:13:"finishedSteps";a:0:{}}}s:28:"configuration_finished_steps";a:0:{}s:36:"dismiss_configuration_workout_notice";b:0;s:34:"dismiss_premium_deactivated_notice";b:0;s:19:"importing_completed";a:0:{}s:26:"wincher_integration_active";b:1;s:14:"wincher_tokens";a:0:{}s:36:"wincher_automatically_add_keyphrases";b:0;s:18:"wincher_website_id";s:0:"";s:28:"wordproof_integration_active";b:0;s:29:"wordproof_integration_changed";b:0;s:18:"first_time_install";b:1;s:34:"should_redirect_after_install_free";b:0;s:34:"activation_redirect_timestamp_free";i:1729235810;s:18:"remove_feed_global";b:0;s:27:"remove_feed_global_comments";b:0;s:25:"remove_feed_post_comments";b:0;s:19:"remove_feed_authors";b:0;s:22:"remove_feed_categories";b:0;s:16:"remove_feed_tags";b:0;s:29:"remove_feed_custom_taxonomies";b:0;s:22:"remove_feed_post_types";b:0;s:18:"remove_feed_search";b:0;s:21:"remove_atom_rdf_feeds";b:0;s:17:"remove_shortlinks";b:0;s:21:"remove_rest_api_links";b:0;s:20:"remove_rsd_wlw_links";b:0;s:19:"remove_oembed_links";b:0;s:16:"remove_generator";b:0;s:20:"remove_emoji_scripts";b:0;s:24:"remove_powered_by_header";b:0;s:22:"remove_pingback_header";b:0;s:28:"clean_campaign_tracking_urls";b:0;s:16:"clean_permalinks";b:0;s:32:"clean_permalinks_extra_variables";s:0:"";s:14:"search_cleanup";b:0;s:20:"search_cleanup_emoji";b:0;s:23:"search_cleanup_patterns";b:0;s:22:"search_character_limit";i:50;s:20:"deny_search_crawling";b:0;s:21:"deny_wp_json_crawling";b:0;s:29:"least_readability_ignore_list";a:0:{}s:27:"least_seo_score_ignore_list";a:0:{}s:23:"most_linked_ignore_list";a:0:{}s:24:"least_linked_ignore_list";a:0:{}s:28:"indexables_page_reading_list";a:5:{i:0;b:0;i:1;b:0;i:2;b:0;i:3;b:0;i:4;b:0;}s:25:"indexables_overview_state";s:21:"dashboard-not-visited";}', 'auto'),
(172, 'wpseo_titles', 'a:191:{s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:25:"social-title-author-wpseo";s:8:"%%name%%";s:26:"social-title-archive-wpseo";s:8:"%%date%%";s:31:"social-description-author-wpseo";s:0:"";s:32:"social-description-archive-wpseo";s:0:"";s:29:"social-image-url-author-wpseo";s:0:"";s:30:"social-image-url-archive-wpseo";s:0:"";s:28:"social-image-id-author-wpseo";i:0;s:29:"social-image-id-archive-wpseo";i:0;s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:11:"person_logo";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:7:"company";s:25:"company_or_person_user_id";b:0;s:17:"stripcategorybase";b:0;s:26:"open_graph_frontpage_title";s:12:"%%sitename%%";s:25:"open_graph_frontpage_desc";s:0:"";s:26:"open_graph_frontpage_image";s:0:"";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:23:"display-metabox-pt-post";b:1;s:23:"post_types-post-maintax";i:0;s:21:"schema-page-type-post";s:7:"WebPage";s:24:"schema-article-type-post";s:7:"Article";s:17:"social-title-post";s:9:"%%title%%";s:23:"social-description-post";s:0:"";s:21:"social-image-url-post";s:0:"";s:20:"social-image-id-post";i:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:23:"display-metabox-pt-page";b:1;s:23:"post_types-page-maintax";i:0;s:21:"schema-page-type-page";s:7:"WebPage";s:24:"schema-article-type-page";s:4:"None";s:17:"social-title-page";s:9:"%%title%%";s:23:"social-description-page";s:0:"";s:21:"social-image-url-page";s:0:"";s:20:"social-image-id-page";i:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:29:"post_types-attachment-maintax";i:0;s:27:"schema-page-type-attachment";s:7:"WebPage";s:30:"schema-article-type-attachment";s:4:"None";s:11:"title-blogs";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:14:"metadesc-blogs";s:0:"";s:13:"noindex-blogs";b:0;s:24:"display-metabox-pt-blogs";b:1;s:24:"post_types-blogs-maintax";i:0;s:22:"schema-page-type-blogs";s:7:"WebPage";s:25:"schema-article-type-blogs";s:4:"None";s:18:"social-title-blogs";s:9:"%%title%%";s:24:"social-description-blogs";s:0:"";s:22:"social-image-url-blogs";s:0:"";s:21:"social-image-id-blogs";i:0;s:21:"title-ptarchive-blogs";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:24:"metadesc-ptarchive-blogs";s:0:"";s:23:"bctitle-ptarchive-blogs";s:0:"";s:23:"noindex-ptarchive-blogs";b:0;s:28:"social-title-ptarchive-blogs";s:21:"%%pt_plural%% Archive";s:34:"social-description-ptarchive-blogs";s:0:"";s:32:"social-image-url-ptarchive-blogs";s:0:"";s:31:"social-image-id-ptarchive-blogs";i:0;s:14:"title-services";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:17:"metadesc-services";s:0:"";s:16:"noindex-services";b:0;s:27:"display-metabox-pt-services";b:1;s:27:"post_types-services-maintax";i:0;s:25:"schema-page-type-services";s:7:"WebPage";s:28:"schema-article-type-services";s:4:"None";s:21:"social-title-services";s:9:"%%title%%";s:27:"social-description-services";s:0:"";s:25:"social-image-url-services";s:0:"";s:24:"social-image-id-services";i:0;s:24:"title-ptarchive-services";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:27:"metadesc-ptarchive-services";s:0:"";s:26:"bctitle-ptarchive-services";s:0:"";s:26:"noindex-ptarchive-services";b:0;s:31:"social-title-ptarchive-services";s:21:"%%pt_plural%% Archive";s:37:"social-description-ptarchive-services";s:0:"";s:35:"social-image-url-ptarchive-services";s:0:"";s:34:"social-image-id-ptarchive-services";i:0;s:11:"title-press";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:14:"metadesc-press";s:0:"";s:13:"noindex-press";b:0;s:24:"display-metabox-pt-press";b:1;s:24:"post_types-press-maintax";i:0;s:22:"schema-page-type-press";s:7:"WebPage";s:25:"schema-article-type-press";s:4:"None";s:18:"social-title-press";s:9:"%%title%%";s:24:"social-description-press";s:0:"";s:22:"social-image-url-press";s:0:"";s:21:"social-image-id-press";i:0;s:21:"title-ptarchive-press";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:24:"metadesc-ptarchive-press";s:0:"";s:23:"bctitle-ptarchive-press";s:0:"";s:23:"noindex-ptarchive-press";b:0;s:28:"social-title-ptarchive-press";s:21:"%%pt_plural%% Archive";s:34:"social-description-ptarchive-press";s:0:"";s:32:"social-image-url-ptarchive-press";s:0:"";s:31:"social-image-id-ptarchive-press";i:0;s:16:"title-newsletter";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-newsletter";s:0:"";s:18:"noindex-newsletter";b:0;s:29:"display-metabox-pt-newsletter";b:1;s:29:"post_types-newsletter-maintax";i:0;s:27:"schema-page-type-newsletter";s:7:"WebPage";s:30:"schema-article-type-newsletter";s:4:"None";s:23:"social-title-newsletter";s:9:"%%title%%";s:29:"social-description-newsletter";s:0:"";s:27:"social-image-url-newsletter";s:0:"";s:26:"social-image-id-newsletter";i:0;s:26:"title-ptarchive-newsletter";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:29:"metadesc-ptarchive-newsletter";s:0:"";s:28:"bctitle-ptarchive-newsletter";s:0:"";s:28:"noindex-ptarchive-newsletter";b:0;s:33:"social-title-ptarchive-newsletter";s:21:"%%pt_plural%% Archive";s:39:"social-description-ptarchive-newsletter";s:0:"";s:37:"social-image-url-ptarchive-newsletter";s:0:"";s:36:"social-image-id-ptarchive-newsletter";i:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:25:"social-title-tax-category";s:23:"%%term_title%% Archives";s:31:"social-description-tax-category";s:0:"";s:29:"social-image-url-tax-category";s:0:"";s:28:"social-image-id-tax-category";i:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:25:"social-title-tax-post_tag";s:23:"%%term_title%% Archives";s:31:"social-description-tax-post_tag";s:0:"";s:29:"social-image-url-tax-post_tag";s:0:"";s:28:"social-image-id-tax-post_tag";i:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;s:28:"social-title-tax-post_format";s:23:"%%term_title%% Archives";s:34:"social-description-tax-post_format";s:0:"";s:32:"social-image-url-tax-post_format";s:0:"";s:31:"social-image-id-tax-post_format";i:0;s:28:"title-tax-service_categories";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:31:"metadesc-tax-service_categories";s:0:"";s:38:"display-metabox-tax-service_categories";b:1;s:30:"noindex-tax-service_categories";b:0;s:35:"social-title-tax-service_categories";s:23:"%%term_title%% Archives";s:41:"social-description-tax-service_categories";s:0:"";s:39:"social-image-url-tax-service_categories";s:0:"";s:38:"social-image-id-tax-service_categories";i:0;s:36:"taxonomy-service_categories-ptparent";i:0;s:14:"person_logo_id";i:0;s:15:"company_logo_id";i:0;s:17:"company_logo_meta";b:0;s:16:"person_logo_meta";b:0;s:29:"open_graph_frontpage_image_id";i:0;}', 'auto'),
(173, 'wpseo_social', 'a:19:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:19:"og_default_image_id";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:21:"og_frontpage_image_id";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:13:"wikipedia_url";s:0:"";s:17:"other_social_urls";a:0:{}}', 'auto'),
(191, 'wordfenceActivated', '1', 'auto'),
(192, 'wf_plugin_act_error', '', 'auto'),
(199, 'acf_version', '5.9.5', 'auto'),
(200, 'mtphr_post_duplicator_settings', '', 'auto'),
(274, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:21:"HTTPS request failed.";}}', 'off'),
(350, 'recovery_mode_email_last_sent', '1729659803', 'auto'),
(351, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'off'),
(455, 'options_site_logo', '58', 'off'),
(456, '_options_site_logo', 'field_67193cb4507f0', 'off'),
(508, 'secret_key', 'MlO.hi;y~]<CZlWalOiG?IL;*6.NkI@=TrT2m7jnn UArR[~DDC%9M?Nn03j{H``', 'off'),
(517, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1731592908;}', 'off'),
(1165, 'options_', '', 'off'),
(1166, '_options_', 'field_671b554520a77', 'off'),
(1167, 'options_ft_scrolling_text', '8', 'off'),
(1168, '_options_ft_scrolling_text', 'field_671b61a437385', 'off'),
(1169, 'options_ft_scrolling_text_0_fs_text', 'Virtual Personal Styling', 'off'),
(1170, '_options_ft_scrolling_text_0_fs_text', 'field_671b61cc37386', 'off'),
(1171, 'options_ft_scrolling_text_1_fs_text', 'Sessions Wardrobe Audit', 'off'),
(1172, '_options_ft_scrolling_text_1_fs_text', 'field_671b61cc37386', 'off'),
(1173, 'options_ft_scrolling_text_2_fs_text', 'Styling Consultations Long-Term', 'off'),
(1174, '_options_ft_scrolling_text_2_fs_text', 'field_671b61cc37386', 'off'),
(1175, 'options_ft_scrolling_text_3_fs_text', 'Styling Packages editorial styling services', 'off'),
(1176, '_options_ft_scrolling_text_3_fs_text', 'field_671b61cc37386', 'off'),
(1189, 'options_ft_scrolling_text_4_fs_text', 'Virtual Personal Styling', 'off'),
(1190, '_options_ft_scrolling_text_4_fs_text', 'field_671b61cc37386', 'off'),
(1191, 'options_ft_scrolling_text_5_fs_text', 'Sessions Wardrobe Audit', 'off'),
(1192, '_options_ft_scrolling_text_5_fs_text', 'field_671b61cc37386', 'off'),
(1193, 'options_ft_scrolling_text_6_fs_text', 'Styling Consultations Long-Term', 'off'),
(1194, '_options_ft_scrolling_text_6_fs_text', 'field_671b61cc37386', 'off'),
(1195, 'options_ft_scrolling_text_7_fs_text', 'Styling Packages editorial styling services', 'off'),
(1196, '_options_ft_scrolling_text_7_fs_text', 'field_671b61cc37386', 'off'),
(1213, 'options_ft_contact_number', '+91 95677 87207', 'off'),
(1214, '_options_ft_contact_number', 'field_671b673036083', 'off'),
(1215, 'options_ft_contact_icon', '<svg width="40" height="40" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<path d="M44 33.8402V39.8402C44.0022 40.3972 43.8882 40.9485 43.665 41.4589C43.4419 41.9692 43.1146 42.4274 42.7041 42.8039C42.2937 43.1805 41.8091 43.4672 41.2815 43.6456C40.7538 43.8241 40.1947 43.8903 39.64 43.8402C33.4857 43.1715 27.574 41.0685 22.38 37.7002C17.5476 34.6295 13.4507 30.5325 10.38 25.7002C6.99994 20.4826 4.89647 14.5422 4.23999 8.36019C4.19001 7.80713 4.25574 7.24971 4.43299 6.72344C4.61024 6.19717 4.89513 5.71357 5.26952 5.30344C5.64391 4.8933 6.0996 4.56561 6.60757 4.34124C7.11554 4.11686 7.66467 4.00072 8.21999 4.00019H14.22C15.1906 3.99064 16.1316 4.33435 16.8675 4.96726C17.6035 5.60017 18.0841 6.47909 18.22 7.44019C18.4732 9.36033 18.9429 11.2456 19.62 13.0602C19.8891 13.776 19.9473 14.554 19.7878 15.302C19.6283 16.0499 19.2577 16.7364 18.72 17.2802L16.18 19.8202C19.0271 24.8273 23.1729 28.9731 28.18 31.8202L30.72 29.2802C31.2638 28.7425 31.9503 28.3719 32.6982 28.2124C33.4462 28.0529 34.2241 28.1111 34.94 28.3802C36.7545 29.0573 38.6399 29.5269 40.56 29.7802C41.5315 29.9173 42.4188 30.4066 43.0531 31.1552C43.6873 31.9038 44.0243 32.8593 44 33.8402Z" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\r\n</svg>', 'off'),
(1216, '_options_ft_contact_icon', 'field_671b67ab04050', 'off'),
(1217, 'options_ft_email_id', 'pingme@lunebybhagya.com', 'off'),
(1218, '_options_ft_email_id', 'field_671b674236084', 'off'),
(1219, 'options_ft_email_icon', '<svg width="51" height="40" viewBox="0 0 51 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<circle cx="6" cy="10" r="6" fill="#C89898"/>\r\n<path d="M47 12C47 9.8 45.2 8 43 8H11C8.8 8 7 9.8 7 12M47 12V36C47 38.2 45.2 40 43 40H11C8.8 40 7 38.2 7 36V12M47 12L27 26L7 12" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\r\n</svg>', 'off'),
(1220, '_options_ft_email_icon', 'field_671b67bd04051', 'off'),
(1221, 'options_copyright_text', '<p>Copyright 2024  |  SITE BY <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<mask id="path-1-inside-1_10_594" fill="white">\r\n<path d="M12.1567 2.68926C11.8588 2.39117 11.505 2.15472 11.1157 1.99339C10.7263 1.83206 10.309 1.74902 9.88753 1.74902C9.46608 1.74902 9.04876 1.83206 8.6594 1.99339C8.27005 2.15472 7.9163 2.39117 7.61836 2.68926L7.00003 3.30759L6.3817 2.68926C5.77987 2.08743 4.96363 1.74934 4.11253 1.74934C3.26143 1.74934 2.44518 2.08743 1.84336 2.68926C1.24154 3.29108 0.903442 4.10732 0.903442 4.95842C0.903442 5.80952 1.24154 6.62577 1.84336 7.22759L7.00003 12.3843L12.1567 7.22759C12.4548 6.92965 12.6912 6.5759 12.8526 6.18655C13.0139 5.79719 13.0969 5.37987 13.0969 4.95842C13.0969 4.53697 13.0139 4.11965 12.8526 3.7303C12.6912 3.34095 12.4548 2.9872 12.1567 2.68926Z"/>\r\n</mask>\r\n<path d="M12.1567 2.68926L-11.8906 26.7252C-11.8868 26.729 -11.8831 26.7328 -11.8793 26.7365L12.1567 2.68926ZM9.88753 1.74902V35.749V1.74902ZM7.61836 2.68926L31.66 26.7309L31.6656 26.7252L7.61836 2.68926ZM7.00003 3.30759L-17.0416 27.3492C-3.76377 40.627 17.7638 40.627 31.0417 27.3492L7.00003 3.30759ZM6.3817 2.68926L-17.6599 26.7309L-17.6599 26.7309L6.3817 2.68926ZM1.84336 7.22759L-22.1983 31.2692V31.2692L1.84336 7.22759ZM7.00003 12.3843L-17.0416 36.4259C-10.6654 42.8021 -2.01733 46.3843 7.00003 46.3843C16.0174 46.3843 24.6654 42.8021 31.0417 36.4259L7.00003 12.3843ZM12.1567 7.22759L-11.8793 -16.8197L-11.8849 -16.814L12.1567 7.22759ZM36.204 -21.3467C32.7486 -24.8037 28.646 -27.546 24.1306 -29.417L-1.89927 33.4038C-5.63603 31.8554 -9.03112 29.586 -11.8906 26.7252L36.204 -21.3467ZM24.1306 -29.417C19.6151 -31.288 14.7753 -32.251 9.88753 -32.251V35.749C5.84268 35.749 1.83748 34.9521 -1.89927 33.4038L24.1306 -29.417ZM9.88753 -32.251C4.9998 -32.251 0.15995 -31.288 -4.35552 -29.417L21.6743 33.4038C17.9376 34.9521 13.9324 35.749 9.88753 35.749V-32.251ZM-4.35552 -29.417C-8.871 -27.546 -12.9736 -24.8037 -16.4289 -21.3467L31.6656 26.7252C28.8062 29.586 25.4111 31.8554 21.6743 33.4038L-4.35552 -29.417ZM-16.4233 -21.3524L-17.0416 -20.734L31.0417 27.3492L31.66 26.7309L-16.4233 -21.3524ZM31.0417 -20.734L30.4233 -21.3524L-17.6599 26.7309L-17.0416 27.3492L31.0417 -20.734ZM30.4233 -21.3524C23.4453 -28.3304 13.981 -32.2507 4.11253 -32.2507L4.11253 35.7493C-4.05373 35.7493 -11.8855 32.5053 -17.6599 26.7309L30.4233 -21.3524ZM4.11253 -32.2507C-5.75594 -32.2507 -15.2202 -28.3304 -22.1983 -21.3524L25.885 26.7309C20.1106 32.5053 12.2788 35.7493 4.11253 35.7493L4.11253 -32.2507ZM-22.1983 -21.3524C-29.1763 -14.3743 -33.0966 -4.91004 -33.0966 4.95842L34.9034 4.95842C34.9034 13.1247 31.6594 20.9565 25.885 26.7309L-22.1983 -21.3524ZM-33.0966 4.95842C-33.0966 14.8269 -29.1763 24.2912 -22.1983 31.2692L25.885 -16.814C31.6594 -11.0396 34.9034 -3.20783 34.9034 4.95842L-33.0966 4.95842ZM36.1927 31.2749C39.6497 27.8195 42.392 23.7169 44.2629 19.2015L-18.5578 -6.82838C-17.0095 -10.5651 -14.7401 -13.9602 -11.8793 -16.8197L36.1927 31.2749ZM44.2629 19.2015C46.1339 14.686 47.0969 9.8462 47.0969 4.95842H-20.9031C-20.9031 0.913544 -20.1061 -3.09166 -18.5578 -6.82838L44.2629 19.2015ZM47.0969 4.95842C47.0969 0.0706401 46.1339 -4.7692 44.2629 -9.28462L-18.5578 16.7452C-20.1061 13.0085 -20.9031 9.0033 -20.9031 4.95842H47.0969ZM44.2629 -9.28462C42.392 -13.8001 39.6497 -17.9027 36.1927 -21.358L-11.8793 26.7365C-14.7401 23.8771 -17.0095 20.482 -18.5578 16.7452L44.2629 -9.28462ZM-22.1983 31.2692L-17.0416 36.4259L31.0417 -11.6574L25.885 -16.814L-22.1983 31.2692ZM31.0417 36.4259L36.1983 31.2692L-11.8849 -16.814L-17.0416 -11.6574L31.0417 36.4259Z" fill="#D9E9CE" mask="url(#path-1-inside-1_10_594)"/>\r\n</svg><a href="https://movewith.digital/" target="_blank"> MWD</a> </p>', 'off'),
(1222, '_options_copyright_text', 'field_671b676536085', 'off'),
(1337, 'options_ot_button_title', '—Loved Our Collages? Dive into Our Styling Questionnaire', 'off'),
(1338, '_options_ot_button_title', 'field_671b890a88ea7', 'off'),
(1339, 'options_ot_button_text', 'Styling Questionnaire', 'off'),
(1340, '_options_ot_button_text', 'field_671b892188ea8', 'off'),
(1341, 'options_ot_button_link', 'a:3:{s:5:"title";s:21:"Styling Questionnaire";s:3:"url";s:50:"https://localhost/luna/site/styling-questionnaire/";s:6:"target";s:0:"";}', 'off'),
(1342, '_options_ot_button_link', 'field_671b892a88ea9', 'off'),
(1930, 'db_upgraded', '', 'on'),
(1936, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:20:"deepsonart@gmail.com";s:7:"version";s:3:"6.7";s:9:"timestamp";i:1731578465;}', 'off'),
(1982, 'can_compress_scripts', '1', 'on'),
(1991, 'fm_key', 'CwAPxHrBXazJqybcls01KDvWg', 'auto'),
(1994, 'filemanager_email_verified_1', 'yes', 'auto') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1853 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_form', '<label> Your name\n    [text* your-name autocomplete:name] </label>\n\n<label> Your email\n    [email* your-email autocomplete:email] </label>\n\n<label> Subject\n    [text* your-subject] </label>\n\n<label> Your message (optional)\n    [textarea your-message] </label>\n\n[submit "Submit"]'),
(4, 5, '_mail', 'a:8:{s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:36:"[_site_title] <deepsonart@gmail.com>";s:4:"body";s:161:"From: [your-name] [your-email]\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])";s:9:"recipient";s:19:"[_site_admin_email]";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(5, 5, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:36:"[_site_title] <deepsonart@gmail.com>";s:4:"body";s:105:"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:29:"Reply-To: [_site_admin_email]";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(6, 5, '_messages', 'a:12:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:27:"Please fill out this field.";s:16:"invalid_too_long";s:32:"This field has a too long input.";s:17:"invalid_too_short";s:33:"This field has a too short input.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:31:"The uploaded file is too large.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";}'),
(7, 5, '_additional_settings', ''),
(8, 5, '_locale', 'en_US'),
(9, 6, '_edit_last', '1'),
(10, 6, '_edit_lock', '1730791592:1'),
(11, 6, '_wp_page_template', 'template-home.php'),
(12, 8, '_edit_last', '1'),
(13, 8, '_edit_lock', '1729835821:1'),
(14, 8, '_wp_page_template', 'template-about.php'),
(15, 10, '_edit_last', '1'),
(16, 10, '_edit_lock', '1730734526:1'),
(17, 10, '_wp_page_template', 'template-styling.php'),
(18, 10, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(19, 10, '_yoast_wpseo_wordproof_timestamp', ''),
(20, 15, '_menu_item_type', 'custom'),
(21, 15, '_menu_item_menu_item_parent', '0'),
(22, 15, '_menu_item_object_id', '15'),
(23, 15, '_menu_item_object', 'custom'),
(24, 15, '_menu_item_target', ''),
(25, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(26, 15, '_menu_item_xfn', ''),
(27, 15, '_menu_item_url', 'http://localhost/luna/site/'),
(28, 15, '_menu_item_orphaned', '1729658729'),
(29, 16, '_menu_item_type', 'post_type'),
(30, 16, '_menu_item_menu_item_parent', '0'),
(31, 16, '_menu_item_object_id', '8'),
(32, 16, '_menu_item_object', 'page'),
(33, 16, '_menu_item_target', ''),
(34, 16, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(35, 16, '_menu_item_xfn', ''),
(36, 16, '_menu_item_url', ''),
(37, 16, '_menu_item_orphaned', '1729658730'),
(38, 17, '_menu_item_type', 'post_type'),
(39, 17, '_menu_item_menu_item_parent', '0'),
(40, 17, '_menu_item_object_id', '10'),
(41, 17, '_menu_item_object', 'page'),
(42, 17, '_menu_item_target', ''),
(43, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(44, 17, '_menu_item_xfn', ''),
(45, 17, '_menu_item_url', ''),
(46, 17, '_menu_item_orphaned', '1729658730'),
(47, 18, '_edit_last', '1'),
(48, 18, '_wp_page_template', 'template-packages.php'),
(49, 18, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(50, 18, '_yoast_wpseo_wordproof_timestamp', ''),
(51, 18, '_edit_lock', '1730800158:1'),
(52, 20, '_edit_last', '1'),
(53, 20, '_edit_lock', '1730883861:1'),
(54, 20, '_wp_page_template', 'template-outfit.php'),
(55, 20, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(56, 20, '_yoast_wpseo_wordproof_timestamp', ''),
(57, 22, '_edit_last', '1'),
(58, 22, '_wp_page_template', 'template-faq.php'),
(59, 22, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(60, 22, '_yoast_wpseo_wordproof_timestamp', ''),
(61, 22, '_edit_lock', '1729841341:1'),
(62, 25, '_edit_last', '1'),
(63, 25, '_edit_lock', '1730883672:1'),
(64, 25, '_wp_page_template', 'template-contact.php'),
(65, 25, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(66, 25, '_yoast_wpseo_wordproof_timestamp', ''),
(67, 28, '_menu_item_type', 'custom'),
(68, 28, '_menu_item_menu_item_parent', '0'),
(69, 28, '_menu_item_object_id', '28'),
(70, 28, '_menu_item_object', 'custom'),
(71, 28, '_menu_item_target', ''),
(72, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(73, 28, '_menu_item_xfn', ''),
(74, 28, '_menu_item_url', 'http://localhost/luna/site/'),
(75, 28, '_menu_item_orphaned', '1729660196'),
(76, 29, '_menu_item_type', 'post_type'),
(77, 29, '_menu_item_menu_item_parent', '0'),
(78, 29, '_menu_item_object_id', '8'),
(79, 29, '_menu_item_object', 'page'),
(80, 29, '_menu_item_target', ''),
(81, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(82, 29, '_menu_item_xfn', ''),
(83, 29, '_menu_item_url', ''),
(85, 30, '_menu_item_type', 'post_type'),
(86, 30, '_menu_item_menu_item_parent', '0'),
(87, 30, '_menu_item_object_id', '25'),
(88, 30, '_menu_item_object', 'page'),
(89, 30, '_menu_item_target', ''),
(90, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(91, 30, '_menu_item_xfn', ''),
(92, 30, '_menu_item_url', ''),
(94, 31, '_menu_item_type', 'post_type'),
(95, 31, '_menu_item_menu_item_parent', '0'),
(96, 31, '_menu_item_object_id', '22'),
(97, 31, '_menu_item_object', 'page'),
(98, 31, '_menu_item_target', ''),
(99, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(100, 31, '_menu_item_xfn', ''),
(101, 31, '_menu_item_url', ''),
(103, 32, '_menu_item_type', 'post_type') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(104, 32, '_menu_item_menu_item_parent', '0'),
(105, 32, '_menu_item_object_id', '6'),
(106, 32, '_menu_item_object', 'page'),
(107, 32, '_menu_item_target', ''),
(108, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(109, 32, '_menu_item_xfn', ''),
(110, 32, '_menu_item_url', ''),
(112, 33, '_menu_item_type', 'post_type'),
(113, 33, '_menu_item_menu_item_parent', '0'),
(114, 33, '_menu_item_object_id', '20'),
(115, 33, '_menu_item_object', 'page'),
(116, 33, '_menu_item_target', ''),
(117, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(118, 33, '_menu_item_xfn', ''),
(119, 33, '_menu_item_url', ''),
(130, 35, '_menu_item_type', 'post_type'),
(131, 35, '_menu_item_menu_item_parent', '0'),
(132, 35, '_menu_item_object_id', '18'),
(133, 35, '_menu_item_object', 'page'),
(134, 35, '_menu_item_target', ''),
(135, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(136, 35, '_menu_item_xfn', ''),
(137, 35, '_menu_item_url', ''),
(139, 36, '_edit_last', '1'),
(140, 36, '_edit_lock', '1729778743:1'),
(141, 36, '_wp_page_template', 'template-blog.php'),
(142, 36, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(143, 36, '_yoast_wpseo_wordproof_timestamp', ''),
(144, 38, '_menu_item_type', 'custom'),
(145, 38, '_menu_item_menu_item_parent', '0'),
(146, 38, '_menu_item_object_id', '38'),
(147, 38, '_menu_item_object', 'custom'),
(148, 38, '_menu_item_target', ''),
(149, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(150, 38, '_menu_item_xfn', ''),
(151, 38, '_menu_item_url', 'http://localhost/luna/site/'),
(152, 38, '_menu_item_orphaned', '1729660774'),
(153, 39, '_menu_item_type', 'post_type'),
(154, 39, '_menu_item_menu_item_parent', '0'),
(155, 39, '_menu_item_object_id', '8'),
(156, 39, '_menu_item_object', 'page'),
(157, 39, '_menu_item_target', ''),
(158, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(159, 39, '_menu_item_xfn', ''),
(160, 39, '_menu_item_url', ''),
(162, 40, '_menu_item_type', 'post_type'),
(163, 40, '_menu_item_menu_item_parent', '0'),
(164, 40, '_menu_item_object_id', '36'),
(165, 40, '_menu_item_object', 'page'),
(166, 40, '_menu_item_target', ''),
(167, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(168, 40, '_menu_item_xfn', ''),
(169, 40, '_menu_item_url', ''),
(171, 41, '_menu_item_type', 'post_type'),
(172, 41, '_menu_item_menu_item_parent', '0'),
(173, 41, '_menu_item_object_id', '25'),
(174, 41, '_menu_item_object', 'page'),
(175, 41, '_menu_item_target', ''),
(176, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(177, 41, '_menu_item_xfn', ''),
(178, 41, '_menu_item_url', ''),
(180, 42, '_menu_item_type', 'post_type'),
(181, 42, '_menu_item_menu_item_parent', '0'),
(182, 42, '_menu_item_object_id', '22'),
(183, 42, '_menu_item_object', 'page'),
(184, 42, '_menu_item_target', ''),
(185, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(186, 42, '_menu_item_xfn', ''),
(187, 42, '_menu_item_url', ''),
(189, 43, '_menu_item_type', 'post_type'),
(190, 43, '_menu_item_menu_item_parent', '0'),
(191, 43, '_menu_item_object_id', '20'),
(192, 43, '_menu_item_object', 'page'),
(193, 43, '_menu_item_target', ''),
(194, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(195, 43, '_menu_item_xfn', ''),
(196, 43, '_menu_item_url', ''),
(198, 44, '_menu_item_type', 'post_type'),
(199, 44, '_menu_item_menu_item_parent', '0'),
(200, 44, '_menu_item_object_id', '10'),
(201, 44, '_menu_item_object', 'page'),
(202, 44, '_menu_item_target', ''),
(203, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(204, 44, '_menu_item_xfn', ''),
(205, 44, '_menu_item_url', ''),
(207, 45, '_menu_item_type', 'post_type'),
(208, 45, '_menu_item_menu_item_parent', '0'),
(209, 45, '_menu_item_object_id', '18'),
(210, 45, '_menu_item_object', 'page'),
(211, 45, '_menu_item_target', ''),
(212, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(213, 45, '_menu_item_xfn', ''),
(214, 45, '_menu_item_url', ''),
(216, 46, '_menu_item_type', 'post_type'),
(217, 46, '_menu_item_menu_item_parent', '0'),
(218, 46, '_menu_item_object_id', '6'),
(219, 46, '_menu_item_object', 'page'),
(220, 46, '_menu_item_target', ''),
(221, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(222, 46, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(223, 46, '_menu_item_url', ''),
(225, 47, '_menu_item_type', 'custom'),
(226, 47, '_menu_item_menu_item_parent', '0'),
(227, 47, '_menu_item_object_id', '47'),
(228, 47, '_menu_item_object', 'custom'),
(229, 47, '_menu_item_target', ''),
(230, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(231, 47, '_menu_item_xfn', ''),
(232, 47, '_menu_item_url', 'http://localhost/luna/site/styling-packages/'),
(234, 48, '_menu_item_type', 'custom'),
(235, 48, '_menu_item_menu_item_parent', '0'),
(236, 48, '_menu_item_object_id', '48'),
(237, 48, '_menu_item_object', 'custom'),
(238, 48, '_menu_item_target', ''),
(239, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(240, 48, '_menu_item_xfn', ''),
(241, 48, '_menu_item_url', 'http://localhost/luna/site/services/'),
(243, 49, '_edit_last', '1'),
(244, 49, '_edit_lock', '1729707005:1'),
(245, 6, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(246, 6, '_yoast_wpseo_wordproof_timestamp', ''),
(247, 58, '_wp_attached_file', '2024/10/text-logo.svg'),
(248, 58, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:134334;}'),
(249, 59, '_wp_attached_file', '2024/10/img-one.png'),
(250, 59, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:580;s:6:"height";i:720;s:4:"file";s:19:"2024/10/img-one.png";s:8:"filesize";i:826937;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:19:"img-one-242x300.png";s:5:"width";i:242;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:164891;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"img-one-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:55149;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(251, 6, 'banner_logo', '58'),
(252, 6, '_banner_logo', 'field_67188d83f2f1a'),
(253, 6, 'banner_text', 'Curated Styling Journeys'),
(254, 6, '_banner_text', 'field_67188e79f2f1b'),
(255, 6, 'banner_image', '59'),
(256, 6, '_banner_image', 'field_67188e8cf2f1c'),
(257, 6, 'banner_content', 'Personalized Styling experiences that weave together grace and practicality, ensuring you radiate confidence and beauty in every moment.'),
(258, 6, '_banner_content', 'field_67188eb9f2f1d'),
(259, 6, 'service_content', 'At Lune by Bhagya, we see personal style as more than mere clothing—it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.'),
(260, 6, '_service_content', 'field_67188ef9f2f1e'),
(261, 6, 'link_text', 'See Styling Services'),
(262, 6, '_link_text', 'field_67188f85f2f1f'),
(263, 6, 'link_url', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(264, 6, '_link_url', 'field_67188f94f2f20'),
(265, 7, 'banner_logo', '58'),
(266, 7, '_banner_logo', 'field_67188d83f2f1a'),
(267, 7, 'banner_text', 'Curated Styling Journeys'),
(268, 7, '_banner_text', 'field_67188e79f2f1b'),
(269, 7, 'banner_image', '59'),
(270, 7, '_banner_image', 'field_67188e8cf2f1c'),
(271, 7, 'banner_content', 'Personalized Styling experiences that weave together grace and practicality, ensuring you radiate confidence and beauty in every moment.'),
(272, 7, '_banner_content', 'field_67188eb9f2f1d'),
(273, 7, 'service_content', 'At Lune by Bhagya, we see personal style as more than mere clothing—it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.'),
(274, 7, '_service_content', 'field_67188ef9f2f1e'),
(275, 7, 'link_text', 'See Styling Services'),
(276, 7, '_link_text', 'field_67188f85f2f1f'),
(277, 7, 'link_url', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(278, 7, '_link_url', 'field_67188f94f2f20'),
(279, 60, 'banner_logo', '58'),
(280, 60, '_banner_logo', 'field_67188d83f2f1a'),
(281, 60, 'banner_text', 'Curated Styling Journeys'),
(282, 60, '_banner_text', 'field_67188e79f2f1b'),
(283, 60, 'banner_image', '59'),
(284, 60, '_banner_image', 'field_67188e8cf2f1c'),
(285, 60, 'banner_content', 'Personalized Styling experiences that weave together grace and practicality, ensuring you radiate confidence and beauty in every moment.'),
(286, 60, '_banner_content', 'field_67188eb9f2f1d'),
(287, 60, 'service_content', 'At Lune by Bhagya, we see personal style as more than mere clothing—it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.'),
(288, 60, '_service_content', 'field_67188ef9f2f1e'),
(289, 60, 'link_text', 'See Styling Services'),
(290, 60, '_link_text', 'field_67188f85f2f1f'),
(291, 60, 'link_url', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(292, 60, '_link_url', 'field_67188f94f2f20'),
(293, 6, 'big_text_0_b_text', 'Styling Packages'),
(294, 6, '_big_text_0_b_text', 'field_6718934d94f76'),
(295, 6, 'big_text_1_b_text', 'Styling Packages'),
(296, 6, '_big_text_1_b_text', 'field_6718934d94f76'),
(297, 6, 'big_text', '2'),
(298, 6, '_big_text', 'field_671892dc94f75'),
(299, 6, 'small_text_0_s_text', 'Virtual Personal Styling'),
(300, 6, '_small_text_0_s_text', 'field_671893d794f78'),
(301, 6, 'small_text_1_s_text', 'Sessions Wardrobe Audit'),
(302, 6, '_small_text_1_s_text', 'field_671893d794f78'),
(303, 6, 'small_text_2_s_text', 'Styling Consultations Long-Term'),
(304, 6, '_small_text_2_s_text', 'field_671893d794f78'),
(305, 6, 'small_text_3_s_text', 'Styling Packages editorial styling services'),
(306, 6, '_small_text_3_s_text', 'field_671893d794f78'),
(307, 6, 'small_text', '8'),
(308, 6, '_small_text', 'field_6718937b94f77'),
(309, 60, 'big_text_0_b_text', 'Styling Packages'),
(310, 60, '_big_text_0_b_text', 'field_6718934d94f76'),
(311, 60, 'big_text_1_b_text', 'Styling Packages'),
(312, 60, '_big_text_1_b_text', 'field_6718934d94f76'),
(313, 60, 'big_text', '2'),
(314, 60, '_big_text', 'field_671892dc94f75'),
(315, 60, 'small_text_0_s_text', 'Virtual Personal Styling'),
(316, 60, '_small_text_0_s_text', 'field_671893d794f78'),
(317, 60, 'small_text_1_s_text', 'Sessions Wardrobe Audit'),
(318, 60, '_small_text_1_s_text', 'field_671893d794f78'),
(319, 60, 'small_text_2_s_text', 'Styling Consultations Long-Term'),
(320, 60, '_small_text_2_s_text', 'field_671893d794f78'),
(321, 60, 'small_text_3_s_text', 'Styling Packages editorial styling services'),
(322, 60, '_small_text_3_s_text', 'field_671893d794f78'),
(323, 60, 'small_text', '4'),
(324, 60, '_small_text', 'field_6718937b94f77'),
(325, 74, '_wp_attached_file', '2024/10/img-four.jpg') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(326, 74, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:501;s:6:"height";i:470;s:4:"file";s:20:"2024/10/img-four.jpg";s:8:"filesize";i:130369;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:20:"img-four-300x281.jpg";s:5:"width";i:300;s:6:"height";i:281;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20138;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"img-four-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8011;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(327, 75, '_wp_attached_file', '2024/10/img-three.jpg'),
(328, 75, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:501;s:6:"height";i:470;s:4:"file";s:21:"2024/10/img-three.jpg";s:8:"filesize";i:131527;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:21:"img-three-300x281.jpg";s:5:"width";i:300;s:6:"height";i:281;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12377;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"img-three-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5103;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(329, 76, '_wp_attached_file', '2024/10/img-two.jpg'),
(330, 76, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:501;s:6:"height";i:470;s:4:"file";s:19:"2024/10/img-two.jpg";s:8:"filesize";i:88922;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:19:"img-two-300x281.jpg";s:5:"width";i:300;s:6:"height";i:281;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12590;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"img-two-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4553;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(331, 6, 'packages_0_package_image', '76'),
(332, 6, '_packages_0_package_image', 'field_67192d92f4ece'),
(333, 6, 'packages_0_package_name', 'entry package - Silver'),
(334, 6, '_packages_0_package_name', 'field_67192db2f4ecf'),
(335, 6, 'packages_0_package_content', 'A single, curated lookbook Delivery in 48 hrs'),
(336, 6, '_packages_0_package_content', 'field_67192dc8f4ed0'),
(337, 6, 'packages_0_package_price', '$75 / Rs. 3000'),
(338, 6, '_packages_0_package_price', 'field_67192deaf4ed1'),
(339, 6, 'packages_0_book_link', '#'),
(340, 6, '_packages_0_book_link', 'field_67192df7f4ed2'),
(341, 6, 'packages_1_package_image', '75'),
(342, 6, '_packages_1_package_image', 'field_67192d92f4ece'),
(343, 6, 'packages_1_package_name', 'Signature package - Gold'),
(344, 6, '_packages_1_package_name', 'field_67192db2f4ecf'),
(345, 6, 'packages_1_package_content', '3 expertly crafted lookbooks Delivery in 3 days'),
(346, 6, '_packages_1_package_content', 'field_67192dc8f4ed0'),
(347, 6, 'packages_1_package_price', '$200 / Rs. 5000'),
(348, 6, '_packages_1_package_price', 'field_67192deaf4ed1'),
(349, 6, 'packages_1_book_link', '#'),
(350, 6, '_packages_1_book_link', 'field_67192df7f4ed2'),
(351, 6, 'packages_2_package_image', '74'),
(352, 6, '_packages_2_package_image', 'field_67192d92f4ece'),
(353, 6, 'packages_2_package_name', 'Ultimate package - Diamond'),
(354, 6, '_packages_2_package_name', 'field_67192db2f4ecf'),
(355, 6, 'packages_2_package_content', '5 meticulously curated lookbooks - Delivery in 5 days'),
(356, 6, '_packages_2_package_content', 'field_67192dc8f4ed0'),
(357, 6, 'packages_2_package_price', '$350 / Rs. 10,000'),
(358, 6, '_packages_2_package_price', 'field_67192deaf4ed1'),
(359, 6, 'packages_2_book_link', '#'),
(360, 6, '_packages_2_book_link', 'field_67192df7f4ed2'),
(361, 6, 'packages', '3'),
(362, 6, '_packages', 'field_67192d3ef4ecd'),
(363, 66, 'banner_logo', '58'),
(364, 66, '_banner_logo', 'field_67188d83f2f1a'),
(365, 66, 'banner_text', 'Curated Styling Journeys'),
(366, 66, '_banner_text', 'field_67188e79f2f1b'),
(367, 66, 'banner_image', '59'),
(368, 66, '_banner_image', 'field_67188e8cf2f1c'),
(369, 66, 'banner_content', 'Personalized Styling experiences that weave together grace and practicality, ensuring you radiate confidence and beauty in every moment.'),
(370, 66, '_banner_content', 'field_67188eb9f2f1d'),
(371, 66, 'service_content', 'At Lune by Bhagya, we see personal style as more than mere clothing—it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.'),
(372, 66, '_service_content', 'field_67188ef9f2f1e'),
(373, 66, 'link_text', 'See Styling Services'),
(374, 66, '_link_text', 'field_67188f85f2f1f'),
(375, 66, 'link_url', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(376, 66, '_link_url', 'field_67188f94f2f20'),
(377, 66, 'big_text_0_b_text', 'Styling Packages'),
(378, 66, '_big_text_0_b_text', 'field_6718934d94f76'),
(379, 66, 'big_text_1_b_text', 'Styling Packages'),
(380, 66, '_big_text_1_b_text', 'field_6718934d94f76'),
(381, 66, 'big_text', '2'),
(382, 66, '_big_text', 'field_671892dc94f75'),
(383, 66, 'small_text_0_s_text', 'Virtual Personal Styling'),
(384, 66, '_small_text_0_s_text', 'field_671893d794f78'),
(385, 66, 'small_text_1_s_text', 'Sessions Wardrobe Audit'),
(386, 66, '_small_text_1_s_text', 'field_671893d794f78'),
(387, 66, 'small_text_2_s_text', 'Styling Consultations Long-Term'),
(388, 66, '_small_text_2_s_text', 'field_671893d794f78'),
(389, 66, 'small_text_3_s_text', 'Styling Packages editorial styling services'),
(390, 66, '_small_text_3_s_text', 'field_671893d794f78'),
(391, 66, 'small_text', '4'),
(392, 66, '_small_text', 'field_6718937b94f77'),
(393, 66, 'packages_0_package_image', '76'),
(394, 66, '_packages_0_package_image', 'field_67192d92f4ece'),
(395, 66, 'packages_0_package_name', 'entry package - Silver'),
(396, 66, '_packages_0_package_name', 'field_67192db2f4ecf'),
(397, 66, 'packages_0_package_content', 'A single, curated lookbook Delivery in 48 hrs'),
(398, 66, '_packages_0_package_content', 'field_67192dc8f4ed0'),
(399, 66, 'packages_0_package_price', '$75 / Rs. 3000'),
(400, 66, '_packages_0_package_price', 'field_67192deaf4ed1'),
(401, 66, 'packages_0_book_link', '#'),
(402, 66, '_packages_0_book_link', 'field_67192df7f4ed2'),
(403, 66, 'packages_1_package_image', '75'),
(404, 66, '_packages_1_package_image', 'field_67192d92f4ece'),
(405, 66, 'packages_1_package_name', 'Signature package - Gold'),
(406, 66, '_packages_1_package_name', 'field_67192db2f4ecf'),
(407, 66, 'packages_1_package_content', '3 expertly crafted lookbooks Delivery in 3 days'),
(408, 66, '_packages_1_package_content', 'field_67192dc8f4ed0'),
(409, 66, 'packages_1_package_price', '$200 / Rs. 5000'),
(410, 66, '_packages_1_package_price', 'field_67192deaf4ed1'),
(411, 66, 'packages_1_book_link', '#'),
(412, 66, '_packages_1_book_link', 'field_67192df7f4ed2'),
(413, 66, 'packages_2_package_image', '74'),
(414, 66, '_packages_2_package_image', 'field_67192d92f4ece'),
(415, 66, 'packages_2_package_name', 'Ultimate package - Diamond'),
(416, 66, '_packages_2_package_name', 'field_67192db2f4ecf'),
(417, 66, 'packages_2_package_content', '5 meticulously curated lookbooks - Delivery in 5 days'),
(418, 66, '_packages_2_package_content', 'field_67192dc8f4ed0'),
(419, 66, 'packages_2_package_price', '$350 / Rs. 10,000'),
(420, 66, '_packages_2_package_price', 'field_67192deaf4ed1'),
(421, 66, 'packages_2_book_link', '#'),
(422, 66, '_packages_2_book_link', 'field_67192df7f4ed2'),
(423, 66, 'packages', '3'),
(424, 66, '_packages', 'field_67192d3ef4ecd'),
(425, 6, 'pk_button_text', 'About Lune by Bhagya') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(426, 6, '_pk_button_text', 'field_671930ab9e49a'),
(427, 6, 'pk_button_link', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:49:"https://localhost/luna/site/about-lune-by-bhagya/";s:6:"target";s:0:"";}'),
(428, 6, '_pk_button_link', 'field_671930b89e49b'),
(429, 77, 'banner_logo', '58'),
(430, 77, '_banner_logo', 'field_67188d83f2f1a'),
(431, 77, 'banner_text', 'Curated Styling Journeys'),
(432, 77, '_banner_text', 'field_67188e79f2f1b'),
(433, 77, 'banner_image', '59'),
(434, 77, '_banner_image', 'field_67188e8cf2f1c'),
(435, 77, 'banner_content', 'Personalized Styling experiences that weave together grace and practicality, ensuring you radiate confidence and beauty in every moment.'),
(436, 77, '_banner_content', 'field_67188eb9f2f1d'),
(437, 77, 'service_content', 'At Lune by Bhagya, we see personal style as more than mere clothing—it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.'),
(438, 77, '_service_content', 'field_67188ef9f2f1e'),
(439, 77, 'link_text', 'See Styling Services'),
(440, 77, '_link_text', 'field_67188f85f2f1f'),
(441, 77, 'link_url', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(442, 77, '_link_url', 'field_67188f94f2f20'),
(443, 77, 'big_text_0_b_text', 'Styling Packages'),
(444, 77, '_big_text_0_b_text', 'field_6718934d94f76'),
(445, 77, 'big_text_1_b_text', 'Styling Packages'),
(446, 77, '_big_text_1_b_text', 'field_6718934d94f76'),
(447, 77, 'big_text', '2'),
(448, 77, '_big_text', 'field_671892dc94f75'),
(449, 77, 'small_text_0_s_text', 'Virtual Personal Styling'),
(450, 77, '_small_text_0_s_text', 'field_671893d794f78'),
(451, 77, 'small_text_1_s_text', 'Sessions Wardrobe Audit'),
(452, 77, '_small_text_1_s_text', 'field_671893d794f78'),
(453, 77, 'small_text_2_s_text', 'Styling Consultations Long-Term'),
(454, 77, '_small_text_2_s_text', 'field_671893d794f78'),
(455, 77, 'small_text_3_s_text', 'Styling Packages editorial styling services'),
(456, 77, '_small_text_3_s_text', 'field_671893d794f78'),
(457, 77, 'small_text', '4'),
(458, 77, '_small_text', 'field_6718937b94f77'),
(459, 77, 'packages_0_package_image', '76'),
(460, 77, '_packages_0_package_image', 'field_67192d92f4ece'),
(461, 77, 'packages_0_package_name', 'entry package - Silver'),
(462, 77, '_packages_0_package_name', 'field_67192db2f4ecf'),
(463, 77, 'packages_0_package_content', 'A single, curated lookbook Delivery in 48 hrs'),
(464, 77, '_packages_0_package_content', 'field_67192dc8f4ed0'),
(465, 77, 'packages_0_package_price', '$75 / Rs. 3000'),
(466, 77, '_packages_0_package_price', 'field_67192deaf4ed1'),
(467, 77, 'packages_0_book_link', '#'),
(468, 77, '_packages_0_book_link', 'field_67192df7f4ed2'),
(469, 77, 'packages_1_package_image', '75'),
(470, 77, '_packages_1_package_image', 'field_67192d92f4ece'),
(471, 77, 'packages_1_package_name', 'Signature package - Gold'),
(472, 77, '_packages_1_package_name', 'field_67192db2f4ecf'),
(473, 77, 'packages_1_package_content', '3 expertly crafted lookbooks Delivery in 3 days'),
(474, 77, '_packages_1_package_content', 'field_67192dc8f4ed0'),
(475, 77, 'packages_1_package_price', '$200 / Rs. 5000'),
(476, 77, '_packages_1_package_price', 'field_67192deaf4ed1'),
(477, 77, 'packages_1_book_link', '#'),
(478, 77, '_packages_1_book_link', 'field_67192df7f4ed2'),
(479, 77, 'packages_2_package_image', '74'),
(480, 77, '_packages_2_package_image', 'field_67192d92f4ece'),
(481, 77, 'packages_2_package_name', 'Ultimate package - Diamond'),
(482, 77, '_packages_2_package_name', 'field_67192db2f4ecf'),
(483, 77, 'packages_2_package_content', '5 meticulously curated lookbooks - Delivery in 5 days'),
(484, 77, '_packages_2_package_content', 'field_67192dc8f4ed0'),
(485, 77, 'packages_2_package_price', '$350 / Rs. 10,000'),
(486, 77, '_packages_2_package_price', 'field_67192deaf4ed1'),
(487, 77, 'packages_2_book_link', '#'),
(488, 77, '_packages_2_book_link', 'field_67192df7f4ed2'),
(489, 77, 'packages', '3'),
(490, 77, '_packages', 'field_67192d3ef4ecd'),
(491, 77, 'pk_button_text', 'see all styling services'),
(492, 77, '_pk_button_text', 'field_671930ab9e49a'),
(493, 77, 'pk_button_link', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(494, 77, '_pk_button_link', 'field_671930b89e49b'),
(495, 84, '_wp_attached_file', '2024/10/banner-three.jpg'),
(496, 84, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:875;s:4:"file";s:24:"2024/10/banner-three.jpg";s:8:"filesize";i:1177156;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:24:"banner-three-300x182.jpg";s:5:"width";i:300;s:6:"height";i:182;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18470;}s:5:"large";a:5:{s:4:"file";s:25:"banner-three-1024x622.jpg";s:5:"width";i:1024;s:6:"height";i:622;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:137255;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"banner-three-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9112;}s:12:"medium_large";a:5:{s:4:"file";s:24:"banner-three-768x467.jpg";s:5:"width";i:768;s:6:"height";i:467;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87518;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(497, 85, '_wp_attached_file', '2024/10/video.mp4'),
(498, 85, '_wp_attachment_metadata', 'a:10:{s:7:"bitrate";i:523859;s:8:"filesize";i:1926663;s:9:"mime_type";s:15:"video/quicktime";s:6:"length";i:29;s:16:"length_formatted";s:4:"0:29";s:5:"width";i:640;s:6:"height";i:360;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:9:"quicktime";s:17:"created_timestamp";i:1539786866;}'),
(499, 6, 'video_image', '84'),
(500, 6, '_video_image', 'field_67193185af906'),
(501, 6, 'add_video', '85'),
(502, 6, '_add_video', 'field_67193152af905'),
(503, 80, 'banner_logo', '58'),
(504, 80, '_banner_logo', 'field_67188d83f2f1a'),
(505, 80, 'banner_text', 'Curated Styling Journeys'),
(506, 80, '_banner_text', 'field_67188e79f2f1b'),
(507, 80, 'banner_image', '59'),
(508, 80, '_banner_image', 'field_67188e8cf2f1c'),
(509, 80, 'banner_content', 'Personalized Styling experiences that weave together grace and practicality, ensuring you radiate confidence and beauty in every moment.'),
(510, 80, '_banner_content', 'field_67188eb9f2f1d'),
(511, 80, 'service_content', 'At Lune by Bhagya, we see personal style as more than mere clothing—it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.'),
(512, 80, '_service_content', 'field_67188ef9f2f1e'),
(513, 80, 'link_text', 'See Styling Services'),
(514, 80, '_link_text', 'field_67188f85f2f1f'),
(515, 80, 'link_url', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(516, 80, '_link_url', 'field_67188f94f2f20'),
(517, 80, 'big_text_0_b_text', 'Styling Packages'),
(518, 80, '_big_text_0_b_text', 'field_6718934d94f76'),
(519, 80, 'big_text_1_b_text', 'Styling Packages'),
(520, 80, '_big_text_1_b_text', 'field_6718934d94f76'),
(521, 80, 'big_text', '2'),
(522, 80, '_big_text', 'field_671892dc94f75'),
(523, 80, 'small_text_0_s_text', 'Virtual Personal Styling'),
(524, 80, '_small_text_0_s_text', 'field_671893d794f78'),
(525, 80, 'small_text_1_s_text', 'Sessions Wardrobe Audit') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(526, 80, '_small_text_1_s_text', 'field_671893d794f78'),
(527, 80, 'small_text_2_s_text', 'Styling Consultations Long-Term'),
(528, 80, '_small_text_2_s_text', 'field_671893d794f78'),
(529, 80, 'small_text_3_s_text', 'Styling Packages editorial styling services'),
(530, 80, '_small_text_3_s_text', 'field_671893d794f78'),
(531, 80, 'small_text', '4'),
(532, 80, '_small_text', 'field_6718937b94f77'),
(533, 80, 'packages_0_package_image', '76'),
(534, 80, '_packages_0_package_image', 'field_67192d92f4ece'),
(535, 80, 'packages_0_package_name', 'entry package - Silver'),
(536, 80, '_packages_0_package_name', 'field_67192db2f4ecf'),
(537, 80, 'packages_0_package_content', 'A single, curated lookbook Delivery in 48 hrs'),
(538, 80, '_packages_0_package_content', 'field_67192dc8f4ed0'),
(539, 80, 'packages_0_package_price', '$75 / Rs. 3000'),
(540, 80, '_packages_0_package_price', 'field_67192deaf4ed1'),
(541, 80, 'packages_0_book_link', '#'),
(542, 80, '_packages_0_book_link', 'field_67192df7f4ed2'),
(543, 80, 'packages_1_package_image', '75'),
(544, 80, '_packages_1_package_image', 'field_67192d92f4ece'),
(545, 80, 'packages_1_package_name', 'Signature package - Gold'),
(546, 80, '_packages_1_package_name', 'field_67192db2f4ecf'),
(547, 80, 'packages_1_package_content', '3 expertly crafted lookbooks Delivery in 3 days'),
(548, 80, '_packages_1_package_content', 'field_67192dc8f4ed0'),
(549, 80, 'packages_1_package_price', '$200 / Rs. 5000'),
(550, 80, '_packages_1_package_price', 'field_67192deaf4ed1'),
(551, 80, 'packages_1_book_link', '#'),
(552, 80, '_packages_1_book_link', 'field_67192df7f4ed2'),
(553, 80, 'packages_2_package_image', '74'),
(554, 80, '_packages_2_package_image', 'field_67192d92f4ece'),
(555, 80, 'packages_2_package_name', 'Ultimate package - Diamond'),
(556, 80, '_packages_2_package_name', 'field_67192db2f4ecf'),
(557, 80, 'packages_2_package_content', '5 meticulously curated lookbooks - Delivery in 5 days'),
(558, 80, '_packages_2_package_content', 'field_67192dc8f4ed0'),
(559, 80, 'packages_2_package_price', '$350 / Rs. 10,000'),
(560, 80, '_packages_2_package_price', 'field_67192deaf4ed1'),
(561, 80, 'packages_2_book_link', '#'),
(562, 80, '_packages_2_book_link', 'field_67192df7f4ed2'),
(563, 80, 'packages', '3'),
(564, 80, '_packages', 'field_67192d3ef4ecd'),
(565, 80, 'pk_button_text', 'see all styling services'),
(566, 80, '_pk_button_text', 'field_671930ab9e49a'),
(567, 80, 'pk_button_link', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(568, 80, '_pk_button_link', 'field_671930b89e49b'),
(569, 80, 'video_image', '84'),
(570, 80, '_video_image', 'field_67193185af906'),
(571, 80, 'add_video', '85'),
(572, 80, '_add_video', 'field_67193152af905'),
(573, 106, '_wp_attached_file', '2024/10/img-five.jpg'),
(574, 106, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:623;s:6:"height";i:574;s:4:"file";s:20:"2024/10/img-five.jpg";s:8:"filesize";i:206067;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:20:"img-five-300x276.jpg";s:5:"width";i:300;s:6:"height";i:276;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15505;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"img-five-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5839;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(575, 107, '_wp_attached_file', '2024/10/detailed-four.jpg'),
(576, 107, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:371;s:6:"height";i:351;s:4:"file";s:25:"2024/10/detailed-four.jpg";s:8:"filesize";i:55621;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:25:"detailed-four-300x284.jpg";s:5:"width";i:300;s:6:"height";i:284;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14618;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"detailed-four-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6695;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(577, 6, 'testi_title', 'real stories'),
(578, 6, '_testi_title', 'field_6719327a5dbbd'),
(579, 6, 'testi_image', '106'),
(580, 6, '_testi_image', 'field_671932d95dbbe'),
(581, 6, 'testi_image_text', 'Real Style Transformations'),
(582, 6, '_testi_image_text', 'field_671932ef5dbbf'),
(583, 6, 'testi_content', 'Working with Lune by Bhagya was a transformative experience! The lookbook I received perfectly captured my style and boosted my confidence for my upcoming event. I can\'t thank Bhagya enough for her expertise!'),
(584, 6, '_testi_content', 'field_6719330e5dbc0'),
(585, 6, 'testi_name', 'Sofia M.'),
(586, 6, '_testi_name', 'field_671933285dbc1'),
(587, 6, 'in_title', 'Insights   Inspiration '),
(588, 6, '_in_title', 'field_6719337767360'),
(589, 6, 'home_insights_0_in_head', 'The Art of Lookbooks: Why They’re Essential for Every Fashionista'),
(590, 6, '_home_insights_0_in_head', 'field_671933b367362'),
(591, 6, 'home_insights_0_in_link', 'a:3:{s:5:"title";s:25:"Building a Brand Identity";s:3:"url";s:62:"https://localhost/luna/site/blogs/building-a-brand-identity-1/";s:6:"target";s:0:"";}'),
(592, 6, '_home_insights_0_in_link', 'field_671933c567363'),
(593, 6, 'home_insights_1_in_head', 'the importance of body shape and color analysis, and how to create versatile outfits'),
(594, 6, '_home_insights_1_in_head', 'field_671933b367362'),
(595, 6, 'home_insights_1_in_link', 'a:3:{s:5:"title";s:25:"Building a Brand Identity";s:3:"url";s:60:"https://localhost/luna/site/blogs/building-a-brand-identity/";s:6:"target";s:0:"";}'),
(596, 6, '_home_insights_1_in_link', 'field_671933c567363'),
(597, 6, 'home_insights', '2'),
(598, 6, '_home_insights', 'field_6719339867361'),
(599, 6, 'blog_title', 'Related Blogs'),
(600, 6, '_blog_title', 'field_67193450dadcb'),
(601, 6, 'rel_blogs_0_blog_image', '107'),
(602, 6, '_rel_blogs_0_blog_image', 'field_6719347fdadcd'),
(603, 6, 'rel_blogs_0_blog_date', '20240910'),
(604, 6, '_rel_blogs_0_blog_date', 'field_671934a3dadce'),
(605, 6, 'rel_blogs_0_b_title', 'Building a Brand Identity'),
(606, 6, '_rel_blogs_0_b_title', 'field_671934d9dadcf'),
(607, 6, 'rel_blogs_0_blog_content', 'This post could delve into the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity.'),
(608, 6, '_rel_blogs_0_blog_content', 'field_671934eddadd0'),
(609, 6, 'rel_blogs_0_blog_link', ''),
(610, 6, '_rel_blogs_0_blog_link', 'field_67193500dadd1'),
(611, 6, 'rel_blogs', '1'),
(612, 6, '_rel_blogs', 'field_67193465dadcc'),
(613, 86, 'banner_logo', '58'),
(614, 86, '_banner_logo', 'field_67188d83f2f1a'),
(615, 86, 'banner_text', 'Curated Styling Journeys'),
(616, 86, '_banner_text', 'field_67188e79f2f1b'),
(617, 86, 'banner_image', '59'),
(618, 86, '_banner_image', 'field_67188e8cf2f1c'),
(619, 86, 'banner_content', 'Personalized Styling experiences that weave together grace and practicality, ensuring you radiate confidence and beauty in every moment.'),
(620, 86, '_banner_content', 'field_67188eb9f2f1d'),
(621, 86, 'service_content', 'At Lune by Bhagya, we see personal style as more than mere clothing—it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.'),
(622, 86, '_service_content', 'field_67188ef9f2f1e'),
(623, 86, 'link_text', 'See Styling Services'),
(624, 86, '_link_text', 'field_67188f85f2f1f'),
(625, 86, 'link_url', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(626, 86, '_link_url', 'field_67188f94f2f20'),
(627, 86, 'big_text_0_b_text', 'Styling Packages'),
(628, 86, '_big_text_0_b_text', 'field_6718934d94f76'),
(629, 86, 'big_text_1_b_text', 'Styling Packages'),
(630, 86, '_big_text_1_b_text', 'field_6718934d94f76'),
(631, 86, 'big_text', '2'),
(632, 86, '_big_text', 'field_671892dc94f75'),
(633, 86, 'small_text_0_s_text', 'Virtual Personal Styling'),
(634, 86, '_small_text_0_s_text', 'field_671893d794f78'),
(635, 86, 'small_text_1_s_text', 'Sessions Wardrobe Audit'),
(636, 86, '_small_text_1_s_text', 'field_671893d794f78'),
(637, 86, 'small_text_2_s_text', 'Styling Consultations Long-Term'),
(638, 86, '_small_text_2_s_text', 'field_671893d794f78'),
(639, 86, 'small_text_3_s_text', 'Styling Packages editorial styling services'),
(640, 86, '_small_text_3_s_text', 'field_671893d794f78'),
(641, 86, 'small_text', '4'),
(642, 86, '_small_text', 'field_6718937b94f77'),
(643, 86, 'packages_0_package_image', '76'),
(644, 86, '_packages_0_package_image', 'field_67192d92f4ece'),
(645, 86, 'packages_0_package_name', 'entry package - Silver'),
(646, 86, '_packages_0_package_name', 'field_67192db2f4ecf'),
(647, 86, 'packages_0_package_content', 'A single, curated lookbook Delivery in 48 hrs'),
(648, 86, '_packages_0_package_content', 'field_67192dc8f4ed0'),
(649, 86, 'packages_0_package_price', '$75 / Rs. 3000'),
(650, 86, '_packages_0_package_price', 'field_67192deaf4ed1'),
(651, 86, 'packages_0_book_link', '#'),
(652, 86, '_packages_0_book_link', 'field_67192df7f4ed2'),
(653, 86, 'packages_1_package_image', '75'),
(654, 86, '_packages_1_package_image', 'field_67192d92f4ece'),
(655, 86, 'packages_1_package_name', 'Signature package - Gold'),
(656, 86, '_packages_1_package_name', 'field_67192db2f4ecf'),
(657, 86, 'packages_1_package_content', '3 expertly crafted lookbooks Delivery in 3 days'),
(658, 86, '_packages_1_package_content', 'field_67192dc8f4ed0'),
(659, 86, 'packages_1_package_price', '$200 / Rs. 5000'),
(660, 86, '_packages_1_package_price', 'field_67192deaf4ed1'),
(661, 86, 'packages_1_book_link', '#'),
(662, 86, '_packages_1_book_link', 'field_67192df7f4ed2'),
(663, 86, 'packages_2_package_image', '74'),
(664, 86, '_packages_2_package_image', 'field_67192d92f4ece'),
(665, 86, 'packages_2_package_name', 'Ultimate package - Diamond'),
(666, 86, '_packages_2_package_name', 'field_67192db2f4ecf'),
(667, 86, 'packages_2_package_content', '5 meticulously curated lookbooks - Delivery in 5 days'),
(668, 86, '_packages_2_package_content', 'field_67192dc8f4ed0'),
(669, 86, 'packages_2_package_price', '$350 / Rs. 10,000'),
(670, 86, '_packages_2_package_price', 'field_67192deaf4ed1'),
(671, 86, 'packages_2_book_link', '#'),
(672, 86, '_packages_2_book_link', 'field_67192df7f4ed2'),
(673, 86, 'packages', '3'),
(674, 86, '_packages', 'field_67192d3ef4ecd'),
(675, 86, 'pk_button_text', 'see all styling services'),
(676, 86, '_pk_button_text', 'field_671930ab9e49a'),
(677, 86, 'pk_button_link', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(678, 86, '_pk_button_link', 'field_671930b89e49b'),
(679, 86, 'video_image', '84'),
(680, 86, '_video_image', 'field_67193185af906'),
(681, 86, 'add_video', '85'),
(682, 86, '_add_video', 'field_67193152af905'),
(683, 86, 'testi_title', 'real stories'),
(684, 86, '_testi_title', 'field_6719327a5dbbd'),
(685, 86, 'testi_image', '106'),
(686, 86, '_testi_image', 'field_671932d95dbbe'),
(687, 86, 'testi_image_text', 'Real Style Transformations'),
(688, 86, '_testi_image_text', 'field_671932ef5dbbf'),
(689, 86, 'testi_content', 'Working with Lune by Bhagya was a transformative experience! The lookbook I received perfectly captured my style and boosted my confidence for my upcoming event. I can\'t thank Bhagya enough for her expertise!'),
(690, 86, '_testi_content', 'field_6719330e5dbc0'),
(691, 86, 'testi_name', 'Sofia M.'),
(692, 86, '_testi_name', 'field_671933285dbc1'),
(693, 86, 'in_title', 'Insights &nbsp; Inspiration '),
(694, 86, '_in_title', 'field_6719337767360'),
(695, 86, 'home_insights_0_in_head', 'The Art of Lookbooks: Why They’re Essential for Every Fashionista'),
(696, 86, '_home_insights_0_in_head', 'field_671933b367362'),
(697, 86, 'home_insights_0_in_link', ''),
(698, 86, '_home_insights_0_in_link', 'field_671933c567363'),
(699, 86, 'home_insights_1_in_head', 'the importance of body shape and color analysis, and how to create versatile outfits'),
(700, 86, '_home_insights_1_in_head', 'field_671933b367362'),
(701, 86, 'home_insights_1_in_link', ''),
(702, 86, '_home_insights_1_in_link', 'field_671933c567363'),
(703, 86, 'home_insights', '2'),
(704, 86, '_home_insights', 'field_6719339867361'),
(705, 86, 'blog_title', 'Related Blogs'),
(706, 86, '_blog_title', 'field_67193450dadcb'),
(707, 86, 'rel_blogs_0_blog_image', '107'),
(708, 86, '_rel_blogs_0_blog_image', 'field_6719347fdadcd'),
(709, 86, 'rel_blogs_0_blog_date', '20240910'),
(710, 86, '_rel_blogs_0_blog_date', 'field_671934a3dadce'),
(711, 86, 'rel_blogs_0_b_title', 'Building a Brand Identity'),
(712, 86, '_rel_blogs_0_b_title', 'field_671934d9dadcf'),
(713, 86, 'rel_blogs_0_blog_content', 'This post could delve into the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity.'),
(714, 86, '_rel_blogs_0_blog_content', 'field_671934eddadd0'),
(715, 86, 'rel_blogs_0_blog_link', ''),
(716, 86, '_rel_blogs_0_blog_link', 'field_67193500dadd1'),
(717, 86, 'rel_blogs', '1'),
(718, 86, '_rel_blogs', 'field_67193465dadcc'),
(719, 8, '_yoast_wpseo_content_score', '90'),
(720, 8, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(721, 8, '_yoast_wpseo_wordproof_timestamp', ''),
(722, 111, '_edit_last', '1'),
(723, 111, '_edit_lock', '1729871471:1'),
(724, 113, '_wp_attached_file', '2024/10/about-page-e1729835608376.jpg'),
(725, 113, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:443;s:6:"height";i:637;s:4:"file";s:37:"2024/10/about-page-e1729835608376.jpg";s:8:"filesize";i:310319;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:37:"about-page-e1729835608376-209x300.jpg";s:5:"width";i:209;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18733;}s:9:"thumbnail";a:5:{s:4:"file";s:37:"about-page-e1729835608376-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7817;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(726, 8, '_thumbnail_id', '113'),
(727, 114, '_edit_last', '1'),
(728, 114, '_edit_lock', '1730711184:1'),
(729, 10, 'banner_title', 'Services'),
(730, 10, '_banner_title', 'field_67193ff9ed0e6'),
(731, 10, 'ser_scrolling_text_0_ser_text', 'Comprehensive styling services'),
(732, 10, '_ser_scrolling_text_0_ser_text', 'field_6719403ded0e8'),
(733, 10, 'ser_scrolling_text_1_ser_text', 'Comprehensive styling services'),
(734, 10, '_ser_scrolling_text_1_ser_text', 'field_6719403ded0e8'),
(735, 10, 'ser_scrolling_text', '2'),
(736, 10, '_ser_scrolling_text', 'field_67194021ed0e7'),
(737, 10, 'our_services_0_service_name', 'Virtual personal styling sessions'),
(738, 10, '_our_services_0_service_name', 'field_671940a4ed0ea'),
(739, 10, 'our_services_0_service_description', '<ul>\r\n 	<li>Body shape analysis</li>\r\n 	<li>Color analysis</li>\r\n 	<li>Variation analysis</li>\r\n 	<li>Moodboard</li>\r\n 	<li>Tailored outfit curation</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Shopping guide - lookbooks with links</li>\r\n 	<li>Video sessions</li>\r\n</ul>'),
(740, 10, '_our_services_0_service_description', 'field_671940b3ed0eb'),
(741, 10, 'our_services_0_service_price', '$500 / Rs. 15,000'),
(742, 10, '_our_services_0_service_price', 'field_671940eded0ed'),
(743, 10, 'our_services_1_service_name', 'Wardrobe audit and styling consultations'),
(744, 10, '_our_services_1_service_name', 'field_671940a4ed0ea'),
(745, 10, 'our_services_1_service_description', '<ul>\r\n 	<li>Complete wardrobe audit</li>\r\n 	<li>Decluttering and sorting</li>\r\n 	<li>Development of personal style</li>\r\n 	<li>Pre-shopping research</li>\r\n 	<li>Guided shopping</li>\r\n 	<li>Moodboard</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Revisions</li>\r\n 	<li>Video sessions</li>\r\n</ul>'),
(746, 10, '_our_services_1_service_description', 'field_671940b3ed0eb'),
(747, 10, 'our_services_1_service_price', '$600 / Rs. 20,000 per month'),
(748, 10, '_our_services_1_service_price', 'field_671940eded0ed'),
(749, 10, 'our_services_2_service_name', 'Editorial styling'),
(750, 10, '_our_services_2_service_name', 'field_671940a4ed0ea'),
(751, 10, 'our_services_2_service_description', '<ul>\r\n 	<li>Concept development</li>\r\n 	<li>Moodboard and colorboard</li>\r\n 	<li>Storyboard</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Garment sourcing</li>\r\n 	<li>Shooting assistance</li>\r\n 	<li>Video and one-on-one assistance</li>\r\n</ul>'),
(752, 10, '_our_services_2_service_description', 'field_671940b3ed0eb'),
(753, 10, 'our_services_2_service_price', '$600 / Rs. 20,000 per month'),
(754, 10, '_our_services_2_service_price', 'field_671940eded0ed'),
(755, 10, 'our_services', '3'),
(756, 10, '_our_services', 'field_6719405bed0e9'),
(757, 11, 'banner_title', 'Styling'),
(758, 11, '_banner_title', 'field_67193ff9ed0e6'),
(759, 11, 'ser_scrolling_text_0_ser_text', 'Comprehensive styling services'),
(760, 11, '_ser_scrolling_text_0_ser_text', 'field_6719403ded0e8'),
(761, 11, 'ser_scrolling_text_1_ser_text', 'Comprehensive styling services'),
(762, 11, '_ser_scrolling_text_1_ser_text', 'field_6719403ded0e8'),
(763, 11, 'ser_scrolling_text', '2'),
(764, 11, '_ser_scrolling_text', 'field_67194021ed0e7'),
(765, 11, 'our_services_0_service_name', 'Virtual personal styling sessions'),
(766, 11, '_our_services_0_service_name', 'field_671940a4ed0ea'),
(767, 11, 'our_services_0_service_description', '<ul>\r\n 	<li>Body shape analysis</li>\r\n 	<li>Color analysis</li>\r\n 	<li>Variation analysis</li>\r\n 	<li>Moodboard</li>\r\n 	<li>Tailored outfit curation</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Shopping guide - lookbooks with links</li>\r\n 	<li>Video sessions</li>\r\n</ul>'),
(768, 11, '_our_services_0_service_description', 'field_671940b3ed0eb'),
(769, 11, 'our_services_0_service_price', '$500 / Rs. 15,000'),
(770, 11, '_our_services_0_service_price', 'field_671940eded0ed'),
(771, 11, 'our_services_1_service_name', 'Wardrobe audit and styling consultations'),
(772, 11, '_our_services_1_service_name', 'field_671940a4ed0ea'),
(773, 11, 'our_services_1_service_description', '<ul>\r\n 	<li>Complete wardrobe audit</li>\r\n 	<li>Decluttering and sorting</li>\r\n 	<li>Development of personal style</li>\r\n 	<li>Pre-shopping research</li>\r\n 	<li>Guided shopping</li>\r\n 	<li>Moodboard</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Revisions</li>\r\n 	<li>Video sessions</li>\r\n</ul>'),
(774, 11, '_our_services_1_service_description', 'field_671940b3ed0eb'),
(775, 11, 'our_services_1_service_price', '$600 / Rs. 20,000 per month'),
(776, 11, '_our_services_1_service_price', 'field_671940eded0ed'),
(777, 11, 'our_services_2_service_name', 'Editorial styling'),
(778, 11, '_our_services_2_service_name', 'field_671940a4ed0ea'),
(779, 11, 'our_services_2_service_description', '<ul>\r\n 	<li>Concept development</li>\r\n 	<li>Moodboard and colorboard</li>\r\n 	<li>Storyboard</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Garment sourcing</li>\r\n 	<li>Shooting assistance</li>\r\n 	<li>Video and one-on-one assistance</li>\r\n</ul>'),
(780, 11, '_our_services_2_service_description', 'field_671940b3ed0eb'),
(781, 11, 'our_services_2_service_price', '$600 / Rs. 20,000 per month'),
(782, 11, '_our_services_2_service_price', 'field_671940eded0ed'),
(783, 11, 'our_services', '3'),
(784, 11, '_our_services', 'field_6719405bed0e9'),
(785, 125, '_menu_item_type', 'post_type'),
(786, 125, '_menu_item_menu_item_parent', '0'),
(787, 125, '_menu_item_object_id', '10'),
(788, 125, '_menu_item_object', 'page'),
(789, 125, '_menu_item_target', ''),
(790, 125, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(791, 125, '_menu_item_xfn', ''),
(792, 125, '_menu_item_url', ''),
(794, 126, '_edit_lock', '1729710447:1'),
(795, 18, '_yoast_wpseo_content_score', '90'),
(796, 126, '_wp_trash_meta_status', 'publish'),
(797, 126, '_wp_trash_meta_time', '1729710562'),
(798, 126, '_wp_desired_post_slug', 'group_671947a683952'),
(799, 127, '_wp_trash_meta_status', 'publish'),
(800, 127, '_wp_trash_meta_time', '1729710563'),
(801, 127, '_wp_desired_post_slug', 'field_671947a75987f'),
(802, 128, '_wp_trash_meta_status', 'publish'),
(803, 128, '_wp_trash_meta_time', '1729710564'),
(804, 128, '_wp_desired_post_slug', 'field_671947a759c63'),
(805, 129, '_wp_trash_meta_status', 'publish'),
(806, 129, '_wp_trash_meta_time', '1729710565'),
(807, 129, '_wp_desired_post_slug', 'field_671947a75a04d'),
(808, 130, '_wp_trash_meta_status', 'publish'),
(809, 130, '_wp_trash_meta_time', '1729710565'),
(810, 130, '_wp_desired_post_slug', 'field_671947a75a433'),
(811, 131, '_wp_trash_meta_status', 'publish'),
(812, 131, '_wp_trash_meta_time', '1729710566'),
(813, 131, '_wp_desired_post_slug', 'field_671947a75a81b'),
(814, 132, '_wp_trash_meta_status', 'publish'),
(815, 132, '_wp_trash_meta_time', '1729710567'),
(816, 132, '_wp_desired_post_slug', 'field_671947a75ac11'),
(817, 133, '_wp_trash_meta_status', 'publish'),
(818, 133, '_wp_trash_meta_time', '1729710568'),
(819, 133, '_wp_desired_post_slug', 'field_671947a75afef'),
(820, 134, '_wp_trash_meta_status', 'publish'),
(821, 134, '_wp_trash_meta_time', '1729710568'),
(822, 134, '_wp_desired_post_slug', 'field_671947a75b405'),
(823, 135, '_wp_trash_meta_status', 'publish'),
(824, 135, '_wp_trash_meta_time', '1729710570'),
(825, 135, '_wp_desired_post_slug', 'field_671947a75b7c1'),
(826, 136, '_wp_trash_meta_status', 'publish') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(827, 136, '_wp_trash_meta_time', '1729710570'),
(828, 136, '_wp_desired_post_slug', 'field_671947a75bbc3'),
(829, 138, '_wp_trash_meta_status', 'publish'),
(830, 138, '_wp_trash_meta_time', '1729710571'),
(831, 138, '_wp_desired_post_slug', 'field_671947a75bf92'),
(832, 140, '_wp_trash_meta_status', 'publish'),
(833, 140, '_wp_trash_meta_time', '1729710572'),
(834, 140, '_wp_desired_post_slug', 'field_671947a75c376'),
(835, 141, '_wp_trash_meta_status', 'publish'),
(836, 141, '_wp_trash_meta_time', '1729710573'),
(837, 141, '_wp_desired_post_slug', 'field_671947a75c764'),
(838, 147, '_wp_trash_meta_status', 'publish'),
(839, 147, '_wp_trash_meta_time', '1729710573'),
(840, 147, '_wp_desired_post_slug', 'field_671947a75cb55'),
(841, 148, '_wp_trash_meta_status', 'publish'),
(842, 148, '_wp_trash_meta_time', '1729710574'),
(843, 148, '_wp_desired_post_slug', 'field_671947a75cf34'),
(844, 149, '_wp_trash_meta_status', 'publish'),
(845, 149, '_wp_trash_meta_time', '1729710575'),
(846, 149, '_wp_desired_post_slug', 'field_671947a75d329'),
(847, 150, '_wp_trash_meta_status', 'publish'),
(848, 150, '_wp_trash_meta_time', '1729710575'),
(849, 150, '_wp_desired_post_slug', 'field_671947a75d70d'),
(850, 151, '_wp_trash_meta_status', 'publish'),
(851, 151, '_wp_trash_meta_time', '1729710577'),
(852, 151, '_wp_desired_post_slug', 'field_671947a75db08'),
(853, 152, '_wp_trash_meta_status', 'publish'),
(854, 152, '_wp_trash_meta_time', '1729710577'),
(855, 152, '_wp_desired_post_slug', 'field_671947a75ded2'),
(856, 153, '_wp_trash_meta_status', 'publish'),
(857, 153, '_wp_trash_meta_time', '1729710578'),
(858, 153, '_wp_desired_post_slug', 'field_671947a75e2db'),
(859, 154, '_wp_trash_meta_status', 'publish'),
(860, 154, '_wp_trash_meta_time', '1729710579'),
(861, 154, '_wp_desired_post_slug', 'field_671947a75e6c0'),
(862, 155, '_wp_trash_meta_status', 'publish'),
(863, 155, '_wp_trash_meta_time', '1729710580'),
(864, 155, '_wp_desired_post_slug', 'field_671947a75eac6'),
(865, 156, '_wp_trash_meta_status', 'publish'),
(866, 156, '_wp_trash_meta_time', '1729710581'),
(867, 156, '_wp_desired_post_slug', 'field_671947a75ee7a'),
(868, 157, '_wp_trash_meta_status', 'publish'),
(869, 157, '_wp_trash_meta_time', '1729710581'),
(870, 157, '_wp_desired_post_slug', 'field_671947a75f260'),
(871, 158, '_wp_trash_meta_status', 'publish'),
(872, 158, '_wp_trash_meta_time', '1729710582'),
(873, 158, '_wp_desired_post_slug', 'field_671947a75f64b'),
(874, 159, '_wp_trash_meta_status', 'publish'),
(875, 159, '_wp_trash_meta_time', '1729710583'),
(876, 159, '_wp_desired_post_slug', 'field_671947a75fa76'),
(877, 160, '_wp_trash_meta_status', 'publish'),
(878, 160, '_wp_trash_meta_time', '1729710584'),
(879, 160, '_wp_desired_post_slug', 'field_671947a75fe1c'),
(880, 163, '_wp_trash_meta_status', 'publish'),
(881, 163, '_wp_trash_meta_time', '1729710585'),
(882, 163, '_wp_desired_post_slug', 'field_671947a760204'),
(883, 164, '_wp_trash_meta_status', 'publish'),
(884, 164, '_wp_trash_meta_time', '1729710586'),
(885, 164, '_wp_desired_post_slug', 'field_671947a7605ec'),
(886, 165, '_wp_trash_meta_status', 'publish'),
(887, 165, '_wp_trash_meta_time', '1729710587'),
(888, 165, '_wp_desired_post_slug', 'field_671947a760a0c'),
(889, 22, '_yoast_wpseo_content_score', '90'),
(890, 25, '_yoast_wpseo_content_score', '90'),
(891, 174, '_form', '<div class="input-group"><label for="name">Your Full name* </label>[text* your-name id:name placeholder "type here"]<span class="focus-border"></span><div class="input-group"><label for="email">email address*</label>[email* your-email id:email placeholder "type here"]<span class="focus-border"></span></div><div class="input-group"><label for="phone">Phone Number</label>[tel* tel-513 id:phone placeholder "type here"]<span class="focus-border"></span></div><div class="input-group"><label for="message">Message</label>[textarea* textarea-568 id:message placeholder "type here"]<span class="focus-border"></span></div>[submit "Send Message"]'),
(892, 174, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:36:"[_site_title] <deepsonart@gmail.com>";s:9:"recipient";s:19:"[_site_admin_email]";s:4:"body";s:161:"From: [your-name] [your-email]\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(893, 174, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:36:"[_site_title] <deepsonart@gmail.com>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:105:"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])";s:18:"additional_headers";s:29:"Reply-To: [_site_admin_email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(894, 174, '_messages', 'a:22:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:27:"Please fill out this field.";s:16:"invalid_too_long";s:32:"This field has a too long input.";s:17:"invalid_too_short";s:33:"This field has a too short input.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:31:"The uploaded file is too large.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";s:12:"invalid_date";s:41:"Please enter a date in YYYY-MM-DD format.";s:14:"date_too_early";s:32:"This field has a too early date.";s:13:"date_too_late";s:31:"This field has a too late date.";s:14:"invalid_number";s:22:"Please enter a number.";s:16:"number_too_small";s:34:"This field has a too small number.";s:16:"number_too_large";s:34:"This field has a too large number.";s:23:"quiz_answer_not_correct";s:36:"The answer to the quiz is incorrect.";s:13:"invalid_email";s:30:"Please enter an email address.";s:11:"invalid_url";s:19:"Please enter a URL.";s:11:"invalid_tel";s:32:"Please enter a telephone number.";}'),
(895, 174, '_additional_settings', ''),
(896, 174, '_locale', 'en_US'),
(900, 20, '_yoast_wpseo_content_score', '90'),
(901, 176, '_edit_last', '1'),
(902, 176, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(903, 176, '_yoast_wpseo_wordproof_timestamp', ''),
(904, 176, '_edit_lock', '1730734687:1'),
(905, 178, '_wp_attached_file', '2024/10/detailed-one.jpg'),
(906, 178, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:583;s:6:"height";i:1054;s:4:"file";s:24:"2024/10/detailed-one.jpg";s:8:"filesize";i:318208;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:24:"detailed-one-166x300.jpg";s:5:"width";i:166;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8685;}s:5:"large";a:5:{s:4:"file";s:25:"detailed-one-566x1024.jpg";s:5:"width";i:566;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:55288;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"detailed-one-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4698;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(907, 176, '_thumbnail_id', '178'),
(908, 176, '_yoast_wpseo_content_score', '90'),
(909, 182, '_edit_last', '1'),
(910, 182, '_edit_lock', '1729857508:1'),
(911, 189, '_wp_attached_file', '2024/10/img-seven.jpg'),
(912, 189, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:550;s:6:"height";i:517;s:4:"file";s:21:"2024/10/img-seven.jpg";s:8:"filesize";i:209466;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:21:"img-seven-300x282.jpg";s:5:"width";i:300;s:6:"height";i:282;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16588;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"img-seven-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6617;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(913, 190, '_wp_attached_file', '2024/10/detailed-three.jpg'),
(914, 190, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:300;s:6:"height";i:332;s:4:"file";s:26:"2024/10/detailed-three.jpg";s:8:"filesize";i:48627;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:26:"detailed-three-271x300.jpg";s:5:"width";i:271;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7779;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"detailed-three-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3516;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(915, 191, '_wp_attached_file', '2024/10/detailed-two.jpg'),
(916, 191, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:267;s:6:"height";i:332;s:4:"file";s:24:"2024/10/detailed-two.jpg";s:8:"filesize";i:44108;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:24:"detailed-two-241x300.jpg";s:5:"width";i:241;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7360;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"detailed-two-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3681;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(917, 176, 'outfit_thumbnail_image', '189'),
(918, 176, '_outfit_thumbnail_image', 'field_6719d47790076'),
(919, 176, 'outfit_position', 'Business Casual'),
(920, 176, '_outfit_position', 'field_6719d53390077'),
(921, 176, 'outfit_gallery_images_0_gal_image', '191'),
(922, 176, '_outfit_gallery_images_0_gal_image', 'field_6719d5a79007b'),
(923, 176, 'outfit_gallery_images_1_gal_image', '190'),
(924, 176, '_outfit_gallery_images_1_gal_image', 'field_6719d5a79007b'),
(925, 176, 'outfit_gallery_images', '2'),
(926, 176, '_outfit_gallery_images', 'field_6719d58e9007a'),
(927, 181, 'outfit_thumbnail_image', '189'),
(928, 181, '_outfit_thumbnail_image', 'field_6719d47790076'),
(929, 181, 'outfit_position', 'Business Casual') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(930, 181, '_outfit_position', 'field_6719d53390077'),
(931, 181, 'outfit_gallery_images_0_gal_image', '191'),
(932, 181, '_outfit_gallery_images_0_gal_image', 'field_6719d5a79007b'),
(933, 181, 'outfit_gallery_images_1_gal_image', '190'),
(934, 181, '_outfit_gallery_images_1_gal_image', 'field_6719d5a79007b'),
(935, 181, 'outfit_gallery_images', '2'),
(936, 181, '_outfit_gallery_images', 'field_6719d58e9007a'),
(937, 192, 'outfit_thumbnail_image', '189'),
(938, 192, '_outfit_thumbnail_image', 'field_6719d47790076'),
(939, 192, 'outfit_position', 'Business Casual'),
(940, 192, '_outfit_position', 'field_6719d53390077'),
(941, 192, 'outfit_gallery_images_0_gal_image', '191'),
(942, 192, '_outfit_gallery_images_0_gal_image', 'field_6719d5a79007b'),
(943, 192, 'outfit_gallery_images_1_gal_image', '190'),
(944, 192, '_outfit_gallery_images_1_gal_image', 'field_6719d5a79007b'),
(945, 192, 'outfit_gallery_images', '2'),
(946, 192, '_outfit_gallery_images', 'field_6719d58e9007a'),
(947, 197, '_wp_attached_file', '2024/10/detailed-five.jpg'),
(948, 197, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:371;s:6:"height";i:351;s:4:"file";s:25:"2024/10/detailed-five.jpg";s:8:"filesize";i:38092;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:25:"detailed-five-300x284.jpg";s:5:"width";i:300;s:6:"height";i:284;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6564;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"detailed-five-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2727;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(949, 198, '_wp_attached_file', '2024/10/detailed-four-1.jpg'),
(950, 198, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:371;s:6:"height";i:351;s:4:"file";s:27:"2024/10/detailed-four-1.jpg";s:8:"filesize";i:55621;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:27:"detailed-four-1-300x284.jpg";s:5:"width";i:300;s:6:"height";i:284;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14618;}s:9:"thumbnail";a:5:{s:4:"file";s:27:"detailed-four-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6695;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(951, 199, '_wp_attached_file', '2024/10/detailed-six.jpg'),
(952, 199, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:371;s:6:"height";i:351;s:4:"file";s:24:"2024/10/detailed-six.jpg";s:8:"filesize";i:47116;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:24:"detailed-six-300x284.jpg";s:5:"width";i:300;s:6:"height";i:284;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8823;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"detailed-six-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4201;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(953, 176, 'outfit_ideas_0_outfit_idea_image', '198'),
(954, 176, '_outfit_ideas_0_outfit_idea_image', 'field_6719d688066ba'),
(955, 176, 'outfit_ideas_0_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(956, 176, '_outfit_ideas_0_oufit_idea_details', 'field_6719d6af066bb'),
(957, 176, 'outfit_ideas_1_outfit_idea_image', '197'),
(958, 176, '_outfit_ideas_1_outfit_idea_image', 'field_6719d688066ba'),
(959, 176, 'outfit_ideas_1_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(960, 176, '_outfit_ideas_1_oufit_idea_details', 'field_6719d6af066bb'),
(961, 176, 'outfit_ideas_2_outfit_idea_image', '199'),
(962, 176, '_outfit_ideas_2_outfit_idea_image', 'field_6719d688066ba'),
(963, 176, 'outfit_ideas_2_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(964, 176, '_outfit_ideas_2_oufit_idea_details', 'field_6719d6af066bb'),
(965, 176, 'outfit_ideas', '3'),
(966, 176, '_outfit_ideas', 'field_6719d66e066b9'),
(967, 192, 'outfit_ideas_0_outfit_idea_image', '198'),
(968, 192, '_outfit_ideas_0_outfit_idea_image', 'field_6719d688066ba'),
(969, 192, 'outfit_ideas_0_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(970, 192, '_outfit_ideas_0_oufit_idea_details', 'field_6719d6af066bb'),
(971, 192, 'outfit_ideas_1_outfit_idea_image', '197'),
(972, 192, '_outfit_ideas_1_outfit_idea_image', 'field_6719d688066ba'),
(973, 192, 'outfit_ideas_1_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(974, 192, '_outfit_ideas_1_oufit_idea_details', 'field_6719d6af066bb'),
(975, 192, 'outfit_ideas_2_outfit_idea_image', '199'),
(976, 192, '_outfit_ideas_2_outfit_idea_image', 'field_6719d688066ba'),
(977, 192, 'outfit_ideas_2_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(978, 192, '_outfit_ideas_2_oufit_idea_details', 'field_6719d6af066bb'),
(979, 192, 'outfit_ideas', '3'),
(980, 192, '_outfit_ideas', 'field_6719d66e066b9'),
(981, 201, '_edit_last', '1'),
(982, 201, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(983, 201, '_yoast_wpseo_wordproof_timestamp', ''),
(984, 201, '_edit_lock', '1730791951:1'),
(985, 201, '_thumbnail_id', '178'),
(986, 201, '_yoast_wpseo_content_score', '90'),
(987, 201, 'outfit_thumbnail_image', '203'),
(988, 201, '_outfit_thumbnail_image', 'field_6719d47790076'),
(989, 201, 'outfit_position', 'Business Casual'),
(990, 201, '_outfit_position', 'field_6719d53390077'),
(991, 201, 'outfit_gallery_images_0_gal_image', '191'),
(992, 201, '_outfit_gallery_images_0_gal_image', 'field_6719d5a79007b'),
(993, 201, 'outfit_gallery_images_1_gal_image', '190'),
(994, 201, '_outfit_gallery_images_1_gal_image', 'field_6719d5a79007b'),
(995, 201, 'outfit_gallery_images', '2'),
(996, 201, '_outfit_gallery_images', 'field_6719d58e9007a'),
(997, 201, 'outfit_ideas_0_outfit_idea_image', '198'),
(998, 201, '_outfit_ideas_0_outfit_idea_image', 'field_6719d688066ba'),
(999, 201, 'outfit_ideas_0_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1000, 201, '_outfit_ideas_0_oufit_idea_details', 'field_6719d6af066bb'),
(1001, 201, 'outfit_ideas_1_outfit_idea_image', '197'),
(1002, 201, '_outfit_ideas_1_outfit_idea_image', 'field_6719d688066ba'),
(1003, 201, 'outfit_ideas_1_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1004, 201, '_outfit_ideas_1_oufit_idea_details', 'field_6719d6af066bb'),
(1005, 201, 'outfit_ideas_2_outfit_idea_image', '199'),
(1006, 201, '_outfit_ideas_2_outfit_idea_image', 'field_6719d688066ba'),
(1007, 201, 'outfit_ideas_2_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1008, 201, '_outfit_ideas_2_oufit_idea_details', 'field_6719d6af066bb'),
(1009, 201, 'outfit_ideas', '3'),
(1010, 201, '_outfit_ideas', 'field_6719d66e066b9'),
(1011, 201, '_wp_old_slug', 'kristen-osborne-copy'),
(1012, 203, '_wp_attached_file', '2024/10/img-six.jpg'),
(1013, 203, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:551;s:6:"height";i:517;s:4:"file";s:19:"2024/10/img-six.jpg";s:8:"filesize";i:229486;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:19:"img-six-300x281.jpg";s:5:"width";i:300;s:6:"height";i:281;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17496;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"img-six-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6860;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1014, 202, 'outfit_thumbnail_image', '203'),
(1015, 202, '_outfit_thumbnail_image', 'field_6719d47790076'),
(1016, 202, 'outfit_position', 'Business Casual'),
(1017, 202, '_outfit_position', 'field_6719d53390077'),
(1018, 202, 'outfit_gallery_images_0_gal_image', '191'),
(1019, 202, '_outfit_gallery_images_0_gal_image', 'field_6719d5a79007b'),
(1020, 202, 'outfit_gallery_images_1_gal_image', '190'),
(1021, 202, '_outfit_gallery_images_1_gal_image', 'field_6719d5a79007b'),
(1022, 202, 'outfit_gallery_images', '2'),
(1023, 202, '_outfit_gallery_images', 'field_6719d58e9007a'),
(1024, 202, 'outfit_ideas_0_outfit_idea_image', '198'),
(1025, 202, '_outfit_ideas_0_outfit_idea_image', 'field_6719d688066ba'),
(1026, 202, 'outfit_ideas_0_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1027, 202, '_outfit_ideas_0_oufit_idea_details', 'field_6719d6af066bb'),
(1028, 202, 'outfit_ideas_1_outfit_idea_image', '197'),
(1029, 202, '_outfit_ideas_1_outfit_idea_image', 'field_6719d688066ba') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1030, 202, 'outfit_ideas_1_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1031, 202, '_outfit_ideas_1_oufit_idea_details', 'field_6719d6af066bb'),
(1032, 202, 'outfit_ideas_2_outfit_idea_image', '199'),
(1033, 202, '_outfit_ideas_2_outfit_idea_image', 'field_6719d688066ba'),
(1034, 202, 'outfit_ideas_2_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1035, 202, '_outfit_ideas_2_oufit_idea_details', 'field_6719d6af066bb'),
(1036, 202, 'outfit_ideas', '3'),
(1037, 202, '_outfit_ideas', 'field_6719d66e066b9'),
(1038, 205, '_edit_last', '1'),
(1039, 205, '_edit_lock', '1729837628:1'),
(1042, 205, '_thumbnail_id', '106'),
(1043, 205, '_yoast_wpseo_content_score', '30'),
(1044, 205, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(1045, 205, '_yoast_wpseo_wordproof_timestamp', ''),
(1046, 208, '_edit_last', '1'),
(1047, 208, '_edit_lock', '1729837537:1'),
(1048, 208, '_thumbnail_id', '84'),
(1049, 208, '_yoast_wpseo_content_score', '60'),
(1050, 208, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(1051, 208, '_yoast_wpseo_wordproof_timestamp', ''),
(1052, 208, '_wp_old_slug', 'building-a-brand-identity-copy'),
(1053, 210, '_edit_last', '1'),
(1054, 210, '_edit_lock', '1729857273:1'),
(1055, 210, '_wp_page_template', 'template-stylingcontact.php'),
(1056, 210, '_yoast_wpseo_content_score', '90'),
(1057, 210, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(1058, 210, '_yoast_wpseo_wordproof_timestamp', ''),
(1059, 212, '_edit_lock', '1729756036:1'),
(1060, 212, '_wp_trash_meta_status', 'publish'),
(1061, 212, '_wp_trash_meta_time', '1729756038'),
(1062, 213, '_wp_attached_file', '2024/10/lune.png'),
(1063, 213, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:16:"2024/10/lune.png";s:8:"filesize";i:50936;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:16:"lune-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:42125;}s:9:"thumbnail";a:5:{s:4:"file";s:16:"lune-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:15208;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1064, 214, '_wp_attached_file', '2024/10/cropped-lune.png'),
(1065, 214, '_wp_attachment_context', 'site-icon'),
(1066, 214, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:24:"2024/10/cropped-lune.png";s:8:"filesize";i:56992;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"cropped-lune-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:42125;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"cropped-lune-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:15208;}s:13:"site_icon-270";a:5:{s:4:"file";s:24:"cropped-lune-270x270.png";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:36045;}s:13:"site_icon-192";a:5:{s:4:"file";s:24:"cropped-lune-192x192.png";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21646;}s:13:"site_icon-180";a:5:{s:4:"file";s:24:"cropped-lune-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:19695;}s:12:"site_icon-32";a:5:{s:4:"file";s:22:"cropped-lune-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1277;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1067, 215, '_wp_trash_meta_status', 'publish'),
(1068, 215, '_wp_trash_meta_time', '1729756130'),
(1069, 216, '_wp_attached_file', '2024/10/contact-image.jpg'),
(1070, 216, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:438;s:6:"height";i:587;s:4:"file";s:25:"2024/10/contact-image.jpg";s:8:"filesize";i:317724;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:25:"contact-image-224x300.jpg";s:5:"width";i:224;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19636;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"contact-image-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7531;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1071, 25, '_thumbnail_id', '216'),
(1072, 108, 'banner_logo', '58'),
(1073, 108, '_banner_logo', 'field_67188d83f2f1a'),
(1074, 108, 'banner_text', 'Curated Styling Journeys'),
(1075, 108, '_banner_text', 'field_67188e79f2f1b'),
(1076, 108, 'banner_image', '59'),
(1077, 108, '_banner_image', 'field_67188e8cf2f1c'),
(1078, 108, 'banner_content', 'Personalized Styling experiences that weave together grace and practicality, ensuring you radiate confidence and beauty in every moment.'),
(1079, 108, '_banner_content', 'field_67188eb9f2f1d'),
(1080, 108, 'service_content', 'At Lune by Bhagya, we see personal style as more than mere clothing—it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.'),
(1081, 108, '_service_content', 'field_67188ef9f2f1e'),
(1082, 108, 'link_text', 'See Styling Services'),
(1083, 108, '_link_text', 'field_67188f85f2f1f'),
(1084, 108, 'link_url', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(1085, 108, '_link_url', 'field_67188f94f2f20'),
(1086, 108, 'big_text_0_b_text', 'Styling Packages'),
(1087, 108, '_big_text_0_b_text', 'field_6718934d94f76'),
(1088, 108, 'big_text_1_b_text', 'Styling Packages'),
(1089, 108, '_big_text_1_b_text', 'field_6718934d94f76'),
(1090, 108, 'big_text', '2'),
(1091, 108, '_big_text', 'field_671892dc94f75'),
(1092, 108, 'small_text_0_s_text', 'Virtual Personal Styling'),
(1093, 108, '_small_text_0_s_text', 'field_671893d794f78'),
(1094, 108, 'small_text_1_s_text', 'Sessions Wardrobe Audit'),
(1095, 108, '_small_text_1_s_text', 'field_671893d794f78'),
(1096, 108, 'small_text_2_s_text', 'Styling Consultations Long-Term'),
(1097, 108, '_small_text_2_s_text', 'field_671893d794f78'),
(1098, 108, 'small_text_3_s_text', 'Styling Packages editorial styling services'),
(1099, 108, '_small_text_3_s_text', 'field_671893d794f78'),
(1100, 108, 'small_text', '4'),
(1101, 108, '_small_text', 'field_6718937b94f77'),
(1102, 108, 'packages_0_package_image', '76'),
(1103, 108, '_packages_0_package_image', 'field_67192d92f4ece'),
(1104, 108, 'packages_0_package_name', 'entry package - Silver'),
(1105, 108, '_packages_0_package_name', 'field_67192db2f4ecf'),
(1106, 108, 'packages_0_package_content', 'A single, curated lookbook Delivery in 48 hrs'),
(1107, 108, '_packages_0_package_content', 'field_67192dc8f4ed0'),
(1108, 108, 'packages_0_package_price', '$75 / Rs. 3000'),
(1109, 108, '_packages_0_package_price', 'field_67192deaf4ed1'),
(1110, 108, 'packages_0_book_link', '#'),
(1111, 108, '_packages_0_book_link', 'field_67192df7f4ed2'),
(1112, 108, 'packages_1_package_image', '75'),
(1113, 108, '_packages_1_package_image', 'field_67192d92f4ece'),
(1114, 108, 'packages_1_package_name', 'Signature package - Gold'),
(1115, 108, '_packages_1_package_name', 'field_67192db2f4ecf'),
(1116, 108, 'packages_1_package_content', '3 expertly crafted lookbooks Delivery in 3 days'),
(1117, 108, '_packages_1_package_content', 'field_67192dc8f4ed0'),
(1118, 108, 'packages_1_package_price', '$200 / Rs. 5000'),
(1119, 108, '_packages_1_package_price', 'field_67192deaf4ed1'),
(1120, 108, 'packages_1_book_link', '#'),
(1121, 108, '_packages_1_book_link', 'field_67192df7f4ed2'),
(1122, 108, 'packages_2_package_image', '74'),
(1123, 108, '_packages_2_package_image', 'field_67192d92f4ece'),
(1124, 108, 'packages_2_package_name', 'Ultimate package - Diamond'),
(1125, 108, '_packages_2_package_name', 'field_67192db2f4ecf'),
(1126, 108, 'packages_2_package_content', '5 meticulously curated lookbooks - Delivery in 5 days'),
(1127, 108, '_packages_2_package_content', 'field_67192dc8f4ed0'),
(1128, 108, 'packages_2_package_price', '$350 / Rs. 10,000'),
(1129, 108, '_packages_2_package_price', 'field_67192deaf4ed1'),
(1130, 108, 'packages_2_book_link', '#'),
(1131, 108, '_packages_2_book_link', 'field_67192df7f4ed2') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1132, 108, 'packages', '3'),
(1133, 108, '_packages', 'field_67192d3ef4ecd'),
(1134, 108, 'pk_button_text', 'see all styling services'),
(1135, 108, '_pk_button_text', 'field_671930ab9e49a'),
(1136, 108, 'pk_button_link', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(1137, 108, '_pk_button_link', 'field_671930b89e49b'),
(1138, 108, 'video_image', '84'),
(1139, 108, '_video_image', 'field_67193185af906'),
(1140, 108, 'add_video', '85'),
(1141, 108, '_add_video', 'field_67193152af905'),
(1142, 108, 'testi_title', 'real stories'),
(1143, 108, '_testi_title', 'field_6719327a5dbbd'),
(1144, 108, 'testi_image', '106'),
(1145, 108, '_testi_image', 'field_671932d95dbbe'),
(1146, 108, 'testi_image_text', 'Real Style Transformations'),
(1147, 108, '_testi_image_text', 'field_671932ef5dbbf'),
(1148, 108, 'testi_content', 'Working with Lune by Bhagya was a transformative experience! The lookbook I received perfectly captured my style and boosted my confidence for my upcoming event. I can\'t thank Bhagya enough for her expertise!'),
(1149, 108, '_testi_content', 'field_6719330e5dbc0'),
(1150, 108, 'testi_name', 'Sofia M.'),
(1151, 108, '_testi_name', 'field_671933285dbc1'),
(1152, 108, 'in_title', 'Insights   Inspiration '),
(1153, 108, '_in_title', 'field_6719337767360'),
(1154, 108, 'home_insights_0_in_head', 'The Art of Lookbooks: Why They’re Essential for Every Fashionista'),
(1155, 108, '_home_insights_0_in_head', 'field_671933b367362'),
(1156, 108, 'home_insights_0_in_link', 'a:3:{s:5:"title";s:25:"Building a Brand Identity";s:3:"url";s:62:"https://localhost/luna/site/blogs/building-a-brand-identity-1/";s:6:"target";s:0:"";}'),
(1157, 108, '_home_insights_0_in_link', 'field_671933c567363'),
(1158, 108, 'home_insights_1_in_head', 'the importance of body shape and color analysis, and how to create versatile outfits'),
(1159, 108, '_home_insights_1_in_head', 'field_671933b367362'),
(1160, 108, 'home_insights_1_in_link', 'a:3:{s:5:"title";s:25:"Building a Brand Identity";s:3:"url";s:60:"https://localhost/luna/site/blogs/building-a-brand-identity/";s:6:"target";s:0:"";}'),
(1161, 108, '_home_insights_1_in_link', 'field_671933c567363'),
(1162, 108, 'home_insights', '2'),
(1163, 108, '_home_insights', 'field_6719339867361'),
(1164, 108, 'blog_title', 'Related Blogs'),
(1165, 108, '_blog_title', 'field_67193450dadcb'),
(1166, 108, 'rel_blogs_0_blog_image', '107'),
(1167, 108, '_rel_blogs_0_blog_image', 'field_6719347fdadcd'),
(1168, 108, 'rel_blogs_0_blog_date', '20240910'),
(1169, 108, '_rel_blogs_0_blog_date', 'field_671934a3dadce'),
(1170, 108, 'rel_blogs_0_b_title', 'Building a Brand Identity'),
(1171, 108, '_rel_blogs_0_b_title', 'field_671934d9dadcf'),
(1172, 108, 'rel_blogs_0_blog_content', 'This post could delve into the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity.'),
(1173, 108, '_rel_blogs_0_blog_content', 'field_671934eddadd0'),
(1174, 108, 'rel_blogs_0_blog_link', ''),
(1175, 108, '_rel_blogs_0_blog_link', 'field_67193500dadd1'),
(1176, 108, 'rel_blogs', '1'),
(1177, 108, '_rel_blogs', 'field_67193465dadcc'),
(1178, 218, '_edit_last', '1'),
(1179, 218, '_edit_lock', '1729837979:1'),
(1180, 36, 'page_title', 'Blogs'),
(1181, 36, '_page_title', 'field_671a5393b6210'),
(1182, 36, 'scrolling_text_0_sc_text', 'Updates and Inspirations'),
(1183, 36, '_scrolling_text_0_sc_text', 'field_671a53f3b6212'),
(1184, 36, 'scrolling_text_1_sc_text', 'Updates and Inspirations'),
(1185, 36, '_scrolling_text_1_sc_text', 'field_671a53f3b6212'),
(1186, 36, 'scrolling_text', '2'),
(1187, 36, '_scrolling_text', 'field_671a53a1b6211'),
(1188, 37, 'page_title', 'Blogs'),
(1189, 37, '_page_title', 'field_671a5393b6210'),
(1190, 37, 'scrolling_text_0_sc_text', 'Updates and Inspirations'),
(1191, 37, '_scrolling_text_0_sc_text', 'field_671a53f3b6212'),
(1192, 37, 'scrolling_text_1_sc_text', 'Updates and Inspirations'),
(1193, 37, '_scrolling_text_1_sc_text', 'field_671a53f3b6212'),
(1194, 37, 'scrolling_text', '2'),
(1195, 37, '_scrolling_text', 'field_671a53a1b6211'),
(1196, 223, '_menu_item_type', 'post_type'),
(1197, 223, '_menu_item_menu_item_parent', '0'),
(1198, 223, '_menu_item_object_id', '210'),
(1199, 223, '_menu_item_object', 'page'),
(1200, 223, '_menu_item_target', ''),
(1201, 223, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1202, 223, '_menu_item_xfn', ''),
(1203, 223, '_menu_item_url', ''),
(1205, 32, '_wp_old_date', '2024-10-23'),
(1206, 29, '_wp_old_date', '2024-10-23'),
(1207, 35, '_wp_old_date', '2024-10-23'),
(1208, 125, '_wp_old_date', '2024-10-23'),
(1209, 33, '_wp_old_date', '2024-10-23'),
(1210, 31, '_wp_old_date', '2024-10-23'),
(1211, 30, '_wp_old_date', '2024-10-23'),
(1212, 224, '_menu_item_type', 'post_type'),
(1213, 224, '_menu_item_menu_item_parent', '0'),
(1214, 224, '_menu_item_object_id', '36'),
(1215, 224, '_menu_item_object', 'page'),
(1216, 224, '_menu_item_target', ''),
(1217, 224, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1218, 224, '_menu_item_xfn', ''),
(1219, 224, '_menu_item_url', ''),
(1221, 46, '_wp_old_date', '2024-10-23'),
(1222, 39, '_wp_old_date', '2024-10-23'),
(1223, 44, '_wp_old_date', '2024-10-23'),
(1224, 45, '_wp_old_date', '2024-10-23'),
(1225, 43, '_wp_old_date', '2024-10-23'),
(1226, 42, '_wp_old_date', '2024-10-23'),
(1227, 40, '_wp_old_date', '2024-10-23'),
(1228, 41, '_wp_old_date', '2024-10-23'),
(1229, 208, '_wp_old_slug', 'building-a-brand-identity-1'),
(1230, 205, '_wp_old_slug', 'building-a-brand-identity'),
(1231, 113, '_wp_attachment_backup_sizes', 'a:3:{s:9:"full-orig";a:3:{s:5:"width";i:457;s:6:"height";i:644;s:4:"file";s:14:"about-page.jpg";}s:14:"thumbnail-orig";a:5:{s:4:"file";s:22:"about-page-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7229;}s:11:"medium-orig";a:5:{s:4:"file";s:22:"about-page-213x300.jpg";s:5:"width";i:213;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17107;}}'),
(1232, 230, '_edit_last', '1'),
(1233, 230, '_edit_lock', '1729837984:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1234, 208, 'blog_date', '20240910'),
(1235, 208, '_blog_date', 'field_671b3a1ab62ed'),
(1236, 226, 'blog_date', '20240910'),
(1237, 226, '_blog_date', 'field_671b3a1ab62ed'),
(1238, 205, 'blog_date', '20240910'),
(1239, 205, '_blog_date', 'field_671b3a1ab62ed'),
(1240, 228, 'blog_date', '20240910'),
(1241, 228, '_blog_date', 'field_671b3a1ab62ed'),
(1242, 234, '_edit_last', '1'),
(1243, 234, '_edit_lock', '1729844374:1'),
(1244, 22, 'page_title', 'FAQ'),
(1245, 22, '_page_title', 'field_671b3dac2232c'),
(1246, 22, 'det_faqs_0_faq_question', 'What is your return policy?'),
(1247, 22, '_det_faqs_0_faq_question', 'field_671b3e862232e'),
(1248, 22, 'det_faqs_0_faq_answer', 'We offer a 30-day return policy on all items. Please ensure that the items are in their original condition and packaging.'),
(1249, 22, '_det_faqs_0_faq_answer', 'field_671b3ea52232f'),
(1250, 22, 'det_faqs_1_faq_question', 'Do you offer international shipping?'),
(1251, 22, '_det_faqs_1_faq_question', 'field_671b3e862232e'),
(1252, 22, 'det_faqs_1_faq_answer', 'Yes, we ship to most countries around the world. Shipping fees and delivery times vary by location.'),
(1253, 22, '_det_faqs_1_faq_answer', 'field_671b3ea52232f'),
(1254, 22, 'det_faqs_2_faq_question', 'How can I track my order?'),
(1255, 22, '_det_faqs_2_faq_question', 'field_671b3e862232e'),
(1256, 22, 'det_faqs_2_faq_answer', 'Once your order has shipped, you will receive an email with a tracking link to monitor the status of your delivery'),
(1257, 22, '_det_faqs_2_faq_answer', 'field_671b3ea52232f'),
(1258, 22, 'det_faqs', '3'),
(1259, 22, '_det_faqs', 'field_671b3e662232d'),
(1260, 172, 'page_title', 'FAQ'),
(1261, 172, '_page_title', 'field_671b3dac2232c'),
(1262, 172, 'det_faqs_0_faq_question', 'What is your return policy?'),
(1263, 172, '_det_faqs_0_faq_question', 'field_671b3e862232e'),
(1264, 172, 'det_faqs_0_faq_answer', 'We offer a 30-day return policy on all items. Please ensure that the items are in their original condition and packaging.'),
(1265, 172, '_det_faqs_0_faq_answer', 'field_671b3ea52232f'),
(1266, 172, 'det_faqs_1_faq_question', 'Do you offer international shipping?'),
(1267, 172, '_det_faqs_1_faq_question', 'field_671b3e862232e'),
(1268, 172, 'det_faqs_1_faq_answer', 'Yes, we ship to most countries around the world. Shipping fees and delivery times vary by location.'),
(1269, 172, '_det_faqs_1_faq_answer', 'field_671b3ea52232f'),
(1270, 172, 'det_faqs_2_faq_question', 'How can I track my order?'),
(1271, 172, '_det_faqs_2_faq_question', 'field_671b3e862232e'),
(1272, 172, 'det_faqs_2_faq_answer', 'Once your order has shipped, you will receive an email with a tracking link to monitor the status of your delivery'),
(1273, 172, '_det_faqs_2_faq_answer', 'field_671b3ea52232f'),
(1274, 172, 'det_faqs', '3'),
(1275, 172, '_det_faqs', 'field_671b3e662232d'),
(1276, 240, '_form', '<div class="input-group">\n                <label for="name">Your Email* </label>[email* email-760 id:email placeholder "type here"]<span class="focus-border"></span>\n            </div>\n              <div class="input-group">\n                <label for="name">What is your name and occupation?* </label>[text* text-name id:name "type here"]<span class="focus-border"></span>\n            </div>\n            <div class="input-group">\n<label for="name">Please mention your height, weight, and skin complexion* </label>[text* text-height id:height "type here"]<span class="focus-border"></span>\n            </div>\n            <div class="input-group">\n                <label for="name">What is the occasion for which you need me to style you? Is it an event, a life episode, etc.? </label>[text* text-style id:style "type here"]<span class="focus-border"></span>\n            </div>\n            <div class="input-group">\n                <label for="name">Is there a theme or color palette to follow for the occasion/life series? If yes, please describe.  </label>[text* text-theme id:theme "type here"]<span class="focus-border"></span>\n            </div>\n            <div class="input-group">\n                <label for="name">Do you need links to buy, or just a picture-focused lookbook?* </label>[text* text-link placeholder "Upload 1 supported file: image. Max 100 MB."]<label for="file-upload" class="custom-file-upload">upload</label>[file file-lookbook limit:10mb filetypes:jpg|png id:look]<span class="focus-border"></span>\n            </div>            \n            <p>How would you describe your body shape?</p> \n             <div class="radio-group">\n[radio radio-bodyshape use_label_element default:1 "straight (more or less rectangular)" "triangle (narrow shoulders and wider hips)" "pear (narrow torso and wider hips)" "hourglass (wide shoulders and hips with a smaller waist)" "apple (narrow shoulders and hips with a wider middle portion)" "inverted triangle (wide shoulders and narrow hips)" "i\'m not sure"]        \n    </div>       \n       <p>Please provide an approximate list of your main measurements (Tip: The size of the top/shirt you usually buy will give you your shoulder/bust measurements, the size of the bottom wear will give you your waist/hip measurements) Alternatively, you can list the sizes of the top wear, bottom wear, footwear that you usually wear. Provide: Shoulder, bust, waist, hip, foot length </p>\n       <div class="input-group">\n[text* text-measurements id:measurements placeholder "type here"]<span class="focus-border"></span>\n            </div>\n            <div class="input-group">\n              <label for="name">Is there any part of your body that you are insecure about and would like not highlighted? E.g. a tummy, bulky arms, a heavy bust. etc.?</label>[text* text-insecure id:insecure placeholder "type here"]<span class="focus-border"></span>\n            </div>\n            <div class="input-group">\n              <label for="name">Is there any part of your body that you love and would like highlighted?E.g. your height, legs, arms. etc.?</label>[text* text-highlight id:highlight placeholder "type here"]<span class="focus-border"></span>\n            </div>\n                  <div class="input-group">\n              <label for="name">What are some brands and department stores you regularly purchase from? (E.g. Zara, ASOS, Nordstorm)</label>[text* text-brands id:brands placeholder "type here"]\n                <span class="focus-border"></span>\n            </div>\n             <div class="input-group">\n              <label for="name">If you are comfortable, please leave the name of the city and country you live in. This will help me curate products online that are available in your city.</label>[text* text-city id:city placeholder "type here"]<span class="focus-border"></span>\n            </div>\n            <div class="input-group">\n              <label for="name">Would you prefer a dressed up or a dressed down look for the occasion?*</label>[text* text-prefer id:prefer placeholder "type here"]<span class="focus-border"></span>\n            </div>\n              <div class="input-group">\n              <label for="name">Would you call yourself a minimalist (fewer accessories and details), or a maximalist (more accessories and details)?*</label>[text* text-call id:call placeholder "type here"]<span class="focus-border"></span>\n            </div>            \n            <p>What are some colors you typically incline towards. A quick look in your wardrobe will give you an idea.</p>\n            <div class="checkbox-container">\n[checkbox checkbox-colors use_label_element "i agree to the terms and conditions" "cool tones - blues, purples, greens" "colorful - colorful prints, outfits in many colors" "warm tones - yellows, oranges, reds"]       \n            </div>\n             <div class="input-group">\n              <label for="name">For the occasion, would you like to maintain your personal style or try something different?*</label>[text* text-maintain id:maintain placeholder "type here"]<span class="focus-border"></span>\n            </div>\n              <div class="radio-group">\n              <p>How comfortable are you to step out of your comfort zone?*</p>      \n        [radio radio-comfortzone id:comfirtzone use_label_element default:1 "not at all" "1" "2" "3" "4" "5" "quite comfortable - in the mood to experiment and adapt"]   \n    </div>\n           <div class="input-group">\n                <label for="name">If you have a vision in mind, please attach a few reference pictures of looks you can see yourself in. This will help me curate a look that you are more likely to love.</label>[text* text-reference id:reference placeholder "Upload 1 supported file: image. Max 100 MB."]<label for="file-upload" class="custom-file-upload">upload</label>[file file-refpicture limit:10mb filetypes:jpg|png id:refpicture]<span class="focus-border"></span>\n            </div>\n                 <div class="checkbox-container">\n                 <p>For the occasion or life episode, what is your priority?*</p>\n       [checkbox* checkbox-priority id:priority use_label_element "being comfortable and peaceful" "looking stylish and put together" "looking on-trend" "other:"]\n            </div>\n               <div class="radio-group">\n              <p>What is your preferred fit of outfits in general?*</p>   \n       [radio radio-fit id:fit use_label_element default:1 "loose and airy" "well-fitted" "something in between"]                \n    </div>\n            <div class="input-group">\n              <label for="name">Is there any other detail about yourself, your fashion preferences, or your personal requirements for this occasion that you would like me to consider when curating looks for you?*</label>[text* text-detail id:detail placeholder "type here"]<span class="focus-border"></span>\n            </div>\n          \n           \n      [submit "Submit"]'),
(1277, 240, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:36:"[_site_title] <wordpress@mwduat.com>";s:9:"recipient";s:19:"[_site_admin_email]";s:4:"body";s:160:"From: [your-name] [email-760]\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])";s:18:"additional_headers";s:21:"Reply-To: [email-760]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(1278, 240, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:36:"[_site_title] <wordpress@mwduat.com>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:105:"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])";s:18:"additional_headers";s:29:"Reply-To: [_site_admin_email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(1279, 240, '_messages', 'a:22:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:27:"Please fill out this field.";s:16:"invalid_too_long";s:32:"This field has a too long input.";s:17:"invalid_too_short";s:33:"This field has a too short input.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:31:"The uploaded file is too large.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";s:12:"invalid_date";s:41:"Please enter a date in YYYY-MM-DD format.";s:14:"date_too_early";s:32:"This field has a too early date.";s:13:"date_too_late";s:31:"This field has a too late date.";s:14:"invalid_number";s:22:"Please enter a number.";s:16:"number_too_small";s:34:"This field has a too small number.";s:16:"number_too_large";s:34:"This field has a too large number.";s:23:"quiz_answer_not_correct";s:36:"The answer to the quiz is incorrect.";s:13:"invalid_email";s:30:"Please enter an email address.";s:11:"invalid_url";s:19:"Please enter a URL.";s:11:"invalid_tel";s:32:"Please enter a telephone number.";}'),
(1280, 240, '_additional_settings', ''),
(1281, 240, '_locale', 'en_US'),
(1291, 251, '_edit_last', '1'),
(1292, 251, '_edit_lock', '1729856515:1'),
(1293, 25, 'contact_heading', 'Hi I’m<span>Bhagya</span>'),
(1294, 25, '_contact_heading', 'field_671b7da8ebb4f'),
(1295, 173, 'contact_heading', 'Hi I’m<span>Bhagya</span>'),
(1296, 173, '_contact_heading', 'field_671b7da8ebb4f'),
(1297, 253, 'contact_heading', 'Hi I’m<span>Bhagya</span>'),
(1298, 253, '_contact_heading', 'field_671b7da8ebb4f'),
(1299, 25, 'cn_number', '+91 9995 666 333'),
(1300, 25, '_cn_number', 'field_671b7e658f701'),
(1301, 25, 'cn_email_id', 'pingme@lunebybhagya.com'),
(1302, 25, '_cn_email_id', 'field_671b7e868f702'),
(1303, 25, 'form_heading', '—Step into Your Style Story'),
(1304, 25, '_form_heading', 'field_671b7eac8f703'),
(1305, 25, 'contact_form', '[contact-form-7 id="174" title="Contact"]'),
(1306, 25, '_contact_form', 'field_671b7ecc8f704'),
(1307, 253, 'cn_number', '+91 9995 666 333'),
(1308, 253, '_cn_number', 'field_671b7e658f701'),
(1309, 253, 'cn_email_id', 'contact@lune.com'),
(1310, 253, '_cn_email_id', 'field_671b7e868f702'),
(1311, 253, 'form_heading', '—Step into Your Style Story'),
(1312, 253, '_form_heading', 'field_671b7eac8f703'),
(1313, 253, 'contact_form', '[contact-form-7 id="174" title="Contact"]'),
(1314, 253, '_contact_form', 'field_671b7ecc8f704'),
(1315, 258, 'contact_heading', 'Hi I’m<span>Bhagya</span>'),
(1316, 258, '_contact_heading', 'field_671b7da8ebb4f'),
(1317, 258, 'cn_number', '+91 9995 666 333'),
(1318, 258, '_cn_number', 'field_671b7e658f701'),
(1319, 258, 'cn_email_id', 'contact@lune.com'),
(1320, 258, '_cn_email_id', 'field_671b7e868f702'),
(1321, 258, 'form_heading', '—Step into Your Style Story'),
(1322, 258, '_form_heading', 'field_671b7eac8f703'),
(1323, 258, 'contact_form', '[contact-form-7 id="174" title="Contact"]'),
(1324, 258, '_contact_form', 'field_671b7ecc8f704'),
(1325, 25, 'cn_number_icon', '<svg width="40" height="40" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<path d="M44 33.8402V39.8402C44.0022 40.3972 43.8882 40.9485 43.665 41.4589C43.4419 41.9692 43.1146 42.4274 42.7041 42.8039C42.2937 43.1805 41.8091 43.4672 41.2815 43.6456C40.7538 43.8241 40.1947 43.8903 39.64 43.8402C33.4857 43.1715 27.574 41.0685 22.38 37.7002C17.5476 34.6295 13.4507 30.5325 10.38 25.7002C6.99994 20.4826 4.89647 14.5422 4.23999 8.36019C4.19001 7.80713 4.25574 7.24971 4.43299 6.72344C4.61024 6.19717 4.89513 5.71357 5.26952 5.30344C5.64391 4.8933 6.0996 4.56561 6.60757 4.34124C7.11554 4.11686 7.66467 4.00072 8.21999 4.00019H14.22C15.1906 3.99064 16.1316 4.33435 16.8675 4.96726C17.6035 5.60017 18.0841 6.47909 18.22 7.44019C18.4732 9.36033 18.9429 11.2456 19.62 13.0602C19.8891 13.776 19.9473 14.554 19.7878 15.302C19.6283 16.0499 19.2577 16.7364 18.72 17.2802L16.18 19.8202C19.0271 24.8273 23.1729 28.9731 28.18 31.8202L30.72 29.2802C31.2638 28.7425 31.9503 28.3719 32.6982 28.2124C33.4462 28.0529 34.2241 28.1111 34.94 28.3802C36.7545 29.0573 38.6399 29.5269 40.56 29.7802C41.5315 29.9173 42.4188 30.4066 43.0531 31.1552C43.6873 31.9038 44.0243 32.8593 44 33.8402Z" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>\r\n</svg>'),
(1326, 25, '_cn_number_icon', 'field_671b7f41a2988'),
(1327, 25, 'cn_email_icon', '<svg width="51" height="40" viewBox="0 0 51 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<circle cx="6" cy="10" r="6" fill="#C89898"/>\r\n<path d="M47 12C47 9.8 45.2 8 43 8H11C8.8 8 7 9.8 7 12M47 12V36C47 38.2 45.2 40 43 40H11C8.8 40 7 38.2 7 36V12M47 12L27 26L7 12" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\r\n</svg>'),
(1328, 25, '_cn_email_icon', 'field_671b7f4fa2989'),
(1329, 258, 'cn_number_icon', '<svg width="40" height="40" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<path d="M44 33.8402V39.8402C44.0022 40.3972 43.8882 40.9485 43.665 41.4589C43.4419 41.9692 43.1146 42.4274 42.7041 42.8039C42.2937 43.1805 41.8091 43.4672 41.2815 43.6456C40.7538 43.8241 40.1947 43.8903 39.64 43.8402C33.4857 43.1715 27.574 41.0685 22.38 37.7002C17.5476 34.6295 13.4507 30.5325 10.38 25.7002C6.99994 20.4826 4.89647 14.5422 4.23999 8.36019C4.19001 7.80713 4.25574 7.24971 4.43299 6.72344C4.61024 6.19717 4.89513 5.71357 5.26952 5.30344C5.64391 4.8933 6.0996 4.56561 6.60757 4.34124C7.11554 4.11686 7.66467 4.00072 8.21999 4.00019H14.22C15.1906 3.99064 16.1316 4.33435 16.8675 4.96726C17.6035 5.60017 18.0841 6.47909 18.22 7.44019C18.4732 9.36033 18.9429 11.2456 19.62 13.0602C19.8891 13.776 19.9473 14.554 19.7878 15.302C19.6283 16.0499 19.2577 16.7364 18.72 17.2802L16.18 19.8202C19.0271 24.8273 23.1729 28.9731 28.18 31.8202L30.72 29.2802C31.2638 28.7425 31.9503 28.3719 32.6982 28.2124C33.4462 28.0529 34.2241 28.1111 34.94 28.3802C36.7545 29.0573 38.6399 29.5269 40.56 29.7802C41.5315 29.9173 42.4188 30.4066 43.0531 31.1552C43.6873 31.9038 44.0243 32.8593 44 33.8402Z" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>\r\n</svg>'),
(1330, 258, '_cn_number_icon', 'field_671b7f41a2988'),
(1331, 258, 'cn_email_icon', '<svg width="51" height="40" viewBox="0 0 51 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<circle cx="6" cy="10" r="6" fill="#C89898"/>\r\n<path d="M47 12C47 9.8 45.2 8 43 8H11C8.8 8 7 9.8 7 12M47 12V36C47 38.2 45.2 40 43 40H11C8.8 40 7 38.2 7 36V12M47 12L27 26L7 12" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\r\n</svg>'),
(1332, 258, '_cn_email_icon', 'field_671b7f4fa2989'),
(1333, 6, 'small_text_4_s_text', 'Virtual Personal Styling'),
(1334, 6, '_small_text_4_s_text', 'field_671893d794f78'),
(1335, 6, 'small_text_5_s_text', 'Sessions Wardrobe Audit'),
(1336, 6, '_small_text_5_s_text', 'field_671893d794f78'),
(1337, 6, 'small_text_6_s_text', 'Styling Consultations Long-Term'),
(1338, 6, '_small_text_6_s_text', 'field_671893d794f78'),
(1339, 6, 'small_text_7_s_text', 'Styling Packages editorial styling services'),
(1340, 6, '_small_text_7_s_text', 'field_671893d794f78'),
(1341, 217, 'banner_logo', '58'),
(1342, 217, '_banner_logo', 'field_67188d83f2f1a') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1343, 217, 'banner_text', 'Curated Styling Journeys'),
(1344, 217, '_banner_text', 'field_67188e79f2f1b'),
(1345, 217, 'banner_image', '59'),
(1346, 217, '_banner_image', 'field_67188e8cf2f1c'),
(1347, 217, 'banner_content', 'Personalized Styling experiences that weave together grace and practicality, ensuring you radiate confidence and beauty in every moment.'),
(1348, 217, '_banner_content', 'field_67188eb9f2f1d'),
(1349, 217, 'service_content', 'At Lune by Bhagya, we see personal style as more than mere clothing—it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.'),
(1350, 217, '_service_content', 'field_67188ef9f2f1e'),
(1351, 217, 'link_text', 'See Styling Services'),
(1352, 217, '_link_text', 'field_67188f85f2f1f'),
(1353, 217, 'link_url', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(1354, 217, '_link_url', 'field_67188f94f2f20'),
(1355, 217, 'big_text_0_b_text', 'Styling Packages'),
(1356, 217, '_big_text_0_b_text', 'field_6718934d94f76'),
(1357, 217, 'big_text_1_b_text', 'Styling Packages'),
(1358, 217, '_big_text_1_b_text', 'field_6718934d94f76'),
(1359, 217, 'big_text', '2'),
(1360, 217, '_big_text', 'field_671892dc94f75'),
(1361, 217, 'small_text_0_s_text', 'Virtual Personal Styling'),
(1362, 217, '_small_text_0_s_text', 'field_671893d794f78'),
(1363, 217, 'small_text_1_s_text', 'Sessions Wardrobe Audit'),
(1364, 217, '_small_text_1_s_text', 'field_671893d794f78'),
(1365, 217, 'small_text_2_s_text', 'Styling Consultations Long-Term'),
(1366, 217, '_small_text_2_s_text', 'field_671893d794f78'),
(1367, 217, 'small_text_3_s_text', 'Styling Packages editorial styling services'),
(1368, 217, '_small_text_3_s_text', 'field_671893d794f78'),
(1369, 217, 'small_text', '8'),
(1370, 217, '_small_text', 'field_6718937b94f77'),
(1371, 217, 'packages_0_package_image', '76'),
(1372, 217, '_packages_0_package_image', 'field_67192d92f4ece'),
(1373, 217, 'packages_0_package_name', 'entry package - Silver'),
(1374, 217, '_packages_0_package_name', 'field_67192db2f4ecf'),
(1375, 217, 'packages_0_package_content', 'A single, curated lookbook Delivery in 48 hrs'),
(1376, 217, '_packages_0_package_content', 'field_67192dc8f4ed0'),
(1377, 217, 'packages_0_package_price', '$75 / Rs. 3000'),
(1378, 217, '_packages_0_package_price', 'field_67192deaf4ed1'),
(1379, 217, 'packages_0_book_link', '#'),
(1380, 217, '_packages_0_book_link', 'field_67192df7f4ed2'),
(1381, 217, 'packages_1_package_image', '75'),
(1382, 217, '_packages_1_package_image', 'field_67192d92f4ece'),
(1383, 217, 'packages_1_package_name', 'Signature package - Gold'),
(1384, 217, '_packages_1_package_name', 'field_67192db2f4ecf'),
(1385, 217, 'packages_1_package_content', '3 expertly crafted lookbooks Delivery in 3 days'),
(1386, 217, '_packages_1_package_content', 'field_67192dc8f4ed0'),
(1387, 217, 'packages_1_package_price', '$200 / Rs. 5000'),
(1388, 217, '_packages_1_package_price', 'field_67192deaf4ed1'),
(1389, 217, 'packages_1_book_link', '#'),
(1390, 217, '_packages_1_book_link', 'field_67192df7f4ed2'),
(1391, 217, 'packages_2_package_image', '74'),
(1392, 217, '_packages_2_package_image', 'field_67192d92f4ece'),
(1393, 217, 'packages_2_package_name', 'Ultimate package - Diamond'),
(1394, 217, '_packages_2_package_name', 'field_67192db2f4ecf'),
(1395, 217, 'packages_2_package_content', '5 meticulously curated lookbooks - Delivery in 5 days'),
(1396, 217, '_packages_2_package_content', 'field_67192dc8f4ed0'),
(1397, 217, 'packages_2_package_price', '$350 / Rs. 10,000'),
(1398, 217, '_packages_2_package_price', 'field_67192deaf4ed1'),
(1399, 217, 'packages_2_book_link', '#'),
(1400, 217, '_packages_2_book_link', 'field_67192df7f4ed2'),
(1401, 217, 'packages', '3'),
(1402, 217, '_packages', 'field_67192d3ef4ecd'),
(1403, 217, 'pk_button_text', 'see all styling services'),
(1404, 217, '_pk_button_text', 'field_671930ab9e49a'),
(1405, 217, 'pk_button_link', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(1406, 217, '_pk_button_link', 'field_671930b89e49b'),
(1407, 217, 'video_image', '84'),
(1408, 217, '_video_image', 'field_67193185af906'),
(1409, 217, 'add_video', '85'),
(1410, 217, '_add_video', 'field_67193152af905'),
(1411, 217, 'testi_title', 'real stories'),
(1412, 217, '_testi_title', 'field_6719327a5dbbd'),
(1413, 217, 'testi_image', '106'),
(1414, 217, '_testi_image', 'field_671932d95dbbe'),
(1415, 217, 'testi_image_text', 'Real Style Transformations'),
(1416, 217, '_testi_image_text', 'field_671932ef5dbbf'),
(1417, 217, 'testi_content', 'Working with Lune by Bhagya was a transformative experience! The lookbook I received perfectly captured my style and boosted my confidence for my upcoming event. I can\'t thank Bhagya enough for her expertise!'),
(1418, 217, '_testi_content', 'field_6719330e5dbc0'),
(1419, 217, 'testi_name', 'Sofia M.'),
(1420, 217, '_testi_name', 'field_671933285dbc1'),
(1421, 217, 'in_title', 'Insights   Inspiration '),
(1422, 217, '_in_title', 'field_6719337767360'),
(1423, 217, 'home_insights_0_in_head', 'The Art of Lookbooks: Why They’re Essential for Every Fashionista'),
(1424, 217, '_home_insights_0_in_head', 'field_671933b367362'),
(1425, 217, 'home_insights_0_in_link', 'a:3:{s:5:"title";s:25:"Building a Brand Identity";s:3:"url";s:62:"https://localhost/luna/site/blogs/building-a-brand-identity-1/";s:6:"target";s:0:"";}'),
(1426, 217, '_home_insights_0_in_link', 'field_671933c567363'),
(1427, 217, 'home_insights_1_in_head', 'the importance of body shape and color analysis, and how to create versatile outfits'),
(1428, 217, '_home_insights_1_in_head', 'field_671933b367362'),
(1429, 217, 'home_insights_1_in_link', 'a:3:{s:5:"title";s:25:"Building a Brand Identity";s:3:"url";s:60:"https://localhost/luna/site/blogs/building-a-brand-identity/";s:6:"target";s:0:"";}'),
(1430, 217, '_home_insights_1_in_link', 'field_671933c567363'),
(1431, 217, 'home_insights', '2'),
(1432, 217, '_home_insights', 'field_6719339867361'),
(1433, 217, 'blog_title', 'Related Blogs'),
(1434, 217, '_blog_title', 'field_67193450dadcb'),
(1435, 217, 'rel_blogs_0_blog_image', '107'),
(1436, 217, '_rel_blogs_0_blog_image', 'field_6719347fdadcd'),
(1437, 217, 'rel_blogs_0_blog_date', '20240910'),
(1438, 217, '_rel_blogs_0_blog_date', 'field_671934a3dadce'),
(1439, 217, 'rel_blogs_0_b_title', 'Building a Brand Identity'),
(1440, 217, '_rel_blogs_0_b_title', 'field_671934d9dadcf'),
(1441, 217, 'rel_blogs_0_blog_content', 'This post could delve into the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity.'),
(1442, 217, '_rel_blogs_0_blog_content', 'field_671934eddadd0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1443, 217, 'rel_blogs_0_blog_link', ''),
(1444, 217, '_rel_blogs_0_blog_link', 'field_67193500dadd1'),
(1445, 217, 'rel_blogs', '1'),
(1446, 217, '_rel_blogs', 'field_67193465dadcc'),
(1447, 217, 'small_text_4_s_text', 'Virtual Personal Styling'),
(1448, 217, '_small_text_4_s_text', 'field_671893d794f78'),
(1449, 217, 'small_text_5_s_text', 'Sessions Wardrobe Audit'),
(1450, 217, '_small_text_5_s_text', 'field_671893d794f78'),
(1451, 217, 'small_text_6_s_text', 'Styling Consultations Long-Term'),
(1452, 217, '_small_text_6_s_text', 'field_671893d794f78'),
(1453, 217, 'small_text_7_s_text', 'Styling Packages editorial styling services'),
(1454, 217, '_small_text_7_s_text', 'field_671893d794f78'),
(1455, 263, '_edit_last', '1'),
(1456, 263, '_edit_lock', '1729857206:1'),
(1457, 210, 'st_contact_form', '[contact-form-7 id="240" title="Contact Styling"]'),
(1458, 210, '_st_contact_form', 'field_671b869f6c69e'),
(1459, 211, 'st_contact_form', '[contact-form-7 id="240" title="Contact Styling"]'),
(1460, 211, '_st_contact_form', 'field_671b869f6c69e'),
(1461, 269, '_edit_last', '1'),
(1462, 269, '_edit_lock', '1729857623:1'),
(1463, 20, 'o_button_text', 'Find the perfect ensemble'),
(1464, 20, '_o_button_text', 'field_671b8764f7b1a'),
(1465, 20, 'o_button_link', 'a:3:{s:5:"title";s:7:"Contact";s:3:"url";s:44:"https://localhost/luna/site/connect-with-me/";s:6:"target";s:0:"";}'),
(1466, 20, '_o_button_link', 'field_671b8771f7b1b'),
(1467, 175, 'o_button_text', 'See all Outfit Collages'),
(1468, 175, '_o_button_text', 'field_671b8764f7b1a'),
(1469, 175, 'o_button_link', ''),
(1470, 175, '_o_button_link', 'field_671b8771f7b1b'),
(1471, 32, '_wp_old_date', '2024-10-25'),
(1472, 29, '_wp_old_date', '2024-10-25'),
(1473, 35, '_wp_old_date', '2024-10-25'),
(1474, 125, '_wp_old_date', '2024-10-25'),
(1475, 223, '_wp_old_date', '2024-10-25'),
(1476, 33, '_wp_old_date', '2024-10-25'),
(1477, 224, '_wp_old_date', '2024-10-25'),
(1478, 31, '_wp_old_date', '2024-10-25'),
(1479, 30, '_wp_old_date', '2024-10-25'),
(1480, 262, 'banner_logo', '58'),
(1481, 262, '_banner_logo', 'field_67188d83f2f1a'),
(1482, 262, 'banner_text', 'Curated Styling Journeys'),
(1483, 262, '_banner_text', 'field_67188e79f2f1b'),
(1484, 262, 'banner_image', '59'),
(1485, 262, '_banner_image', 'field_67188e8cf2f1c'),
(1486, 262, 'banner_content', 'Personalized Styling experiences that weave together grace and practicality, ensuring you radiate confidence and beauty in every moment.'),
(1487, 262, '_banner_content', 'field_67188eb9f2f1d'),
(1488, 262, 'service_content', 'At Lune by Bhagya, we see personal style as more than mere clothing—it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.'),
(1489, 262, '_service_content', 'field_67188ef9f2f1e'),
(1490, 262, 'link_text', 'See Styling Services'),
(1491, 262, '_link_text', 'field_67188f85f2f1f'),
(1492, 262, 'link_url', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:46:"http://localhost/luna/site/index.php/services/";s:6:"target";s:0:"";}'),
(1493, 262, '_link_url', 'field_67188f94f2f20'),
(1494, 262, 'big_text_0_b_text', 'Styling Packages'),
(1495, 262, '_big_text_0_b_text', 'field_6718934d94f76'),
(1496, 262, 'big_text_1_b_text', 'Styling Packages'),
(1497, 262, '_big_text_1_b_text', 'field_6718934d94f76'),
(1498, 262, 'big_text', '2'),
(1499, 262, '_big_text', 'field_671892dc94f75'),
(1500, 262, 'small_text_0_s_text', 'Virtual Personal Styling'),
(1501, 262, '_small_text_0_s_text', 'field_671893d794f78'),
(1502, 262, 'small_text_1_s_text', 'Sessions Wardrobe Audit'),
(1503, 262, '_small_text_1_s_text', 'field_671893d794f78'),
(1504, 262, 'small_text_2_s_text', 'Styling Consultations Long-Term'),
(1505, 262, '_small_text_2_s_text', 'field_671893d794f78'),
(1506, 262, 'small_text_3_s_text', 'Styling Packages editorial styling services'),
(1507, 262, '_small_text_3_s_text', 'field_671893d794f78'),
(1508, 262, 'small_text', '8'),
(1509, 262, '_small_text', 'field_6718937b94f77'),
(1510, 262, 'packages_0_package_image', '76'),
(1511, 262, '_packages_0_package_image', 'field_67192d92f4ece'),
(1512, 262, 'packages_0_package_name', 'entry package - Silver'),
(1513, 262, '_packages_0_package_name', 'field_67192db2f4ecf'),
(1514, 262, 'packages_0_package_content', 'A single, curated lookbook Delivery in 48 hrs'),
(1515, 262, '_packages_0_package_content', 'field_67192dc8f4ed0'),
(1516, 262, 'packages_0_package_price', '$75 / Rs. 3000'),
(1517, 262, '_packages_0_package_price', 'field_67192deaf4ed1'),
(1518, 262, 'packages_0_book_link', '#'),
(1519, 262, '_packages_0_book_link', 'field_67192df7f4ed2'),
(1520, 262, 'packages_1_package_image', '75'),
(1521, 262, '_packages_1_package_image', 'field_67192d92f4ece'),
(1522, 262, 'packages_1_package_name', 'Signature package - Gold'),
(1523, 262, '_packages_1_package_name', 'field_67192db2f4ecf'),
(1524, 262, 'packages_1_package_content', '3 expertly crafted lookbooks Delivery in 3 days'),
(1525, 262, '_packages_1_package_content', 'field_67192dc8f4ed0'),
(1526, 262, 'packages_1_package_price', '$200 / Rs. 5000'),
(1527, 262, '_packages_1_package_price', 'field_67192deaf4ed1'),
(1528, 262, 'packages_1_book_link', '#'),
(1529, 262, '_packages_1_book_link', 'field_67192df7f4ed2'),
(1530, 262, 'packages_2_package_image', '74'),
(1531, 262, '_packages_2_package_image', 'field_67192d92f4ece'),
(1532, 262, 'packages_2_package_name', 'Ultimate package - Diamond'),
(1533, 262, '_packages_2_package_name', 'field_67192db2f4ecf'),
(1534, 262, 'packages_2_package_content', '5 meticulously curated lookbooks - Delivery in 5 days'),
(1535, 262, '_packages_2_package_content', 'field_67192dc8f4ed0'),
(1536, 262, 'packages_2_package_price', '$350 / Rs. 10,000'),
(1537, 262, '_packages_2_package_price', 'field_67192deaf4ed1'),
(1538, 262, 'packages_2_book_link', '#'),
(1539, 262, '_packages_2_book_link', 'field_67192df7f4ed2'),
(1540, 262, 'packages', '3'),
(1541, 262, '_packages', 'field_67192d3ef4ecd'),
(1542, 262, 'pk_button_text', 'About Lune by Bhagya') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1543, 262, '_pk_button_text', 'field_671930ab9e49a'),
(1544, 262, 'pk_button_link', 'a:3:{s:5:"title";s:8:"Services";s:3:"url";s:49:"https://localhost/luna/site/about-lune-by-bhagya/";s:6:"target";s:0:"";}'),
(1545, 262, '_pk_button_link', 'field_671930b89e49b'),
(1546, 262, 'video_image', '84'),
(1547, 262, '_video_image', 'field_67193185af906'),
(1548, 262, 'add_video', '85'),
(1549, 262, '_add_video', 'field_67193152af905'),
(1550, 262, 'testi_title', 'real stories'),
(1551, 262, '_testi_title', 'field_6719327a5dbbd'),
(1552, 262, 'testi_image', '106'),
(1553, 262, '_testi_image', 'field_671932d95dbbe'),
(1554, 262, 'testi_image_text', 'Real Style Transformations'),
(1555, 262, '_testi_image_text', 'field_671932ef5dbbf'),
(1556, 262, 'testi_content', 'Working with Lune by Bhagya was a transformative experience! The lookbook I received perfectly captured my style and boosted my confidence for my upcoming event. I can\'t thank Bhagya enough for her expertise!'),
(1557, 262, '_testi_content', 'field_6719330e5dbc0'),
(1558, 262, 'testi_name', 'Sofia M.'),
(1559, 262, '_testi_name', 'field_671933285dbc1'),
(1560, 262, 'in_title', 'Insights   Inspiration '),
(1561, 262, '_in_title', 'field_6719337767360'),
(1562, 262, 'home_insights_0_in_head', 'The Art of Lookbooks: Why They’re Essential for Every Fashionista'),
(1563, 262, '_home_insights_0_in_head', 'field_671933b367362'),
(1564, 262, 'home_insights_0_in_link', 'a:3:{s:5:"title";s:25:"Building a Brand Identity";s:3:"url";s:62:"https://localhost/luna/site/blogs/building-a-brand-identity-1/";s:6:"target";s:0:"";}'),
(1565, 262, '_home_insights_0_in_link', 'field_671933c567363'),
(1566, 262, 'home_insights_1_in_head', 'the importance of body shape and color analysis, and how to create versatile outfits'),
(1567, 262, '_home_insights_1_in_head', 'field_671933b367362'),
(1568, 262, 'home_insights_1_in_link', 'a:3:{s:5:"title";s:25:"Building a Brand Identity";s:3:"url";s:60:"https://localhost/luna/site/blogs/building-a-brand-identity/";s:6:"target";s:0:"";}'),
(1569, 262, '_home_insights_1_in_link', 'field_671933c567363'),
(1570, 262, 'home_insights', '2'),
(1571, 262, '_home_insights', 'field_6719339867361'),
(1572, 262, 'blog_title', 'Related Blogs'),
(1573, 262, '_blog_title', 'field_67193450dadcb'),
(1574, 262, 'rel_blogs_0_blog_image', '107'),
(1575, 262, '_rel_blogs_0_blog_image', 'field_6719347fdadcd'),
(1576, 262, 'rel_blogs_0_blog_date', '20240910'),
(1577, 262, '_rel_blogs_0_blog_date', 'field_671934a3dadce'),
(1578, 262, 'rel_blogs_0_b_title', 'Building a Brand Identity'),
(1579, 262, '_rel_blogs_0_b_title', 'field_671934d9dadcf'),
(1580, 262, 'rel_blogs_0_blog_content', 'This post could delve into the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity.'),
(1581, 262, '_rel_blogs_0_blog_content', 'field_671934eddadd0'),
(1582, 262, 'rel_blogs_0_blog_link', ''),
(1583, 262, '_rel_blogs_0_blog_link', 'field_67193500dadd1'),
(1584, 262, 'rel_blogs', '1'),
(1585, 262, '_rel_blogs', 'field_67193465dadcc'),
(1586, 262, 'small_text_4_s_text', 'Virtual Personal Styling'),
(1587, 262, '_small_text_4_s_text', 'field_671893d794f78'),
(1588, 262, 'small_text_5_s_text', 'Sessions Wardrobe Audit'),
(1589, 262, '_small_text_5_s_text', 'field_671893d794f78'),
(1590, 262, 'small_text_6_s_text', 'Styling Consultations Long-Term'),
(1591, 262, '_small_text_6_s_text', 'field_671893d794f78'),
(1592, 262, 'small_text_7_s_text', 'Styling Packages editorial styling services'),
(1593, 262, '_small_text_7_s_text', 'field_671893d794f78'),
(1594, 124, 'banner_title', 'Services'),
(1595, 124, '_banner_title', 'field_67193ff9ed0e6'),
(1596, 124, 'ser_scrolling_text_0_ser_text', 'Comprehensive styling services'),
(1597, 124, '_ser_scrolling_text_0_ser_text', 'field_6719403ded0e8'),
(1598, 124, 'ser_scrolling_text_1_ser_text', 'Comprehensive styling services'),
(1599, 124, '_ser_scrolling_text_1_ser_text', 'field_6719403ded0e8'),
(1600, 124, 'ser_scrolling_text', '2'),
(1601, 124, '_ser_scrolling_text', 'field_67194021ed0e7'),
(1602, 124, 'our_services_0_service_name', 'Virtual personal styling sessions'),
(1603, 124, '_our_services_0_service_name', 'field_671940a4ed0ea'),
(1604, 124, 'our_services_0_service_description', '<ul>\r\n 	<li>Body shape analysis</li>\r\n 	<li>Color analysis</li>\r\n 	<li>Variation analysis</li>\r\n 	<li>Moodboard</li>\r\n 	<li>Tailored outfit curation</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Shopping guide - lookbooks with links</li>\r\n 	<li>Video sessions</li>\r\n</ul>'),
(1605, 124, '_our_services_0_service_description', 'field_671940b3ed0eb'),
(1606, 124, 'our_services_0_service_price', '$500 / Rs. 15,000'),
(1607, 124, '_our_services_0_service_price', 'field_671940eded0ed'),
(1608, 124, 'our_services_1_service_name', 'Wardrobe audit and styling consultations'),
(1609, 124, '_our_services_1_service_name', 'field_671940a4ed0ea'),
(1610, 124, 'our_services_1_service_description', '<ul>\r\n 	<li>Complete wardrobe audit</li>\r\n 	<li>Decluttering and sorting</li>\r\n 	<li>Development of personal style</li>\r\n 	<li>Pre-shopping research</li>\r\n 	<li>Guided shopping</li>\r\n 	<li>Moodboard</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Revisions</li>\r\n 	<li>Video sessions</li>\r\n</ul>'),
(1611, 124, '_our_services_1_service_description', 'field_671940b3ed0eb'),
(1612, 124, 'our_services_1_service_price', '$600 / Rs. 20,000 per month'),
(1613, 124, '_our_services_1_service_price', 'field_671940eded0ed'),
(1614, 124, 'our_services_2_service_name', 'Editorial styling'),
(1615, 124, '_our_services_2_service_name', 'field_671940a4ed0ea'),
(1616, 124, 'our_services_2_service_description', '<ul>\r\n 	<li>Concept development</li>\r\n 	<li>Moodboard and colorboard</li>\r\n 	<li>Storyboard</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Garment sourcing</li>\r\n 	<li>Shooting assistance</li>\r\n 	<li>Video and one-on-one assistance</li>\r\n</ul>'),
(1617, 124, '_our_services_2_service_description', 'field_671940b3ed0eb'),
(1618, 124, 'our_services_2_service_price', '$600 / Rs. 20,000 per month'),
(1619, 124, '_our_services_2_service_price', 'field_671940eded0ed'),
(1620, 124, 'our_services', '3'),
(1621, 124, '_our_services', 'field_6719405bed0e9'),
(1622, 271, 'o_button_text', 'Reach out me'),
(1623, 271, '_o_button_text', 'field_671b8764f7b1a'),
(1624, 271, 'o_button_link', 'a:3:{s:5:"title";s:7:"Contact";s:3:"url";s:36:"https://localhost/luna/site/contact/";s:6:"target";s:0:"";}'),
(1625, 271, '_o_button_link', 'field_671b8771f7b1b'),
(1626, 261, 'contact_heading', 'Hi I’m<span>Bhagya</span>'),
(1627, 261, '_contact_heading', 'field_671b7da8ebb4f'),
(1628, 261, 'cn_number', '+91 9995 666 333'),
(1629, 261, '_cn_number', 'field_671b7e658f701'),
(1630, 261, 'cn_email_id', 'contact@lune.com'),
(1631, 261, '_cn_email_id', 'field_671b7e868f702'),
(1632, 261, 'form_heading', '—Step into Your Style Story'),
(1633, 261, '_form_heading', 'field_671b7eac8f703'),
(1634, 261, 'contact_form', '[contact-form-7 id="174" title="Contact"]'),
(1635, 261, '_contact_form', 'field_671b7ecc8f704'),
(1636, 261, 'cn_number_icon', '<svg width="40" height="40" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<path d="M44 33.8402V39.8402C44.0022 40.3972 43.8882 40.9485 43.665 41.4589C43.4419 41.9692 43.1146 42.4274 42.7041 42.8039C42.2937 43.1805 41.8091 43.4672 41.2815 43.6456C40.7538 43.8241 40.1947 43.8903 39.64 43.8402C33.4857 43.1715 27.574 41.0685 22.38 37.7002C17.5476 34.6295 13.4507 30.5325 10.38 25.7002C6.99994 20.4826 4.89647 14.5422 4.23999 8.36019C4.19001 7.80713 4.25574 7.24971 4.43299 6.72344C4.61024 6.19717 4.89513 5.71357 5.26952 5.30344C5.64391 4.8933 6.0996 4.56561 6.60757 4.34124C7.11554 4.11686 7.66467 4.00072 8.21999 4.00019H14.22C15.1906 3.99064 16.1316 4.33435 16.8675 4.96726C17.6035 5.60017 18.0841 6.47909 18.22 7.44019C18.4732 9.36033 18.9429 11.2456 19.62 13.0602C19.8891 13.776 19.9473 14.554 19.7878 15.302C19.6283 16.0499 19.2577 16.7364 18.72 17.2802L16.18 19.8202C19.0271 24.8273 23.1729 28.9731 28.18 31.8202L30.72 29.2802C31.2638 28.7425 31.9503 28.3719 32.6982 28.2124C33.4462 28.0529 34.2241 28.1111 34.94 28.3802C36.7545 29.0573 38.6399 29.5269 40.56 29.7802C41.5315 29.9173 42.4188 30.4066 43.0531 31.1552C43.6873 31.9038 44.0243 32.8593 44 33.8402Z" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>\r\n</svg>'),
(1637, 261, '_cn_number_icon', 'field_671b7f41a2988'),
(1638, 261, 'cn_email_icon', '<svg width="51" height="40" viewBox="0 0 51 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<circle cx="6" cy="10" r="6" fill="#C89898"/>\r\n<path d="M47 12C47 9.8 45.2 8 43 8H11C8.8 8 7 9.8 7 12M47 12V36C47 38.2 45.2 40 43 40H11C8.8 40 7 38.2 7 36V12M47 12L27 26L7 12" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\r\n</svg>'),
(1639, 261, '_cn_email_icon', 'field_671b7f4fa2989'),
(1640, 46, '_wp_old_date', '2024-10-25'),
(1641, 39, '_wp_old_date', '2024-10-25'),
(1642, 44, '_wp_old_date', '2024-10-25') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1643, 45, '_wp_old_date', '2024-10-25'),
(1644, 43, '_wp_old_date', '2024-10-25'),
(1645, 42, '_wp_old_date', '2024-10-25'),
(1646, 40, '_wp_old_date', '2024-10-25'),
(1647, 41, '_wp_old_date', '2024-10-25'),
(1648, 47, '_wp_old_date', '2024-10-23'),
(1649, 48, '_wp_old_date', '2024-10-23'),
(1650, 281, '_menu_item_type', 'custom'),
(1651, 281, '_menu_item_menu_item_parent', '0'),
(1652, 281, '_menu_item_object_id', '281'),
(1653, 281, '_menu_item_object', 'custom'),
(1654, 281, '_menu_item_target', ''),
(1655, 281, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1656, 281, '_menu_item_xfn', ''),
(1657, 281, '_menu_item_url', 'https://localhost/luna/site/portfolio/'),
(1659, 280, 'contact_heading', 'Hi I’m<span>Bhagya</span>'),
(1660, 280, '_contact_heading', 'field_671b7da8ebb4f'),
(1661, 280, 'cn_number', '+91 9995 666 333'),
(1662, 280, '_cn_number', 'field_671b7e658f701'),
(1663, 280, 'cn_email_id', 'pingme@lunebybhagya.com'),
(1664, 280, '_cn_email_id', 'field_671b7e868f702'),
(1665, 280, 'form_heading', '—Step into Your Style Story'),
(1666, 280, '_form_heading', 'field_671b7eac8f703'),
(1667, 280, 'contact_form', '[contact-form-7 id="174" title="Contact"]'),
(1668, 280, '_contact_form', 'field_671b7ecc8f704'),
(1669, 280, 'cn_number_icon', '<svg width="40" height="40" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<path d="M44 33.8402V39.8402C44.0022 40.3972 43.8882 40.9485 43.665 41.4589C43.4419 41.9692 43.1146 42.4274 42.7041 42.8039C42.2937 43.1805 41.8091 43.4672 41.2815 43.6456C40.7538 43.8241 40.1947 43.8903 39.64 43.8402C33.4857 43.1715 27.574 41.0685 22.38 37.7002C17.5476 34.6295 13.4507 30.5325 10.38 25.7002C6.99994 20.4826 4.89647 14.5422 4.23999 8.36019C4.19001 7.80713 4.25574 7.24971 4.43299 6.72344C4.61024 6.19717 4.89513 5.71357 5.26952 5.30344C5.64391 4.8933 6.0996 4.56561 6.60757 4.34124C7.11554 4.11686 7.66467 4.00072 8.21999 4.00019H14.22C15.1906 3.99064 16.1316 4.33435 16.8675 4.96726C17.6035 5.60017 18.0841 6.47909 18.22 7.44019C18.4732 9.36033 18.9429 11.2456 19.62 13.0602C19.8891 13.776 19.9473 14.554 19.7878 15.302C19.6283 16.0499 19.2577 16.7364 18.72 17.2802L16.18 19.8202C19.0271 24.8273 23.1729 28.9731 28.18 31.8202L30.72 29.2802C31.2638 28.7425 31.9503 28.3719 32.6982 28.2124C33.4462 28.0529 34.2241 28.1111 34.94 28.3802C36.7545 29.0573 38.6399 29.5269 40.56 29.7802C41.5315 29.9173 42.4188 30.4066 43.0531 31.1552C43.6873 31.9038 44.0243 32.8593 44 33.8402Z" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>\r\n</svg>'),
(1670, 280, '_cn_number_icon', 'field_671b7f41a2988'),
(1671, 280, 'cn_email_icon', '<svg width="51" height="40" viewBox="0 0 51 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<circle cx="6" cy="10" r="6" fill="#C89898"/>\r\n<path d="M47 12C47 9.8 45.2 8 43 8H11C8.8 8 7 9.8 7 12M47 12V36C47 38.2 45.2 40 43 40H11C8.8 40 7 38.2 7 36V12M47 12L27 26L7 12" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\r\n</svg>'),
(1672, 280, '_cn_email_icon', 'field_671b7f4fa2989'),
(1673, 279, 'o_button_text', 'Find the perfect ensemble'),
(1674, 279, '_o_button_text', 'field_671b8764f7b1a'),
(1675, 279, 'o_button_link', 'a:3:{s:5:"title";s:7:"Contact";s:3:"url";s:36:"https://localhost/luna/site/contact/";s:6:"target";s:0:"";}'),
(1676, 279, '_o_button_link', 'field_671b8771f7b1b'),
(1677, 283, 'o_button_text', 'Find the perfect ensemble'),
(1678, 283, '_o_button_text', 'field_671b8764f7b1a'),
(1679, 283, 'o_button_link', 'a:3:{s:5:"title";s:7:"Contact";s:3:"url";s:41:"https://localhost/luna/site/reach-out-me/";s:6:"target";s:0:"";}'),
(1680, 283, '_o_button_link', 'field_671b8771f7b1b'),
(1681, 204, 'outfit_thumbnail_image', '203'),
(1682, 204, '_outfit_thumbnail_image', 'field_6719d47790076'),
(1683, 204, 'outfit_position', 'Business Casual'),
(1684, 204, '_outfit_position', 'field_6719d53390077'),
(1685, 204, 'outfit_gallery_images_0_gal_image', '191'),
(1686, 204, '_outfit_gallery_images_0_gal_image', 'field_6719d5a79007b'),
(1687, 204, 'outfit_gallery_images_1_gal_image', '190'),
(1688, 204, '_outfit_gallery_images_1_gal_image', 'field_6719d5a79007b'),
(1689, 204, 'outfit_gallery_images', '2'),
(1690, 204, '_outfit_gallery_images', 'field_6719d58e9007a'),
(1691, 204, 'outfit_ideas_0_outfit_idea_image', '198'),
(1692, 204, '_outfit_ideas_0_outfit_idea_image', 'field_6719d688066ba'),
(1693, 204, 'outfit_ideas_0_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1694, 204, '_outfit_ideas_0_oufit_idea_details', 'field_6719d6af066bb'),
(1695, 204, 'outfit_ideas_1_outfit_idea_image', '197'),
(1696, 204, '_outfit_ideas_1_outfit_idea_image', 'field_6719d688066ba'),
(1697, 204, 'outfit_ideas_1_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1698, 204, '_outfit_ideas_1_oufit_idea_details', 'field_6719d6af066bb'),
(1699, 204, 'outfit_ideas_2_outfit_idea_image', '199'),
(1700, 204, '_outfit_ideas_2_outfit_idea_image', 'field_6719d688066ba'),
(1701, 204, 'outfit_ideas_2_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1702, 204, '_outfit_ideas_2_oufit_idea_details', 'field_6719d6af066bb'),
(1703, 204, 'outfit_ideas', '3'),
(1704, 204, '_outfit_ideas', 'field_6719d66e066b9'),
(1705, 10, 'our_services_0_service_link', '#'),
(1706, 10, '_our_services_0_service_link', 'field_67288e8d0a639'),
(1707, 10, 'our_services_1_service_link', '#'),
(1708, 10, '_our_services_1_service_link', 'field_67288e8d0a639'),
(1709, 10, 'our_services_2_service_link', '#'),
(1710, 10, '_our_services_2_service_link', 'field_67288e8d0a639'),
(1711, 278, 'banner_title', 'Services'),
(1712, 278, '_banner_title', 'field_67193ff9ed0e6'),
(1713, 278, 'ser_scrolling_text_0_ser_text', 'Comprehensive styling services'),
(1714, 278, '_ser_scrolling_text_0_ser_text', 'field_6719403ded0e8'),
(1715, 278, 'ser_scrolling_text_1_ser_text', 'Comprehensive styling services'),
(1716, 278, '_ser_scrolling_text_1_ser_text', 'field_6719403ded0e8'),
(1717, 278, 'ser_scrolling_text', '2'),
(1718, 278, '_ser_scrolling_text', 'field_67194021ed0e7'),
(1719, 278, 'our_services_0_service_name', 'Virtual personal styling sessions'),
(1720, 278, '_our_services_0_service_name', 'field_671940a4ed0ea'),
(1721, 278, 'our_services_0_service_description', '<ul>\r\n 	<li>Body shape analysis</li>\r\n 	<li>Color analysis</li>\r\n 	<li>Variation analysis</li>\r\n 	<li>Moodboard</li>\r\n 	<li>Tailored outfit curation</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Shopping guide - lookbooks with links</li>\r\n 	<li>Video sessions</li>\r\n</ul>'),
(1722, 278, '_our_services_0_service_description', 'field_671940b3ed0eb'),
(1723, 278, 'our_services_0_service_price', '$500 / Rs. 15,000'),
(1724, 278, '_our_services_0_service_price', 'field_671940eded0ed'),
(1725, 278, 'our_services_1_service_name', 'Wardrobe audit and styling consultations'),
(1726, 278, '_our_services_1_service_name', 'field_671940a4ed0ea'),
(1727, 278, 'our_services_1_service_description', '<ul>\r\n 	<li>Complete wardrobe audit</li>\r\n 	<li>Decluttering and sorting</li>\r\n 	<li>Development of personal style</li>\r\n 	<li>Pre-shopping research</li>\r\n 	<li>Guided shopping</li>\r\n 	<li>Moodboard</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Revisions</li>\r\n 	<li>Video sessions</li>\r\n</ul>'),
(1728, 278, '_our_services_1_service_description', 'field_671940b3ed0eb'),
(1729, 278, 'our_services_1_service_price', '$600 / Rs. 20,000 per month'),
(1730, 278, '_our_services_1_service_price', 'field_671940eded0ed'),
(1731, 278, 'our_services_2_service_name', 'Editorial styling'),
(1732, 278, '_our_services_2_service_name', 'field_671940a4ed0ea'),
(1733, 278, 'our_services_2_service_description', '<ul>\r\n 	<li>Concept development</li>\r\n 	<li>Moodboard and colorboard</li>\r\n 	<li>Storyboard</li>\r\n 	<li>Style recommendations</li>\r\n 	<li>Garment sourcing</li>\r\n 	<li>Shooting assistance</li>\r\n 	<li>Video and one-on-one assistance</li>\r\n</ul>'),
(1734, 278, '_our_services_2_service_description', 'field_671940b3ed0eb'),
(1735, 278, 'our_services_2_service_price', '$600 / Rs. 20,000 per month'),
(1736, 278, '_our_services_2_service_price', 'field_671940eded0ed'),
(1737, 278, 'our_services', '3'),
(1738, 278, '_our_services', 'field_6719405bed0e9'),
(1739, 278, 'our_services_0_service_link', '#'),
(1740, 278, '_our_services_0_service_link', 'field_67288e8d0a639'),
(1741, 278, 'our_services_1_service_link', '#'),
(1742, 278, '_our_services_1_service_link', 'field_67288e8d0a639'),
(1743, 278, 'our_services_2_service_link', '#') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1744, 278, '_our_services_2_service_link', 'field_67288e8d0a639'),
(1745, 287, '_edit_last', '1'),
(1746, 287, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(1747, 287, '_yoast_wpseo_wordproof_timestamp', ''),
(1748, 287, '_edit_lock', '1730792438:1'),
(1749, 287, '_thumbnail_id', '178'),
(1750, 287, '_yoast_wpseo_content_score', '90'),
(1751, 287, 'outfit_thumbnail_image', '203'),
(1752, 287, '_outfit_thumbnail_image', 'field_6719d47790076'),
(1753, 287, 'outfit_position', 'Business Casual'),
(1754, 287, '_outfit_position', 'field_6719d53390077'),
(1755, 287, 'outfit_gallery_images_0_gal_image', '191'),
(1756, 287, '_outfit_gallery_images_0_gal_image', 'field_6719d5a79007b'),
(1757, 287, 'outfit_gallery_images_1_gal_image', '190'),
(1758, 287, '_outfit_gallery_images_1_gal_image', 'field_6719d5a79007b'),
(1759, 287, 'outfit_gallery_images', '2'),
(1760, 287, '_outfit_gallery_images', 'field_6719d58e9007a'),
(1761, 287, 'outfit_ideas_0_outfit_idea_image', '198'),
(1762, 287, '_outfit_ideas_0_outfit_idea_image', 'field_6719d688066ba'),
(1763, 287, 'outfit_ideas_0_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1764, 287, '_outfit_ideas_0_oufit_idea_details', 'field_6719d6af066bb'),
(1765, 287, 'outfit_ideas_1_outfit_idea_image', '197'),
(1766, 287, '_outfit_ideas_1_outfit_idea_image', 'field_6719d688066ba'),
(1767, 287, 'outfit_ideas_1_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1768, 287, '_outfit_ideas_1_oufit_idea_details', 'field_6719d6af066bb'),
(1769, 287, 'outfit_ideas_2_outfit_idea_image', '199'),
(1770, 287, '_outfit_ideas_2_outfit_idea_image', 'field_6719d688066ba'),
(1771, 287, 'outfit_ideas_2_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1772, 287, '_outfit_ideas_2_oufit_idea_details', 'field_6719d6af066bb'),
(1773, 287, 'outfit_ideas', '3'),
(1774, 287, '_outfit_ideas', 'field_6719d66e066b9'),
(1775, 287, '_wp_old_slug', 'kristen-osborne-copy'),
(1776, 287, '_wp_old_slug', 'vi-rodriguez-copy'),
(1777, 288, 'outfit_thumbnail_image', '203'),
(1778, 288, '_outfit_thumbnail_image', 'field_6719d47790076'),
(1779, 288, 'outfit_position', 'Business Casual'),
(1780, 288, '_outfit_position', 'field_6719d53390077'),
(1781, 288, 'outfit_gallery_images_0_gal_image', '191'),
(1782, 288, '_outfit_gallery_images_0_gal_image', 'field_6719d5a79007b'),
(1783, 288, 'outfit_gallery_images_1_gal_image', '190'),
(1784, 288, '_outfit_gallery_images_1_gal_image', 'field_6719d5a79007b'),
(1785, 288, 'outfit_gallery_images', '2'),
(1786, 288, '_outfit_gallery_images', 'field_6719d58e9007a'),
(1787, 288, 'outfit_ideas_0_outfit_idea_image', '198'),
(1788, 288, '_outfit_ideas_0_outfit_idea_image', 'field_6719d688066ba'),
(1789, 288, 'outfit_ideas_0_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1790, 288, '_outfit_ideas_0_oufit_idea_details', 'field_6719d6af066bb'),
(1791, 288, 'outfit_ideas_1_outfit_idea_image', '197'),
(1792, 288, '_outfit_ideas_1_outfit_idea_image', 'field_6719d688066ba'),
(1793, 288, 'outfit_ideas_1_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1794, 288, '_outfit_ideas_1_oufit_idea_details', 'field_6719d6af066bb'),
(1795, 288, 'outfit_ideas_2_outfit_idea_image', '199'),
(1796, 288, '_outfit_ideas_2_outfit_idea_image', 'field_6719d688066ba'),
(1797, 288, 'outfit_ideas_2_oufit_idea_details', '<p>Black beaded statement necklace to go with your dress. It matches with your blazer and shoes. It will pull the whole look together. Even without the blazer, it will make your look complete.</p>'),
(1798, 288, '_outfit_ideas_2_oufit_idea_details', 'field_6719d6af066bb'),
(1799, 288, 'outfit_ideas', '3'),
(1800, 288, '_outfit_ideas', 'field_6719d66e066b9'),
(1801, 47, '_wp_old_date', '2024-11-03'),
(1802, 48, '_wp_old_date', '2024-11-03'),
(1803, 281, '_wp_old_date', '2024-11-03'),
(1804, 46, '_wp_old_date', '2024-11-03'),
(1805, 39, '_wp_old_date', '2024-11-03'),
(1806, 44, '_wp_old_date', '2024-11-03'),
(1807, 45, '_wp_old_date', '2024-11-03'),
(1808, 43, '_wp_old_date', '2024-11-03'),
(1809, 42, '_wp_old_date', '2024-11-03'),
(1810, 40, '_wp_old_date', '2024-11-03'),
(1811, 41, '_wp_old_date', '2024-11-03'),
(1812, 32, '_wp_old_date', '2024-11-03'),
(1813, 29, '_wp_old_date', '2024-11-03'),
(1814, 35, '_wp_old_date', '2024-11-03'),
(1815, 125, '_wp_old_date', '2024-11-03'),
(1816, 223, '_wp_old_date', '2024-11-03'),
(1817, 33, '_wp_old_date', '2024-11-03'),
(1818, 224, '_wp_old_date', '2024-11-03'),
(1819, 31, '_wp_old_date', '2024-11-03'),
(1820, 30, '_wp_old_date', '2024-11-03'),
(1821, 282, 'contact_heading', 'Hi I’m<span>Bhagya</span>'),
(1822, 282, '_contact_heading', 'field_671b7da8ebb4f'),
(1823, 282, 'cn_number', '+91 9995 666 333'),
(1824, 282, '_cn_number', 'field_671b7e658f701'),
(1825, 282, 'cn_email_id', 'pingme@lunebybhagya.com'),
(1826, 282, '_cn_email_id', 'field_671b7e868f702'),
(1827, 282, 'form_heading', '—Step into Your Style Story'),
(1828, 282, '_form_heading', 'field_671b7eac8f703'),
(1829, 282, 'contact_form', '[contact-form-7 id="174" title="Contact"]'),
(1830, 282, '_contact_form', 'field_671b7ecc8f704'),
(1831, 282, 'cn_number_icon', '<svg width="40" height="40" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<path d="M44 33.8402V39.8402C44.0022 40.3972 43.8882 40.9485 43.665 41.4589C43.4419 41.9692 43.1146 42.4274 42.7041 42.8039C42.2937 43.1805 41.8091 43.4672 41.2815 43.6456C40.7538 43.8241 40.1947 43.8903 39.64 43.8402C33.4857 43.1715 27.574 41.0685 22.38 37.7002C17.5476 34.6295 13.4507 30.5325 10.38 25.7002C6.99994 20.4826 4.89647 14.5422 4.23999 8.36019C4.19001 7.80713 4.25574 7.24971 4.43299 6.72344C4.61024 6.19717 4.89513 5.71357 5.26952 5.30344C5.64391 4.8933 6.0996 4.56561 6.60757 4.34124C7.11554 4.11686 7.66467 4.00072 8.21999 4.00019H14.22C15.1906 3.99064 16.1316 4.33435 16.8675 4.96726C17.6035 5.60017 18.0841 6.47909 18.22 7.44019C18.4732 9.36033 18.9429 11.2456 19.62 13.0602C19.8891 13.776 19.9473 14.554 19.7878 15.302C19.6283 16.0499 19.2577 16.7364 18.72 17.2802L16.18 19.8202C19.0271 24.8273 23.1729 28.9731 28.18 31.8202L30.72 29.2802C31.2638 28.7425 31.9503 28.3719 32.6982 28.2124C33.4462 28.0529 34.2241 28.1111 34.94 28.3802C36.7545 29.0573 38.6399 29.5269 40.56 29.7802C41.5315 29.9173 42.4188 30.4066 43.0531 31.1552C43.6873 31.9038 44.0243 32.8593 44 33.8402Z" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>\r\n</svg>'),
(1832, 282, '_cn_number_icon', 'field_671b7f41a2988'),
(1833, 282, 'cn_email_icon', '<svg width="51" height="40" viewBox="0 0 51 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<circle cx="6" cy="10" r="6" fill="#C89898"/>\r\n<path d="M47 12C47 9.8 45.2 8 43 8H11C8.8 8 7 9.8 7 12M47 12V36C47 38.2 45.2 40 43 40H11C8.8 40 7 38.2 7 36V12M47 12L27 26L7 12" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\r\n</svg>'),
(1834, 282, '_cn_email_icon', 'field_671b7f4fa2989'),
(1835, 293, 'contact_heading', 'Hi I’m<span>Bhagya</span>'),
(1836, 293, '_contact_heading', 'field_671b7da8ebb4f'),
(1837, 293, 'cn_number', '+91 9995 666 333'),
(1838, 293, '_cn_number', 'field_671b7e658f701'),
(1839, 293, 'cn_email_id', 'pingme@lunebybhagya.com'),
(1840, 293, '_cn_email_id', 'field_671b7e868f702'),
(1841, 293, 'form_heading', '—Step into Your Style Story'),
(1842, 293, '_form_heading', 'field_671b7eac8f703'),
(1843, 293, 'contact_form', '[contact-form-7 id="174" title="Contact"]') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1844, 293, '_contact_form', 'field_671b7ecc8f704'),
(1845, 293, 'cn_number_icon', '<svg width="40" height="40" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<path d="M44 33.8402V39.8402C44.0022 40.3972 43.8882 40.9485 43.665 41.4589C43.4419 41.9692 43.1146 42.4274 42.7041 42.8039C42.2937 43.1805 41.8091 43.4672 41.2815 43.6456C40.7538 43.8241 40.1947 43.8903 39.64 43.8402C33.4857 43.1715 27.574 41.0685 22.38 37.7002C17.5476 34.6295 13.4507 30.5325 10.38 25.7002C6.99994 20.4826 4.89647 14.5422 4.23999 8.36019C4.19001 7.80713 4.25574 7.24971 4.43299 6.72344C4.61024 6.19717 4.89513 5.71357 5.26952 5.30344C5.64391 4.8933 6.0996 4.56561 6.60757 4.34124C7.11554 4.11686 7.66467 4.00072 8.21999 4.00019H14.22C15.1906 3.99064 16.1316 4.33435 16.8675 4.96726C17.6035 5.60017 18.0841 6.47909 18.22 7.44019C18.4732 9.36033 18.9429 11.2456 19.62 13.0602C19.8891 13.776 19.9473 14.554 19.7878 15.302C19.6283 16.0499 19.2577 16.7364 18.72 17.2802L16.18 19.8202C19.0271 24.8273 23.1729 28.9731 28.18 31.8202L30.72 29.2802C31.2638 28.7425 31.9503 28.3719 32.6982 28.2124C33.4462 28.0529 34.2241 28.1111 34.94 28.3802C36.7545 29.0573 38.6399 29.5269 40.56 29.7802C41.5315 29.9173 42.4188 30.4066 43.0531 31.1552C43.6873 31.9038 44.0243 32.8593 44 33.8402Z" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>\r\n</svg>'),
(1846, 293, '_cn_number_icon', 'field_671b7f41a2988'),
(1847, 293, 'cn_email_icon', '<svg width="51" height="40" viewBox="0 0 51 48" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<circle cx="6" cy="10" r="6" fill="#C89898"/>\r\n<path d="M47 12C47 9.8 45.2 8 43 8H11C8.8 8 7 9.8 7 12M47 12V36C47 38.2 45.2 40 43 40H11C8.8 40 7 38.2 7 36V12M47 12L27 26L7 12" stroke="#C89898" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\r\n</svg>'),
(1848, 293, '_cn_email_icon', 'field_671b7f4fa2989'),
(1849, 284, 'o_button_text', 'Find the perfect ensemble'),
(1850, 284, '_o_button_text', 'field_671b8764f7b1a'),
(1851, 284, 'o_button_link', 'a:3:{s:5:"title";s:7:"Contact";s:3:"url";s:44:"https://localhost/luna/site/connect-with-me/";s:6:"target";s:0:"";}'),
(1852, 284, '_o_button_link', 'field_671b8771f7b1b') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-10-18 07:11:46', '2024-10-18 07:11:46', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2024-10-18 07:11:46', '2024-10-18 07:11:46', '', 0, 'http://localhost/luna/site/?p=1', 0, 'post', '', 1),
(2, 1, '2024-10-18 07:11:46', '2024-10-18 07:11:46', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost/luna/site/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2024-10-18 07:11:46', '2024-10-18 07:11:46', '', 0, 'http://localhost/luna/site/?page_id=2', 0, 'page', '', 0),
(3, 1, '2024-10-18 07:11:46', '2024-10-18 07:11:46', '<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we are</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost/luna/site.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Comments</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Media</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we share your data with</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">How long we retain your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">What rights you have over your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Where your data is sent</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2024-10-18 07:11:46', '2024-10-18 07:11:46', '', 0, 'http://localhost/luna/site/?page_id=3', 0, 'page', '', 0),
(5, 1, '2024-10-18 07:14:11', '2024-10-18 07:14:11', '<label> Your name\n    [text* your-name autocomplete:name] </label>\n\n<label> Your email\n    [email* your-email autocomplete:email] </label>\n\n<label> Subject\n    [text* your-subject] </label>\n\n<label> Your message (optional)\n    [textarea your-message] </label>\n\n[submit "Submit"]\n[_site_title] "[your-subject]"\n[_site_title] <deepsonart@gmail.com>\nFrom: [your-name] [your-email]\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\n[_site_admin_email]\nReply-To: [your-email]\n\n0\n0\n\n[_site_title] "[your-subject]"\n[_site_title] <deepsonart@gmail.com>\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\n[your-email]\nReply-To: [_site_admin_email]\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nPlease fill out this field.\nThis field has a too long input.\nThis field has a too short input.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe uploaded file is too large.\nThere was an error uploading the file.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2024-10-18 07:14:11', '2024-10-18 07:14:11', '', 0, 'http://localhost/luna/site/?post_type=wpcf7_contact_form&p=5', 0, 'wpcf7_contact_form', '', 0),
(6, 1, '2024-10-18 07:17:50', '2024-10-18 07:17:50', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2024-11-03 05:48:35', '2024-11-03 05:48:35', '', 0, 'http://localhost/luna/site/?page_id=6', 0, 'page', '', 0),
(7, 1, '2024-10-18 07:17:50', '2024-10-18 07:17:50', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-10-18 07:17:50', '2024-10-18 07:17:50', '', 6, 'http://localhost/luna/site/?p=7', 0, 'revision', '', 0),
(8, 1, '2024-10-18 07:18:44', '2024-10-18 07:18:44', '<h1>My name is <span>Bhagya</span></h1>\r\n<p>I\'m a qualified fashion stylist with over 6 years of experience and a degree in fashion merchandising. I\'m also a certified color analyst, and seasoned fashion journalist, with a keen eye for putting together OOTDs. Clearly, I live and breathe fashion!</p>\r\n<p>At the heart of Lune by Bhagya is also my mother who, like most mothers, is a powerhouse of a manager! She keeps the engine running, while also taking the role of a shopping consultant in my projects!</p>\r\n<p>Together, we are a passionate mother-daughter duo, who are on a quest to helping men and women feel more confident in their own skin! We celebrate flaws and tailor outfit looks that embrace your unique features! Our styling solutions will change the way you feel about yourself, period.</p>', 'About Lune by Bhagya', '', 'publish', 'closed', 'closed', '', 'about-lune-by-bhagya', '', '', '2024-10-25 05:53:34', '2024-10-25 05:53:34', '', 0, 'http://localhost/luna/site/?page_id=8', 0, 'page', '', 0),
(9, 1, '2024-10-18 07:18:44', '2024-10-18 07:18:44', '', 'About', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2024-10-18 07:18:44', '2024-10-18 07:18:44', '', 8, 'http://localhost/luna/site/?p=9', 0, 'revision', '', 0),
(10, 1, '2024-10-18 07:23:53', '2024-10-18 07:23:53', '', 'Services', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2024-11-04 09:07:49', '2024-11-04 09:07:49', '', 0, 'http://localhost/luna/site/?page_id=10', 0, 'page', '', 0),
(11, 1, '2024-10-18 07:23:53', '2024-10-18 07:23:53', '', 'Services', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2024-10-18 07:23:53', '2024-10-18 07:23:53', '', 10, 'http://localhost/luna/site/?p=11', 0, 'revision', '', 0),
(15, 1, '2024-10-23 04:45:27', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2024-10-23 04:45:27', '0000-00-00 00:00:00', '', 0, 'http://localhost/luna/site/?p=15', 1, 'nav_menu_item', '', 0),
(16, 1, '2024-10-23 04:45:29', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2024-10-23 04:45:29', '0000-00-00 00:00:00', '', 0, 'http://localhost/luna/site/?p=16', 1, 'nav_menu_item', '', 0),
(17, 1, '2024-10-23 04:45:30', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2024-10-23 04:45:30', '0000-00-00 00:00:00', '', 0, 'http://localhost/luna/site/?p=17', 1, 'nav_menu_item', '', 0),
(18, 1, '2024-10-23 04:48:03', '2024-10-23 04:48:03', '<p>At Lune by Bhagya, we offer a range of hand-curated, no-commitment, quick and easy styling packages designed to suit your personal style journey. Whether you need a quick style refresh or a comprehensive wardrobe overhaul, our packages provide expert guidance and personalized looks for every occasion. Explore our Silver, Gold, and Diamond options to find the perfect match for your fashion needs, and let us help you elevate your wardrobe with elegance and ease.</p>\r\n                     ', 'Styling Packages', '', 'publish', 'closed', 'closed', '', 'styling-packages', '', '', '2024-11-05 07:46:52', '2024-11-05 07:46:52', '', 0, 'http://localhost/luna/site/?page_id=18', 0, 'page', '', 0),
(19, 1, '2024-10-23 04:48:03', '2024-10-23 04:48:03', '', 'Styling Packages', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2024-10-23 04:48:03', '2024-10-23 04:48:03', '', 18, 'http://localhost/luna/site/?p=19', 0, 'revision', '', 0),
(20, 1, '2024-10-23 04:49:06', '2024-10-23 04:49:06', '<h2>Curated Outfit Collages</h2>\r\n<p>Explore our collection of curated outfit collages, each designed to inspire and simplify your wardrobe choices. Whether you\'re looking for casual chic, office elegance, or special occasion glam, these collages provide versatile looks that blend fashion and functionality. Find the perfect ensemble for any moment, all thoughtfully styled to reflect your unique taste.\r\n', 'Portfolio', '', 'publish', 'closed', 'closed', '', 'portfolio', '', '', '2024-11-06 09:06:21', '2024-11-06 09:06:21', '', 0, 'http://localhost/luna/site/?page_id=20', 0, 'page', '', 0),
(21, 1, '2024-10-23 04:49:06', '2024-10-23 04:49:06', '', 'Portfolio', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2024-10-23 04:49:06', '2024-10-23 04:49:06', '', 20, 'http://localhost/luna/site/?p=21', 0, 'revision', '', 0),
(22, 1, '2024-10-23 04:50:18', '2024-10-23 04:50:18', '<div class="faq">\r\n    <h3 class="faq-question">What is your return policy?</h3>\r\n    <div class="faq-answer">\r\n      <p>We offer a 30-day return policy on all items. Please ensure that the items are in their original condition and packaging.</p>\r\n    </div>\r\n  </div>\r\n\r\n  <div class="faq">\r\n    <h3 class="faq-question">Do you offer international shipping?</h3>\r\n    <div class="faq-answer">\r\n      <p>Yes, we ship to most countries around the world. Shipping fees and delivery times vary by location.</p>\r\n    </div>\r\n  </div>\r\n\r\n  <div class="faq">\r\n    <h3 class="faq-question">How can I track my order?</h3>\r\n    <div class="faq-answer">\r\n      <p>Once your order has shipped, you will receive an email with a tracking link to monitor the status of your delivery.</p>\r\n    </div>\r\n  </div>', 'FAQs', '', 'publish', 'closed', 'closed', '', 'faqs', '', '', '2024-10-25 06:48:09', '2024-10-25 06:48:09', '', 0, 'http://localhost/luna/site/?page_id=22', 0, 'page', '', 0),
(23, 1, '2024-10-23 04:50:18', '2024-10-23 04:50:18', '', 'FAQs', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2024-10-23 04:50:18', '2024-10-23 04:50:18', '', 22, 'http://localhost/luna/site/?p=23', 0, 'revision', '', 0),
(25, 1, '2024-10-23 05:06:22', '2024-10-23 05:06:22', '<p>I’d love to hear from you! Whether you have questions about my styling services, need personalized fashion advice, or are ready to begin your style journey, feel free to reach out</p>', 'Connect With Me', '', 'publish', 'closed', 'closed', '', 'connect-with-me', '', '', '2024-11-06 08:59:45', '2024-11-06 08:59:45', '', 0, 'http://localhost/luna/site/?page_id=25', 0, 'page', '', 0),
(27, 1, '2024-10-23 05:06:22', '2024-10-23 05:06:22', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2024-10-23 05:06:22', '2024-10-23 05:06:22', '', 25, 'http://localhost/luna/site/?p=27', 0, 'revision', '', 0),
(28, 1, '2024-10-23 05:09:55', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2024-10-23 05:09:55', '0000-00-00 00:00:00', '', 0, 'http://localhost/luna/site/?p=28', 1, 'nav_menu_item', '', 0),
(29, 1, '2024-11-06 08:58:14', '2024-10-23 05:11:17', ' ', '', '', 'publish', 'closed', 'closed', '', '29', '', '', '2024-11-06 08:58:14', '2024-11-06 08:58:14', '', 0, 'http://localhost/luna/site/?p=29', 2, 'nav_menu_item', '', 0),
(30, 1, '2024-11-06 08:58:14', '2024-10-23 05:11:22', '', 'Connect With Me', '', 'publish', 'closed', 'closed', '', '30', '', '', '2024-11-06 08:58:14', '2024-11-06 08:58:14', '', 0, 'http://localhost/luna/site/?p=30', 9, 'nav_menu_item', '', 0),
(31, 1, '2024-11-06 08:58:14', '2024-10-23 05:11:22', ' ', '', '', 'publish', 'closed', 'closed', '', '31', '', '', '2024-11-06 08:58:14', '2024-11-06 08:58:14', '', 0, 'http://localhost/luna/site/?p=31', 8, 'nav_menu_item', '', 0),
(32, 1, '2024-11-06 08:58:14', '2024-10-23 05:11:16', ' ', '', '', 'publish', 'closed', 'closed', '', '32', '', '', '2024-11-06 08:58:14', '2024-11-06 08:58:14', '', 0, 'http://localhost/luna/site/?p=32', 1, 'nav_menu_item', '', 0),
(33, 1, '2024-11-06 08:58:14', '2024-10-23 05:11:21', '', 'Outfit Portfolio', '', 'publish', 'closed', 'closed', '', '33', '', '', '2024-11-06 08:58:14', '2024-11-06 08:58:14', '', 0, 'http://localhost/luna/site/?p=33', 6, 'nav_menu_item', '', 0),
(35, 1, '2024-11-06 08:58:14', '2024-10-23 05:11:20', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2024-11-06 08:58:14', '2024-11-06 08:58:14', '', 0, 'http://localhost/luna/site/?p=35', 3, 'nav_menu_item', '', 0),
(36, 1, '2024-10-23 05:18:20', '2024-10-23 05:18:20', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2024-10-24 14:05:42', '2024-10-24 14:05:42', '', 0, 'http://localhost/luna/site/?page_id=36', 0, 'page', '', 0),
(37, 1, '2024-10-23 05:18:20', '2024-10-23 05:18:20', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2024-10-23 05:18:20', '2024-10-23 05:18:20', '', 36, 'http://localhost/luna/site/?p=37', 0, 'revision', '', 0),
(38, 1, '2024-10-23 05:19:33', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2024-10-23 05:19:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/luna/site/?p=38', 1, 'nav_menu_item', '', 0),
(39, 1, '2024-11-06 08:57:57', '2024-10-23 05:22:24', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2024-11-06 08:57:57', '2024-11-06 08:57:57', '', 0, 'http://localhost/luna/site/?p=39', 2, 'nav_menu_item', '', 0),
(40, 1, '2024-11-06 08:57:57', '2024-10-23 05:22:29', '', 'Blogs', '', 'publish', 'closed', 'closed', '', '40', '', '', '2024-11-06 08:57:57', '2024-11-06 08:57:57', '', 0, 'http://localhost/luna/site/?p=40', 7, 'nav_menu_item', '', 0),
(41, 1, '2024-11-06 08:57:57', '2024-10-23 05:22:30', '', 'Connect With Me', '', 'publish', 'closed', 'closed', '', '41', '', '', '2024-11-06 08:57:57', '2024-11-06 08:57:57', '', 0, 'http://localhost/luna/site/?p=41', 8, 'nav_menu_item', '', 0),
(42, 1, '2024-11-06 08:57:57', '2024-10-23 05:22:28', ' ', '', '', 'publish', 'closed', 'closed', '', '42', '', '', '2024-11-06 08:57:57', '2024-11-06 08:57:57', '', 0, 'http://localhost/luna/site/?p=42', 6, 'nav_menu_item', '', 0),
(43, 1, '2024-11-06 08:57:57', '2024-10-23 05:22:27', '', 'Outfit Portfolio', '', 'publish', 'closed', 'closed', '', '43', '', '', '2024-11-06 08:57:57', '2024-11-06 08:57:57', '', 0, 'http://localhost/luna/site/?p=43', 5, 'nav_menu_item', '', 0),
(44, 1, '2024-11-06 08:57:57', '2024-10-23 05:22:24', '', 'Styling Services', '', 'publish', 'closed', 'closed', '', '44', '', '', '2024-11-06 08:57:57', '2024-11-06 08:57:57', '', 0, 'http://localhost/luna/site/?p=44', 3, 'nav_menu_item', '', 0),
(45, 1, '2024-11-06 08:57:57', '2024-10-23 05:22:26', ' ', '', '', 'publish', 'closed', 'closed', '', '45', '', '', '2024-11-06 08:57:57', '2024-11-06 08:57:57', '', 0, 'http://localhost/luna/site/?p=45', 4, 'nav_menu_item', '', 0),
(46, 1, '2024-11-06 08:57:57', '2024-10-23 05:22:22', ' ', '', '', 'publish', 'closed', 'closed', '', '46', '', '', '2024-11-06 08:57:57', '2024-11-06 08:57:57', '', 0, 'http://localhost/luna/site/?p=46', 1, 'nav_menu_item', '', 0),
(47, 1, '2024-11-06 08:57:34', '2024-10-23 05:27:58', '', 'Styling Packages', '', 'publish', 'closed', 'closed', '', 'our-styling-packages', '', '', '2024-11-06 08:57:34', '2024-11-06 08:57:34', '', 0, 'http://localhost/luna/site/?p=47', 1, 'nav_menu_item', '', 0),
(48, 1, '2024-11-06 08:57:34', '2024-10-23 05:27:59', '', 'Styling Services', '', 'publish', 'closed', 'closed', '', 'styling-services', '', '', '2024-11-06 08:57:34', '2024-11-06 08:57:34', '', 0, 'http://localhost/luna/site/?p=48', 2, 'nav_menu_item', '', 0),
(49, 1, '2024-10-23 05:55:36', '2024-10-23 05:55:36', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:17:"template-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Home Page Settings', 'home-page-settings', 'publish', 'closed', 'closed', '', 'group_67188d203104d', '', '', '2024-10-23 17:40:53', '2024-10-23 17:40:53', '', 0, 'http://localhost/luna/site/?post_type=acf-field-group&#038;p=49', 0, 'acf-field-group', '', 0),
(50, 1, '2024-10-23 05:55:36', '2024-10-23 05:55:36', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Banner Section', 'banner_section', 'publish', 'closed', 'closed', '', 'field_67188d47f2f19', '', '', '2024-10-23 05:55:36', '2024-10-23 05:55:36', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=50', 0, 'acf-field', '', 0),
(51, 1, '2024-10-23 05:55:37', '2024-10-23 05:55:37', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Banner Logo', 'banner_logo', 'publish', 'closed', 'closed', '', 'field_67188d83f2f1a', '', '', '2024-10-23 05:55:37', '2024-10-23 05:55:37', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=51', 1, 'acf-field', '', 0),
(52, 1, '2024-10-23 05:55:38', '2024-10-23 05:55:38', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Banner Text', 'banner_text', 'publish', 'closed', 'closed', '', 'field_67188e79f2f1b', '', '', '2024-10-23 05:55:38', '2024-10-23 05:55:38', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=52', 2, 'acf-field', '', 0),
(53, 1, '2024-10-23 05:55:38', '2024-10-23 05:55:38', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Banner Image', 'banner_image', 'publish', 'closed', 'closed', '', 'field_67188e8cf2f1c', '', '', '2024-10-23 05:55:38', '2024-10-23 05:55:38', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=53', 3, 'acf-field', '', 0),
(54, 1, '2024-10-23 05:55:39', '2024-10-23 05:55:39', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'banner_content', 'publish', 'closed', 'closed', '', 'field_67188eb9f2f1d', '', '', '2024-10-23 05:55:39', '2024-10-23 05:55:39', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=54', 4, 'acf-field', '', 0),
(55, 1, '2024-10-23 05:55:39', '2024-10-23 05:55:39', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Service Content', 'service_content', 'publish', 'closed', 'closed', '', 'field_67188ef9f2f1e', '', '', '2024-10-23 05:55:39', '2024-10-23 05:55:39', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=55', 5, 'acf-field', '', 0),
(56, 1, '2024-10-23 05:55:40', '2024-10-23 05:55:40', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Link text', 'link_text', 'publish', 'closed', 'closed', '', 'field_67188f85f2f1f', '', '', '2024-10-23 05:55:40', '2024-10-23 05:55:40', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=56', 6, 'acf-field', '', 0),
(57, 1, '2024-10-23 05:55:40', '2024-10-23 05:55:40', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Link Url', 'link_url', 'publish', 'closed', 'closed', '', 'field_67188f94f2f20', '', '', '2024-10-23 05:55:40', '2024-10-23 05:55:40', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=57', 7, 'acf-field', '', 0),
(58, 1, '2024-10-23 05:58:08', '2024-10-23 05:58:08', '', 'text-logo', '', 'inherit', 'open', 'closed', '', 'text-logo', '', '', '2024-10-23 05:58:08', '2024-10-23 05:58:08', '', 6, 'http://localhost/luna/site/wp-content/uploads/2024/10/text-logo.svg', 0, 'attachment', 'image/svg+xml', 0),
(59, 1, '2024-10-23 05:59:14', '2024-10-23 05:59:14', '', 'img-one', '', 'inherit', 'open', 'closed', '', 'img-one', '', '', '2024-10-23 05:59:14', '2024-10-23 05:59:14', '', 6, 'http://localhost/luna/site/wp-content/uploads/2024/10/img-one.png', 0, 'attachment', 'image/png', 0),
(60, 1, '2024-10-23 06:00:49', '2024-10-23 06:00:49', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-10-23 06:00:49', '2024-10-23 06:00:49', '', 6, 'http://localhost/luna/site/?p=60', 0, 'revision', '', 0),
(61, 1, '2024-10-23 06:14:11', '2024-10-23 06:14:11', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Scrolling Section', 'scrolling_section', 'publish', 'closed', 'closed', '', 'field_6718928994f74', '', '', '2024-10-23 06:14:11', '2024-10-23 06:14:11', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=61', 8, 'acf-field', '', 0),
(62, 1, '2024-10-23 06:14:12', '2024-10-23 06:14:12', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Big Text', 'big_text', 'publish', 'closed', 'closed', '', 'field_671892dc94f75', '', '', '2024-10-23 06:14:12', '2024-10-23 06:14:12', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=62', 9, 'acf-field', '', 0),
(63, 1, '2024-10-23 06:14:12', '2024-10-23 06:14:12', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'b_text', 'publish', 'closed', 'closed', '', 'field_6718934d94f76', '', '', '2024-10-23 06:14:12', '2024-10-23 06:14:12', '', 62, 'http://localhost/luna/site/?post_type=acf-field&p=63', 0, 'acf-field', '', 0),
(64, 1, '2024-10-23 06:14:13', '2024-10-23 06:14:13', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Small Text', 'small_text', 'publish', 'closed', 'closed', '', 'field_6718937b94f77', '', '', '2024-10-23 06:14:13', '2024-10-23 06:14:13', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=64', 10, 'acf-field', '', 0),
(65, 1, '2024-10-23 06:14:13', '2024-10-23 06:14:13', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 's_text', 'publish', 'closed', 'closed', '', 'field_671893d794f78', '', '', '2024-10-23 06:14:13', '2024-10-23 06:14:13', '', 64, 'http://localhost/luna/site/?post_type=acf-field&p=65', 0, 'acf-field', '', 0),
(66, 1, '2024-10-23 06:16:20', '2024-10-23 06:16:20', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-10-23 06:16:20', '2024-10-23 06:16:20', '', 6, 'http://localhost/luna/site/?p=66', 0, 'revision', '', 0),
(67, 1, '2024-10-23 17:10:47', '2024-10-23 17:10:47', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Package Section', 'package_section', 'publish', 'closed', 'closed', '', 'field_67192d2ff4ecc', '', '', '2024-10-23 17:10:47', '2024-10-23 17:10:47', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=67', 11, 'acf-field', '', 0),
(68, 1, '2024-10-23 17:10:48', '2024-10-23 17:10:48', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Packages', 'packages', 'publish', 'closed', 'closed', '', 'field_67192d3ef4ecd', '', '', '2024-10-23 17:10:48', '2024-10-23 17:10:48', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=68', 12, 'acf-field', '', 0),
(69, 1, '2024-10-23 17:10:49', '2024-10-23 17:10:49', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'package_image', 'publish', 'closed', 'closed', '', 'field_67192d92f4ece', '', '', '2024-10-23 17:10:49', '2024-10-23 17:10:49', '', 68, 'http://localhost/luna/site/?post_type=acf-field&p=69', 0, 'acf-field', '', 0),
(70, 1, '2024-10-23 17:10:49', '2024-10-23 17:10:49', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'package_name', 'publish', 'closed', 'closed', '', 'field_67192db2f4ecf', '', '', '2024-10-23 17:10:49', '2024-10-23 17:10:49', '', 68, 'http://localhost/luna/site/?post_type=acf-field&p=70', 1, 'acf-field', '', 0),
(71, 1, '2024-10-23 17:10:50', '2024-10-23 17:10:50', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Content', 'package_content', 'publish', 'closed', 'closed', '', 'field_67192dc8f4ed0', '', '', '2024-10-23 17:10:50', '2024-10-23 17:10:50', '', 68, 'http://localhost/luna/site/?post_type=acf-field&p=71', 2, 'acf-field', '', 0),
(72, 1, '2024-10-23 17:10:50', '2024-10-23 17:10:50', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Price', 'package_price', 'publish', 'closed', 'closed', '', 'field_67192deaf4ed1', '', '', '2024-10-23 17:10:50', '2024-10-23 17:10:50', '', 68, 'http://localhost/luna/site/?post_type=acf-field&p=72', 3, 'acf-field', '', 0),
(73, 1, '2024-10-23 17:10:51', '2024-10-23 17:10:51', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Book Link', 'book_link', 'publish', 'closed', 'closed', '', 'field_67192df7f4ed2', '', '', '2024-10-23 17:10:51', '2024-10-23 17:10:51', '', 68, 'http://localhost/luna/site/?post_type=acf-field&p=73', 4, 'acf-field', '', 0),
(74, 1, '2024-10-23 17:12:29', '2024-10-23 17:12:29', '', 'img-four', '', 'inherit', 'open', 'closed', '', 'img-four', '', '', '2024-10-23 17:12:29', '2024-10-23 17:12:29', '', 6, 'http://localhost/luna/site/wp-content/uploads/2024/10/img-four.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2024-10-23 17:12:31', '2024-10-23 17:12:31', '', 'img-three', '', 'inherit', 'open', 'closed', '', 'img-three', '', '', '2024-10-23 17:12:31', '2024-10-23 17:12:31', '', 6, 'http://localhost/luna/site/wp-content/uploads/2024/10/img-three.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2024-10-23 17:12:33', '2024-10-23 17:12:33', '', 'img-two', '', 'inherit', 'open', 'closed', '', 'img-two', '', '', '2024-10-23 17:12:33', '2024-10-23 17:12:33', '', 6, 'http://localhost/luna/site/wp-content/uploads/2024/10/img-two.jpg', 0, 'attachment', 'image/jpeg', 0),
(77, 1, '2024-10-23 17:16:25', '2024-10-23 17:16:25', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-10-23 17:16:25', '2024-10-23 17:16:25', '', 6, 'http://localhost/luna/site/?p=77', 0, 'revision', '', 0),
(78, 1, '2024-10-23 17:22:30', '2024-10-23 17:22:30', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'pk_button_text', 'publish', 'closed', 'closed', '', 'field_671930ab9e49a', '', '', '2024-10-23 17:22:30', '2024-10-23 17:22:30', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=78', 13, 'acf-field', '', 0),
(79, 1, '2024-10-23 17:22:30', '2024-10-23 17:22:30', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Button Link', 'pk_button_link', 'publish', 'closed', 'closed', '', 'field_671930b89e49b', '', '', '2024-10-23 17:22:30', '2024-10-23 17:22:30', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=79', 14, 'acf-field', '', 0),
(80, 1, '2024-10-23 17:22:56', '2024-10-23 17:22:56', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-10-23 17:22:56', '2024-10-23 17:22:56', '', 6, 'http://localhost/luna/site/?p=80', 0, 'revision', '', 0),
(81, 1, '2024-10-23 17:25:56', '2024-10-23 17:25:56', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Video Section', 'video_section', 'publish', 'closed', 'closed', '', 'field_6719312faf904', '', '', '2024-10-23 17:25:56', '2024-10-23 17:25:56', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=81', 15, 'acf-field', '', 0),
(82, 1, '2024-10-23 17:25:57', '2024-10-23 17:25:57', 'a:10:{s:4:"type";s:4:"file";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:8:"min_size";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:3:"mp4";}', 'Add Video', 'add_video', 'publish', 'closed', 'closed', '', 'field_67193152af905', '', '', '2024-10-23 17:26:23', '2024-10-23 17:26:23', '', 49, 'http://localhost/luna/site/?post_type=acf-field&#038;p=82', 17, 'acf-field', '', 0),
(83, 1, '2024-10-23 17:25:57', '2024-10-23 17:25:57', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Background Image', 'video_image', 'publish', 'closed', 'closed', '', 'field_67193185af906', '', '', '2024-10-23 17:26:22', '2024-10-23 17:26:22', '', 49, 'http://localhost/luna/site/?post_type=acf-field&#038;p=83', 16, 'acf-field', '', 0),
(84, 1, '2024-10-23 17:26:41', '2024-10-23 17:26:41', '', 'banner-three', '', 'inherit', 'open', 'closed', '', 'banner-three', '', '', '2024-10-23 17:26:41', '2024-10-23 17:26:41', '', 6, 'http://localhost/luna/site/wp-content/uploads/2024/10/banner-three.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 1, '2024-10-23 17:27:02', '2024-10-23 17:27:02', '', 'video', '', 'inherit', 'open', 'closed', '', 'video', '', '', '2024-10-23 17:27:02', '2024-10-23 17:27:02', '', 6, 'http://localhost/luna/site/wp-content/uploads/2024/10/video.mp4', 0, 'attachment', 'video/mp4', 0),
(86, 1, '2024-10-23 17:27:13', '2024-10-23 17:27:13', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-10-23 17:27:13', '2024-10-23 17:27:13', '', 6, 'http://localhost/luna/site/?p=86', 0, 'revision', '', 0),
(87, 1, '2024-10-23 17:32:47', '2024-10-23 17:32:47', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Testimonial Section', 'testimonial_section', 'publish', 'closed', 'closed', '', 'field_6719325d5dbbc', '', '', '2024-10-23 17:32:47', '2024-10-23 17:32:47', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=87', 18, 'acf-field', '', 0),
(88, 1, '2024-10-23 17:32:47', '2024-10-23 17:32:47', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'testi_title', 'publish', 'closed', 'closed', '', 'field_6719327a5dbbd', '', '', '2024-10-23 17:32:47', '2024-10-23 17:32:47', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=88', 19, 'acf-field', '', 0),
(89, 1, '2024-10-23 17:32:48', '2024-10-23 17:32:48', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'testi_image', 'publish', 'closed', 'closed', '', 'field_671932d95dbbe', '', '', '2024-10-23 17:32:48', '2024-10-23 17:32:48', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=89', 20, 'acf-field', '', 0),
(90, 1, '2024-10-23 17:32:49', '2024-10-23 17:32:49', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Image Text', 'testi_image_text', 'publish', 'closed', 'closed', '', 'field_671932ef5dbbf', '', '', '2024-10-23 17:32:49', '2024-10-23 17:32:49', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=90', 21, 'acf-field', '', 0),
(91, 1, '2024-10-23 17:32:50', '2024-10-23 17:32:50', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'testi_content', 'publish', 'closed', 'closed', '', 'field_6719330e5dbc0', '', '', '2024-10-23 17:32:50', '2024-10-23 17:32:50', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=91', 22, 'acf-field', '', 0),
(92, 1, '2024-10-23 17:32:51', '2024-10-23 17:32:51', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'testi_name', 'publish', 'closed', 'closed', '', 'field_671933285dbc1', '', '', '2024-10-23 17:32:51', '2024-10-23 17:32:51', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=92', 23, 'acf-field', '', 0),
(93, 1, '2024-10-23 17:35:32', '2024-10-23 17:35:32', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Insights Section', 'insights_section', 'publish', 'closed', 'closed', '', 'field_671933636735f', '', '', '2024-10-23 17:35:32', '2024-10-23 17:35:32', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=93', 24, 'acf-field', '', 0),
(94, 1, '2024-10-23 17:35:32', '2024-10-23 17:35:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'in_title', 'publish', 'closed', 'closed', '', 'field_6719337767360', '', '', '2024-10-23 17:35:32', '2024-10-23 17:35:32', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=94', 25, 'acf-field', '', 0),
(95, 1, '2024-10-23 17:35:33', '2024-10-23 17:35:33', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Insights', 'home_insights', 'publish', 'closed', 'closed', '', 'field_6719339867361', '', '', '2024-10-23 17:35:33', '2024-10-23 17:35:33', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=95', 26, 'acf-field', '', 0),
(96, 1, '2024-10-23 17:35:34', '2024-10-23 17:35:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'in_head', 'publish', 'closed', 'closed', '', 'field_671933b367362', '', '', '2024-10-23 17:40:47', '2024-10-23 17:40:47', '', 95, 'http://localhost/luna/site/?post_type=acf-field&#038;p=96', 0, 'acf-field', '', 0),
(97, 1, '2024-10-23 17:35:34', '2024-10-23 17:35:34', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Link', 'in_link', 'publish', 'closed', 'closed', '', 'field_671933c567363', '', '', '2024-10-23 17:40:48', '2024-10-23 17:40:48', '', 95, 'http://localhost/luna/site/?post_type=acf-field&#038;p=97', 1, 'acf-field', '', 0),
(98, 1, '2024-10-23 17:40:48', '2024-10-23 17:40:48', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Blog Section', 'blog_section', 'publish', 'closed', 'closed', '', 'field_6719341adadca', '', '', '2024-10-23 17:40:48', '2024-10-23 17:40:48', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=98', 27, 'acf-field', '', 0),
(99, 1, '2024-10-23 17:40:49', '2024-10-23 17:40:49', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'blog_title', 'publish', 'closed', 'closed', '', 'field_67193450dadcb', '', '', '2024-10-23 17:40:49', '2024-10-23 17:40:49', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=99', 28, 'acf-field', '', 0),
(100, 1, '2024-10-23 17:40:50', '2024-10-23 17:40:50', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Blogs', 'rel_blogs', 'publish', 'closed', 'closed', '', 'field_67193465dadcc', '', '', '2024-10-23 17:40:50', '2024-10-23 17:40:50', '', 49, 'http://localhost/luna/site/?post_type=acf-field&p=100', 29, 'acf-field', '', 0),
(101, 1, '2024-10-23 17:40:50', '2024-10-23 17:40:50', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'blog_image', 'publish', 'closed', 'closed', '', 'field_6719347fdadcd', '', '', '2024-10-23 17:40:50', '2024-10-23 17:40:50', '', 100, 'http://localhost/luna/site/?post_type=acf-field&p=101', 0, 'acf-field', '', 0),
(102, 1, '2024-10-23 17:40:50', '2024-10-23 17:40:50', 'a:8:{s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:5:"d/m/Y";s:13:"return_format";s:5:"d/m/Y";s:9:"first_day";i:1;}', 'Date', 'blog_date', 'publish', 'closed', 'closed', '', 'field_671934a3dadce', '', '', '2024-10-23 17:40:50', '2024-10-23 17:40:50', '', 100, 'http://localhost/luna/site/?post_type=acf-field&p=102', 1, 'acf-field', '', 0),
(103, 1, '2024-10-23 17:40:51', '2024-10-23 17:40:51', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'b_title', 'publish', 'closed', 'closed', '', 'field_671934d9dadcf', '', '', '2024-10-23 17:40:51', '2024-10-23 17:40:51', '', 100, 'http://localhost/luna/site/?post_type=acf-field&p=103', 2, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(104, 1, '2024-10-23 17:40:51', '2024-10-23 17:40:51', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'blog_content', 'publish', 'closed', 'closed', '', 'field_671934eddadd0', '', '', '2024-10-23 17:40:51', '2024-10-23 17:40:51', '', 100, 'http://localhost/luna/site/?post_type=acf-field&p=104', 3, 'acf-field', '', 0),
(105, 1, '2024-10-23 17:40:52', '2024-10-23 17:40:52', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Link', 'blog_link', 'publish', 'closed', 'closed', '', 'field_67193500dadd1', '', '', '2024-10-23 17:40:52', '2024-10-23 17:40:52', '', 100, 'http://localhost/luna/site/?post_type=acf-field&p=105', 4, 'acf-field', '', 0),
(106, 1, '2024-10-23 17:42:12', '2024-10-23 17:42:12', '', 'img-five', '', 'inherit', 'open', 'closed', '', 'img-five', '', '', '2024-10-23 17:42:12', '2024-10-23 17:42:12', '', 6, 'http://localhost/luna/site/wp-content/uploads/2024/10/img-five.jpg', 0, 'attachment', 'image/jpeg', 0),
(107, 1, '2024-10-23 17:44:08', '2024-10-23 17:44:08', '', 'detailed-four', '', 'inherit', 'open', 'closed', '', 'detailed-four', '', '', '2024-10-23 17:44:08', '2024-10-23 17:44:08', '', 6, 'http://localhost/luna/site/wp-content/uploads/2024/10/detailed-four.jpg', 0, 'attachment', 'image/jpeg', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(108, 1, '2024-10-23 17:44:51', '2024-10-23 17:44:51', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-10-23 17:44:51', '2024-10-23 17:44:51', '', 6, 'http://localhost/luna/site/?p=108', 0, 'revision', '', 0),
(109, 1, '2024-10-23 18:04:57', '2024-10-23 18:04:57', '<h1>My name is <span>Bhagya</span></h1>\n                           <p>I\'m a qualified fashion stylist with over 6 years of experience and a degree in fashion merchandising. I\'m also a certified color analyst, and seasoned fashion journalist, with a keen eye for putting together OOTDs. Clearly, I live and breathe fashion!\n</p>\n                      <p>At the heart of Lune by Bhagya is also my mother who, like most mothers, is a powerhouse of a manager! She keeps the engine running, while also taking the role of a shopping consultant in my projects!</p>\n                      <p>Together, we are a passionate mother-daughter duo, who are on a quest to helping men and women feel more confident in their own skin! We celebrate flaws and tailor outfit looks that embrace your unique features! Our styling solutions will change the way you feel about yourself, period.</p>', 'About', '', 'inherit', 'closed', 'closed', '', '8-autosave-v1', '', '', '2024-10-23 18:04:57', '2024-10-23 18:04:57', '', 8, 'http://localhost/luna/site/?p=109', 0, 'revision', '', 0),
(110, 1, '2024-10-23 18:05:15', '2024-10-23 18:05:15', '<h1>My name is <span>Bhagya</span></h1>\r\n<p>I\'m a qualified fashion stylist with over 6 years of experience and a degree in fashion merchandising. I\'m also a certified color analyst, and seasoned fashion journalist, with a keen eye for putting together OOTDs. Clearly, I live and breathe fashion!</p>\r\n<p>At the heart of Lune by Bhagya is also my mother who, like most mothers, is a powerhouse of a manager! She keeps the engine running, while also taking the role of a shopping consultant in my projects!</p>\r\n<p>Together, we are a passionate mother-daughter duo, who are on a quest to helping men and women feel more confident in their own skin! We celebrate flaws and tailor outfit looks that embrace your unique features! Our styling solutions will change the way you feel about yourself, period.</p>', 'About', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2024-10-23 18:05:15', '2024-10-23 18:05:15', '', 8, 'http://localhost/luna/site/?p=110', 0, 'revision', '', 0),
(111, 1, '2024-10-23 18:13:26', '2024-10-23 18:13:26', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:22:"theme-general-settings";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Theme General Settings', 'theme-general-settings', 'publish', 'closed', 'closed', '', 'group_67193c8c61977', '', '', '2024-10-25 12:07:38', '2024-10-25 12:07:38', '', 0, 'http://localhost/luna/site/?post_type=acf-field-group&#038;p=111', 0, 'acf-field-group', '', 0),
(112, 1, '2024-10-23 18:13:26', '2024-10-23 18:13:26', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Site Logo', 'site_logo', 'publish', 'closed', 'closed', '', 'field_67193cb4507f0', '', '', '2024-10-25 09:43:20', '2024-10-25 09:43:20', '', 111, 'http://localhost/luna/site/?post_type=acf-field&#038;p=112', 1, 'acf-field', '', 0),
(113, 1, '2024-10-23 18:16:27', '2024-10-23 18:16:27', '', 'about-page', '', 'inherit', 'open', 'closed', '', 'about-page', '', '', '2024-10-23 18:16:27', '2024-10-23 18:16:27', '', 8, 'http://localhost/luna/site/wp-content/uploads/2024/10/about-page.jpg', 0, 'attachment', 'image/jpeg', 0),
(114, 1, '2024-10-23 18:31:34', '2024-10-23 18:31:34', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:20:"template-styling.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Service Page Settings', 'service-page-settings', 'publish', 'closed', 'closed', '', 'group_67193f914a771', '', '', '2024-11-04 09:06:48', '2024-11-04 09:06:48', '', 0, 'http://localhost/luna/site/?post_type=acf-field-group&#038;p=114', 0, 'acf-field-group', '', 0),
(115, 1, '2024-10-23 18:31:34', '2024-10-23 18:31:34', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Banner Section', 'banner_section', 'publish', 'closed', 'closed', '', 'field_67193fd7ed0e5', '', '', '2024-10-23 18:31:34', '2024-10-23 18:31:34', '', 114, 'http://localhost/luna/site/?post_type=acf-field&p=115', 0, 'acf-field', '', 0),
(116, 1, '2024-10-23 18:31:35', '2024-10-23 18:31:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'banner_title', 'publish', 'closed', 'closed', '', 'field_67193ff9ed0e6', '', '', '2024-10-23 18:31:35', '2024-10-23 18:31:35', '', 114, 'http://localhost/luna/site/?post_type=acf-field&p=116', 1, 'acf-field', '', 0),
(117, 1, '2024-10-23 18:31:35', '2024-10-23 18:31:35', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Scrolling Text', 'ser_scrolling_text', 'publish', 'closed', 'closed', '', 'field_67194021ed0e7', '', '', '2024-10-23 18:31:35', '2024-10-23 18:31:35', '', 114, 'http://localhost/luna/site/?post_type=acf-field&p=117', 2, 'acf-field', '', 0),
(118, 1, '2024-10-23 18:31:36', '2024-10-23 18:31:36', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'ser_text', 'publish', 'closed', 'closed', '', 'field_6719403ded0e8', '', '', '2024-10-23 18:31:36', '2024-10-23 18:31:36', '', 117, 'http://localhost/luna/site/?post_type=acf-field&p=118', 0, 'acf-field', '', 0),
(119, 1, '2024-10-23 18:31:37', '2024-10-23 18:31:37', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Services', 'our_services', 'publish', 'closed', 'closed', '', 'field_6719405bed0e9', '', '', '2024-10-23 18:33:11', '2024-10-23 18:33:11', '', 114, 'http://localhost/luna/site/?post_type=acf-field&#038;p=119', 4, 'acf-field', '', 0),
(120, 1, '2024-10-23 18:31:38', '2024-10-23 18:31:38', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Service Name', 'service_name', 'publish', 'closed', 'closed', '', 'field_671940a4ed0ea', '', '', '2024-10-23 18:31:38', '2024-10-23 18:31:38', '', 119, 'http://localhost/luna/site/?post_type=acf-field&p=120', 0, 'acf-field', '', 0),
(121, 1, '2024-10-23 18:31:38', '2024-10-23 18:31:38', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Description', 'service_description', 'publish', 'closed', 'closed', '', 'field_671940b3ed0eb', '', '', '2024-10-23 18:31:38', '2024-10-23 18:31:38', '', 119, 'http://localhost/luna/site/?post_type=acf-field&p=121', 1, 'acf-field', '', 0),
(122, 1, '2024-10-23 18:31:39', '2024-10-23 18:31:39', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Price', 'service_price', 'publish', 'closed', 'closed', '', 'field_671940eded0ed', '', '', '2024-10-23 18:31:39', '2024-10-23 18:31:39', '', 119, 'http://localhost/luna/site/?post_type=acf-field&p=122', 2, 'acf-field', '', 0),
(123, 1, '2024-10-23 18:33:10', '2024-10-23 18:33:10', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Services Section', 'services_section', 'publish', 'closed', 'closed', '', 'field_67194142bf9b7', '', '', '2024-10-23 18:33:10', '2024-10-23 18:33:10', '', 114, 'http://localhost/luna/site/?post_type=acf-field&p=123', 3, 'acf-field', '', 0),
(124, 1, '2024-10-23 18:37:09', '2024-10-23 18:37:09', '', 'Services', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2024-10-23 18:37:09', '2024-10-23 18:37:09', '', 10, 'http://localhost/luna/site/?p=124', 0, 'revision', '', 0),
(125, 1, '2024-11-06 08:58:14', '2024-10-23 18:55:42', '', 'Styling Services', '', 'publish', 'closed', 'closed', '', '125', '', '', '2024-11-06 08:58:14', '2024-11-06 08:58:14', '', 0, 'http://localhost/luna/site/?p=125', 4, 'nav_menu_item', '', 0),
(126, 1, '2024-10-23 19:00:30', '2024-10-23 19:00:30', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:17:"template-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Home Page Settings (copy)', 'home-page-settings-copy', 'trash', 'closed', 'closed', '', 'group_671947a683952__trashed', '', '', '2024-10-23 19:09:22', '2024-10-23 19:09:22', '', 0, 'http://localhost/luna/site/?p=126', 0, 'acf-field-group', '', 0),
(127, 1, '2024-10-23 18:59:51', '2024-10-23 18:59:51', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Banner Section', '', 'trash', 'closed', 'closed', '', 'field_671947a75987f__trashed', '', '', '2024-10-23 19:09:24', '2024-10-23 19:09:24', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=127', 0, 'acf-field', '', 0),
(128, 1, '2024-10-23 18:59:52', '2024-10-23 18:59:52', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Banner Logo', 'banner_logo', 'trash', 'closed', 'closed', '', 'field_671947a759c63__trashed', '', '', '2024-10-23 19:09:24', '2024-10-23 19:09:24', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=128', 1, 'acf-field', '', 0),
(129, 1, '2024-10-23 18:59:52', '2024-10-23 18:59:52', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Banner Text', 'banner_text', 'trash', 'closed', 'closed', '', 'field_671947a75a04d__trashed', '', '', '2024-10-23 19:09:25', '2024-10-23 19:09:25', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=129', 2, 'acf-field', '', 0),
(130, 1, '2024-10-23 18:59:53', '2024-10-23 18:59:53', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Banner Image', 'banner_image', 'trash', 'closed', 'closed', '', 'field_671947a75a433__trashed', '', '', '2024-10-23 19:09:25', '2024-10-23 19:09:25', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=130', 3, 'acf-field', '', 0),
(131, 1, '2024-10-23 18:59:54', '2024-10-23 18:59:54', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'banner_content', 'trash', 'closed', 'closed', '', 'field_671947a75a81b__trashed', '', '', '2024-10-23 19:09:26', '2024-10-23 19:09:26', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=131', 4, 'acf-field', '', 0),
(132, 1, '2024-10-23 18:59:55', '2024-10-23 18:59:55', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Service Content', 'service_content', 'trash', 'closed', 'closed', '', 'field_671947a75ac11__trashed', '', '', '2024-10-23 19:09:27', '2024-10-23 19:09:27', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=132', 5, 'acf-field', '', 0),
(133, 1, '2024-10-23 18:59:56', '2024-10-23 18:59:56', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Link text', 'link_text', 'trash', 'closed', 'closed', '', 'field_671947a75afef__trashed', '', '', '2024-10-23 19:09:28', '2024-10-23 19:09:28', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=133', 6, 'acf-field', '', 0),
(134, 1, '2024-10-23 18:59:56', '2024-10-23 18:59:56', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Link Url', 'link_url', 'trash', 'closed', 'closed', '', 'field_671947a75b405__trashed', '', '', '2024-10-23 19:09:28', '2024-10-23 19:09:28', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=134', 7, 'acf-field', '', 0),
(135, 1, '2024-10-23 18:59:57', '2024-10-23 18:59:57', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Scrolling Section', '', 'trash', 'closed', 'closed', '', 'field_671947a75b7c1__trashed', '', '', '2024-10-23 19:09:30', '2024-10-23 19:09:30', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=135', 8, 'acf-field', '', 0),
(136, 1, '2024-10-23 18:59:57', '2024-10-23 18:59:57', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";i:0;s:3:"max";i:0;s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Big Text', 'big_text', 'trash', 'closed', 'closed', '', 'field_671947a75bbc3__trashed', '', '', '2024-10-23 19:09:30', '2024-10-23 19:09:30', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=136', 9, 'acf-field', '', 0),
(137, 1, '2024-10-23 18:59:59', '2024-10-23 18:59:59', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'b_text', 'publish', 'closed', 'closed', '', 'field_671947af20ea2', '', '', '2024-10-23 18:59:59', '2024-10-23 18:59:59', '', 136, 'http://localhost/luna/site/?post_type=acf-field&p=137', 0, 'acf-field', '', 0),
(138, 1, '2024-10-23 19:00:00', '2024-10-23 19:00:00', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";i:0;s:3:"max";i:0;s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Small Text', 'small_text', 'trash', 'closed', 'closed', '', 'field_671947a75bf92__trashed', '', '', '2024-10-23 19:09:31', '2024-10-23 19:09:31', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=138', 10, 'acf-field', '', 0),
(139, 1, '2024-10-23 19:00:02', '2024-10-23 19:00:02', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 's_text', 'publish', 'closed', 'closed', '', 'field_671947b272115', '', '', '2024-10-23 19:00:02', '2024-10-23 19:00:02', '', 138, 'http://localhost/luna/site/?post_type=acf-field&p=139', 0, 'acf-field', '', 0),
(140, 1, '2024-10-23 19:00:03', '2024-10-23 19:00:03', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Package Section', '', 'trash', 'closed', 'closed', '', 'field_671947a75c376__trashed', '', '', '2024-10-23 19:09:32', '2024-10-23 19:09:32', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=140', 11, 'acf-field', '', 0),
(141, 1, '2024-10-23 19:00:03', '2024-10-23 19:00:03', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";i:0;s:3:"max";i:0;s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Packages', 'packages', 'trash', 'closed', 'closed', '', 'field_671947a75c764__trashed', '', '', '2024-10-23 19:09:33', '2024-10-23 19:09:33', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=141', 12, 'acf-field', '', 0),
(142, 1, '2024-10-23 19:00:04', '2024-10-23 19:00:04', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'package_image', 'publish', 'closed', 'closed', '', 'field_671947b45b1f1', '', '', '2024-10-23 19:00:04', '2024-10-23 19:00:04', '', 141, 'http://localhost/luna/site/?post_type=acf-field&p=142', 0, 'acf-field', '', 0),
(143, 1, '2024-10-23 19:00:04', '2024-10-23 19:00:04', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'package_name', 'publish', 'closed', 'closed', '', 'field_671947b45b5d8', '', '', '2024-10-23 19:00:04', '2024-10-23 19:00:04', '', 141, 'http://localhost/luna/site/?post_type=acf-field&p=143', 1, 'acf-field', '', 0),
(144, 1, '2024-10-23 19:00:05', '2024-10-23 19:00:05', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Content', 'package_content', 'publish', 'closed', 'closed', '', 'field_671947b45b9e9', '', '', '2024-10-23 19:00:05', '2024-10-23 19:00:05', '', 141, 'http://localhost/luna/site/?post_type=acf-field&p=144', 2, 'acf-field', '', 0),
(145, 1, '2024-10-23 19:00:05', '2024-10-23 19:00:05', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Price', 'package_price', 'publish', 'closed', 'closed', '', 'field_671947b45bdaa', '', '', '2024-10-23 19:00:05', '2024-10-23 19:00:05', '', 141, 'http://localhost/luna/site/?post_type=acf-field&p=145', 3, 'acf-field', '', 0),
(146, 1, '2024-10-23 19:00:06', '2024-10-23 19:00:06', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Book Link', 'book_link', 'publish', 'closed', 'closed', '', 'field_671947b45c197', '', '', '2024-10-23 19:00:06', '2024-10-23 19:00:06', '', 141, 'http://localhost/luna/site/?post_type=acf-field&p=146', 4, 'acf-field', '', 0),
(147, 1, '2024-10-23 19:00:07', '2024-10-23 19:00:07', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'pk_button_text', 'trash', 'closed', 'closed', '', 'field_671947a75cb55__trashed', '', '', '2024-10-23 19:09:33', '2024-10-23 19:09:33', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=147', 13, 'acf-field', '', 0),
(148, 1, '2024-10-23 19:00:07', '2024-10-23 19:00:07', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Button Link', 'pk_button_link', 'trash', 'closed', 'closed', '', 'field_671947a75cf34__trashed', '', '', '2024-10-23 19:09:34', '2024-10-23 19:09:34', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=148', 14, 'acf-field', '', 0),
(149, 1, '2024-10-23 19:00:09', '2024-10-23 19:00:09', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Video Section', '', 'trash', 'closed', 'closed', '', 'field_671947a75d329__trashed', '', '', '2024-10-23 19:09:35', '2024-10-23 19:09:35', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=149', 15, 'acf-field', '', 0),
(150, 1, '2024-10-23 19:00:10', '2024-10-23 19:00:10', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Background Image', 'video_image', 'trash', 'closed', 'closed', '', 'field_671947a75d70d__trashed', '', '', '2024-10-23 19:09:35', '2024-10-23 19:09:35', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=150', 16, 'acf-field', '', 0),
(151, 1, '2024-10-23 19:00:11', '2024-10-23 19:00:11', 'a:10:{s:4:"type";s:4:"file";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:8:"min_size";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:3:"mp4";}', 'Add Video', 'add_video', 'trash', 'closed', 'closed', '', 'field_671947a75db08__trashed', '', '', '2024-10-23 19:09:37', '2024-10-23 19:09:37', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=151', 17, 'acf-field', '', 0),
(152, 1, '2024-10-23 19:00:12', '2024-10-23 19:00:12', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Testimonial Section', '', 'trash', 'closed', 'closed', '', 'field_671947a75ded2__trashed', '', '', '2024-10-23 19:09:37', '2024-10-23 19:09:37', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=152', 18, 'acf-field', '', 0),
(153, 1, '2024-10-23 19:00:12', '2024-10-23 19:00:12', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'testi_title', 'trash', 'closed', 'closed', '', 'field_671947a75e2db__trashed', '', '', '2024-10-23 19:09:39', '2024-10-23 19:09:39', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=153', 19, 'acf-field', '', 0),
(154, 1, '2024-10-23 19:00:13', '2024-10-23 19:00:13', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'testi_image', 'trash', 'closed', 'closed', '', 'field_671947a75e6c0__trashed', '', '', '2024-10-23 19:09:39', '2024-10-23 19:09:39', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=154', 20, 'acf-field', '', 0),
(155, 1, '2024-10-23 19:00:14', '2024-10-23 19:00:14', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Image Text', 'testi_image_text', 'trash', 'closed', 'closed', '', 'field_671947a75eac6__trashed', '', '', '2024-10-23 19:09:40', '2024-10-23 19:09:40', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=155', 21, 'acf-field', '', 0),
(156, 1, '2024-10-23 19:00:15', '2024-10-23 19:00:15', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'testi_content', 'trash', 'closed', 'closed', '', 'field_671947a75ee7a__trashed', '', '', '2024-10-23 19:09:41', '2024-10-23 19:09:41', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=156', 22, 'acf-field', '', 0),
(157, 1, '2024-10-23 19:00:16', '2024-10-23 19:00:16', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'testi_name', 'trash', 'closed', 'closed', '', 'field_671947a75f260__trashed', '', '', '2024-10-23 19:09:42', '2024-10-23 19:09:42', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=157', 23, 'acf-field', '', 0),
(158, 1, '2024-10-23 19:00:17', '2024-10-23 19:00:17', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Insights Section', '', 'trash', 'closed', 'closed', '', 'field_671947a75f64b__trashed', '', '', '2024-10-23 19:09:42', '2024-10-23 19:09:42', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=158', 24, 'acf-field', '', 0),
(159, 1, '2024-10-23 19:00:18', '2024-10-23 19:00:18', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'in_title', 'trash', 'closed', 'closed', '', 'field_671947a75fa76__trashed', '', '', '2024-10-23 19:09:43', '2024-10-23 19:09:43', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=159', 25, 'acf-field', '', 0),
(160, 1, '2024-10-23 19:00:19', '2024-10-23 19:00:19', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";i:0;s:3:"max";i:0;s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Insights', 'home_insights', 'trash', 'closed', 'closed', '', 'field_671947a75fe1c__trashed', '', '', '2024-10-23 19:09:44', '2024-10-23 19:09:44', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=160', 26, 'acf-field', '', 0),
(161, 1, '2024-10-23 19:00:20', '2024-10-23 19:00:20', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'in_head', 'publish', 'closed', 'closed', '', 'field_671947c4316b7', '', '', '2024-10-23 19:00:20', '2024-10-23 19:00:20', '', 160, 'http://localhost/luna/site/?post_type=acf-field&p=161', 0, 'acf-field', '', 0),
(162, 1, '2024-10-23 19:00:20', '2024-10-23 19:00:20', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Link', 'in_link', 'publish', 'closed', 'closed', '', 'field_671947c431a9d', '', '', '2024-10-23 19:00:20', '2024-10-23 19:00:20', '', 160, 'http://localhost/luna/site/?post_type=acf-field&p=162', 1, 'acf-field', '', 0),
(163, 1, '2024-10-23 19:00:22', '2024-10-23 19:00:22', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Blog Section', '', 'trash', 'closed', 'closed', '', 'field_671947a760204__trashed', '', '', '2024-10-23 19:09:46', '2024-10-23 19:09:46', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=163', 27, 'acf-field', '', 0),
(164, 1, '2024-10-23 19:00:22', '2024-10-23 19:00:22', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'blog_title', 'trash', 'closed', 'closed', '', 'field_671947a7605ec__trashed', '', '', '2024-10-23 19:09:46', '2024-10-23 19:09:46', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=164', 28, 'acf-field', '', 0),
(165, 1, '2024-10-23 19:00:23', '2024-10-23 19:00:23', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";i:0;s:3:"max";i:0;s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Blogs', 'rel_blogs', 'trash', 'closed', 'closed', '', 'field_671947a760a0c__trashed', '', '', '2024-10-23 19:09:47', '2024-10-23 19:09:47', '', 126, 'http://localhost/luna/site/?post_type=acf-field&#038;p=165', 29, 'acf-field', '', 0),
(166, 1, '2024-10-23 19:00:24', '2024-10-23 19:00:24', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'blog_image', 'publish', 'closed', 'closed', '', 'field_671947c88fef1', '', '', '2024-10-23 19:00:24', '2024-10-23 19:00:24', '', 165, 'http://localhost/luna/site/?post_type=acf-field&p=166', 0, 'acf-field', '', 0),
(167, 1, '2024-10-23 19:00:25', '2024-10-23 19:00:25', 'a:8:{s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:5:"d/m/Y";s:13:"return_format";s:5:"d/m/Y";s:9:"first_day";i:1;}', 'Date', 'blog_date', 'publish', 'closed', 'closed', '', 'field_671947c8902d6', '', '', '2024-10-23 19:00:25', '2024-10-23 19:00:25', '', 165, 'http://localhost/luna/site/?post_type=acf-field&p=167', 1, 'acf-field', '', 0),
(168, 1, '2024-10-23 19:00:26', '2024-10-23 19:00:26', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'b_title', 'publish', 'closed', 'closed', '', 'field_671947c8906c0', '', '', '2024-10-23 19:00:26', '2024-10-23 19:00:26', '', 165, 'http://localhost/luna/site/?post_type=acf-field&p=168', 2, 'acf-field', '', 0),
(169, 1, '2024-10-23 19:00:27', '2024-10-23 19:00:27', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Content', 'blog_content', 'publish', 'closed', 'closed', '', 'field_671947c890aa3', '', '', '2024-10-23 19:00:27', '2024-10-23 19:00:27', '', 165, 'http://localhost/luna/site/?post_type=acf-field&p=169', 3, 'acf-field', '', 0),
(170, 1, '2024-10-23 19:00:27', '2024-10-23 19:00:27', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Link', 'blog_link', 'publish', 'closed', 'closed', '', 'field_671947c890e8e', '', '', '2024-10-23 19:00:27', '2024-10-23 19:00:27', '', 165, 'http://localhost/luna/site/?post_type=acf-field&p=170', 4, 'acf-field', '', 0),
(171, 1, '2024-10-23 19:04:53', '2024-10-23 19:04:53', '<p>At Lune by Bhagya, we offer a range of curated styling packages designed to suit your personal style journey. Whether you need a quick style refresh or a comprehensive wardrobe overhaul, our packages provide expert guidance and personalized looks for every occasion. Explore our Silver, Gold, and Diamond options to find the perfect match for your fashion needs, and let us help you elevate your wardrobe with elegance and ease.</p>\r\n                     ', 'Styling Packages', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2024-10-23 19:04:53', '2024-10-23 19:04:53', '', 18, 'http://localhost/luna/site/?p=171', 0, 'revision', '', 0),
(172, 1, '2024-10-23 19:26:52', '2024-10-23 19:26:52', '<div class="faq">\r\n    <h3 class="faq-question">What is your return policy?</h3>\r\n    <div class="faq-answer">\r\n      <p>We offer a 30-day return policy on all items. Please ensure that the items are in their original condition and packaging.</p>\r\n    </div>\r\n  </div>\r\n\r\n  <div class="faq">\r\n    <h3 class="faq-question">Do you offer international shipping?</h3>\r\n    <div class="faq-answer">\r\n      <p>Yes, we ship to most countries around the world. Shipping fees and delivery times vary by location.</p>\r\n    </div>\r\n  </div>\r\n\r\n  <div class="faq">\r\n    <h3 class="faq-question">How can I track my order?</h3>\r\n    <div class="faq-answer">\r\n      <p>Once your order has shipped, you will receive an email with a tracking link to monitor the status of your delivery.</p>\r\n    </div>\r\n  </div>', 'FAQs', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2024-10-23 19:26:52', '2024-10-23 19:26:52', '', 22, 'http://localhost/luna/site/?p=172', 0, 'revision', '', 0),
(173, 1, '2024-10-23 19:31:04', '2024-10-23 19:31:04', '<p>I’d love to hear from you! Whether you have questions about my styling services, need personalized fashion advice, or are ready to begin your style journey, feel free to reach out</p>', 'Contact', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2024-10-23 19:31:04', '2024-10-23 19:31:04', '', 25, 'http://localhost/luna/site/?p=173', 0, 'revision', '', 0),
(174, 1, '2024-10-23 19:33:14', '2024-10-23 19:33:14', '<div class="input-group"><label for="name">Your Full name* </label>[text* your-name id:name placeholder "type here"]<span class="focus-border"></span><div class="input-group"><label for="email">email address*</label>[email* your-email id:email placeholder "type here"]<span class="focus-border"></span></div><div class="input-group"><label for="phone">Phone Number</label>[tel* tel-513 id:phone placeholder "type here"]<span class="focus-border"></span></div><div class="input-group"><label for="message">Message</label>[textarea* textarea-568 id:message placeholder "type here"]<span class="focus-border"></span></div>[submit "Send Message"]\n1\n[_site_title] "[your-subject]"\n[_site_title] <deepsonart@gmail.com>\n[_site_admin_email]\nFrom: [your-name] [your-email]\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [your-email]\n\n\n\n\n[_site_title] "[your-subject]"\n[_site_title] <deepsonart@gmail.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [_site_admin_email]\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nPlease fill out this field.\nThis field has a too long input.\nThis field has a too short input.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe uploaded file is too large.\nThere was an error uploading the file.\nPlease enter a date in YYYY-MM-DD format.\nThis field has a too early date.\nThis field has a too late date.\nPlease enter a number.\nThis field has a too small number.\nThis field has a too large number.\nThe answer to the quiz is incorrect.\nPlease enter an email address.\nPlease enter a URL.\nPlease enter a telephone number.', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2024-10-23 19:44:51', '2024-10-23 19:44:51', '', 0, 'http://localhost/luna/site/?post_type=wpcf7_contact_form&#038;p=174', 0, 'wpcf7_contact_form', '', 0),
(175, 1, '2024-10-23 19:50:39', '2024-10-23 19:50:39', '<h2>Curated Outfit Collages</h2>\r\n<p>Explore our collection of curated outfit collages, each designed to inspire and simplify your wardrobe choices. Whether you\'re looking for casual chic, office elegance, or special occasion glam, these collages provide versatile looks that blend fashion and functionality. Find the perfect ensemble for any moment, all thoughtfully styled to reflect your unique taste.\r\n', 'Portfolio', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2024-10-23 19:50:39', '2024-10-23 19:50:39', '', 20, 'http://localhost/luna/site/?p=175', 0, 'revision', '', 0),
(176, 1, '2024-10-24 04:48:32', '2024-10-24 04:48:32', 'A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.\r\n\r\nI know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.\r\n\r\nIt is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer.\r\n\r\nAnd I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape', 'Kristen Osborne', '', 'publish', 'open', 'closed', '', 'kristen-osborne', '', '', '2024-11-04 15:38:07', '2024-11-04 15:38:07', '', 0, 'http://localhost/luna/site/?post_type=outfit&#038;p=176', 0, 'outfit', '', 0),
(177, 1, '2024-10-24 04:48:32', '2024-10-24 04:48:32', '', 'Kristen Osborne', '', 'inherit', 'closed', 'closed', '', '176-revision-v1', '', '', '2024-10-24 04:48:32', '2024-10-24 04:48:32', '', 176, 'http://localhost/luna/site/?p=177', 0, 'revision', '', 0),
(178, 1, '2024-10-24 04:51:18', '2024-10-24 04:51:18', '', 'detailed-one', '', 'inherit', 'open', 'closed', '', 'detailed-one', '', '', '2024-10-24 04:51:18', '2024-10-24 04:51:18', '', 176, 'http://localhost/luna/site/wp-content/uploads/2024/10/detailed-one.jpg', 0, 'attachment', 'image/jpeg', 0),
(179, 1, '2024-10-24 04:52:17', '2024-10-24 04:52:17', '<p>A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.</p>\r\n<p> I know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.</p>\r\n<p>It is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer. </p>\r\n<p>And I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape</p>', 'Kristen Osborne', '', 'inherit', 'closed', 'closed', '', '176-revision-v1', '', '', '2024-10-24 04:52:17', '2024-10-24 04:52:17', '', 176, 'http://localhost/luna/site/?p=179', 0, 'revision', '', 0),
(180, 1, '2024-10-24 04:57:06', '2024-10-24 04:57:06', '<p>A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.</p><span data-mce-type="bookmark" style="display: inline-block; width: 0px; overflow: hidden; line-height: 0;" class="mce_SELRES_start">﻿</span>\n<p> I know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.</p>\n<p>It is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer. </p>\n<p>And I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape</p>', 'Kristen Osborne', '', 'inherit', 'closed', 'closed', '', '176-autosave-v1', '', '', '2024-10-24 04:57:06', '2024-10-24 04:57:06', '', 176, 'http://localhost/luna/site/?p=180', 0, 'revision', '', 0),
(181, 1, '2024-10-24 04:57:06', '2024-10-24 04:57:06', 'A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.\r\n\r\nI know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.\r\n\r\nIt is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer.\r\n\r\nAnd I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape', 'Kristen Osborne', '', 'inherit', 'closed', 'closed', '', '176-revision-v1', '', '', '2024-10-24 04:57:06', '2024-10-24 04:57:06', '', 176, 'http://localhost/luna/site/?p=181', 0, 'revision', '', 0),
(182, 1, '2024-10-24 05:06:06', '2024-10-24 05:06:06', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:6:"outfit";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Outfit Details', 'outfit-details', 'publish', 'closed', 'closed', '', 'group_6719d45fb625b', '', '', '2024-10-25 11:59:37', '2024-10-25 11:59:37', '', 0, 'http://localhost/luna/site/?post_type=acf-field-group&#038;p=182', 0, 'acf-field-group', '', 0),
(183, 1, '2024-10-24 05:06:06', '2024-10-24 05:06:06', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Thumbnail Image Section', 'thumbnail_image_section', 'publish', 'closed', 'closed', '', 'field_6719d54590078', '', '', '2024-10-24 05:06:06', '2024-10-24 05:06:06', '', 182, 'http://localhost/luna/site/?post_type=acf-field&p=183', 0, 'acf-field', '', 0),
(184, 1, '2024-10-24 05:06:07', '2024-10-24 05:06:07', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Thumbnail Image', 'outfit_thumbnail_image', 'publish', 'closed', 'closed', '', 'field_6719d47790076', '', '', '2024-10-24 05:06:07', '2024-10-24 05:06:07', '', 182, 'http://localhost/luna/site/?post_type=acf-field&p=184', 1, 'acf-field', '', 0),
(185, 1, '2024-10-24 05:06:08', '2024-10-24 05:06:08', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Position', 'outfit_position', 'publish', 'closed', 'closed', '', 'field_6719d53390077', '', '', '2024-10-24 05:06:08', '2024-10-24 05:06:08', '', 182, 'http://localhost/luna/site/?post_type=acf-field&p=185', 2, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(186, 1, '2024-10-24 05:06:09', '2024-10-24 05:06:09', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Image Gallery Section', 'image_gallery_section', 'publish', 'closed', 'closed', '', 'field_6719d56f90079', '', '', '2024-10-24 05:06:09', '2024-10-24 05:06:09', '', 182, 'http://localhost/luna/site/?post_type=acf-field&p=186', 3, 'acf-field', '', 0),
(187, 1, '2024-10-24 05:06:09', '2024-10-24 05:06:09', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Gallery Images', 'outfit_gallery_images', 'publish', 'closed', 'closed', '', 'field_6719d58e9007a', '', '', '2024-10-24 05:06:09', '2024-10-24 05:06:09', '', 182, 'http://localhost/luna/site/?post_type=acf-field&p=187', 4, 'acf-field', '', 0),
(188, 1, '2024-10-24 05:06:09', '2024-10-24 05:06:09', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'gal_image', 'publish', 'closed', 'closed', '', 'field_6719d5a79007b', '', '', '2024-10-24 05:06:09', '2024-10-24 05:06:09', '', 187, 'http://localhost/luna/site/?post_type=acf-field&p=188', 0, 'acf-field', '', 0),
(189, 1, '2024-10-24 05:07:38', '2024-10-24 05:07:38', '', 'img-seven', '', 'inherit', 'open', 'closed', '', 'img-seven', '', '', '2024-10-24 05:07:38', '2024-10-24 05:07:38', '', 176, 'http://localhost/luna/site/wp-content/uploads/2024/10/img-seven.jpg', 0, 'attachment', 'image/jpeg', 0),
(190, 1, '2024-10-24 05:08:26', '2024-10-24 05:08:26', '', 'detailed-three', '', 'inherit', 'open', 'closed', '', 'detailed-three', '', '', '2024-10-24 05:08:26', '2024-10-24 05:08:26', '', 176, 'http://localhost/luna/site/wp-content/uploads/2024/10/detailed-three.jpg', 0, 'attachment', 'image/jpeg', 0),
(191, 1, '2024-10-24 05:08:28', '2024-10-24 05:08:28', '', 'detailed-two', '', 'inherit', 'open', 'closed', '', 'detailed-two', '', '', '2024-10-24 05:08:28', '2024-10-24 05:08:28', '', 176, 'http://localhost/luna/site/wp-content/uploads/2024/10/detailed-two.jpg', 0, 'attachment', 'image/jpeg', 0),
(192, 1, '2024-10-24 05:08:46', '2024-10-24 05:08:46', 'A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.\r\n\r\nI know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.\r\n\r\nIt is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer.\r\n\r\nAnd I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape', 'Kristen Osborne', '', 'inherit', 'closed', 'closed', '', '176-revision-v1', '', '', '2024-10-24 05:08:46', '2024-10-24 05:08:46', '', 176, 'http://localhost/luna/site/?p=192', 0, 'revision', '', 0),
(193, 1, '2024-10-24 05:10:37', '2024-10-24 05:10:37', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Outfit Ideas', 'outfit_ideas', 'publish', 'closed', 'closed', '', 'field_6719d66e066b9', '', '', '2024-10-24 05:12:13', '2024-10-24 05:12:13', '', 182, 'http://localhost/luna/site/?post_type=acf-field&#038;p=193', 6, 'acf-field', '', 0),
(194, 1, '2024-10-24 05:10:38', '2024-10-24 05:10:38', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'outfit_idea_image', 'publish', 'closed', 'closed', '', 'field_6719d688066ba', '', '', '2024-10-24 05:10:38', '2024-10-24 05:10:38', '', 193, 'http://localhost/luna/site/?post_type=acf-field&p=194', 0, 'acf-field', '', 0),
(195, 1, '2024-10-24 05:10:39', '2024-10-24 05:10:39', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Details', 'oufit_idea_details', 'publish', 'closed', 'closed', '', 'field_6719d6af066bb', '', '', '2024-10-24 05:10:39', '2024-10-24 05:10:39', '', 193, 'http://localhost/luna/site/?post_type=acf-field&p=195', 1, 'acf-field', '', 0),
(196, 1, '2024-10-24 05:12:12', '2024-10-24 05:12:12', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Outfit Ideas Section', 'outfit_ideas_section_copy', 'publish', 'closed', 'closed', '', 'field_6719d7045f87c', '', '', '2024-10-24 05:12:12', '2024-10-24 05:12:12', '', 182, 'http://localhost/luna/site/?post_type=acf-field&p=196', 5, 'acf-field', '', 0),
(197, 1, '2024-10-24 05:12:52', '2024-10-24 05:12:52', '', 'detailed-five', '', 'inherit', 'open', 'closed', '', 'detailed-five', '', '', '2024-10-24 05:12:52', '2024-10-24 05:12:52', '', 176, 'http://localhost/luna/site/wp-content/uploads/2024/10/detailed-five.jpg', 0, 'attachment', 'image/jpeg', 0),
(198, 1, '2024-10-24 05:12:55', '2024-10-24 05:12:55', '', 'detailed-four', '', 'inherit', 'open', 'closed', '', 'detailed-four-2', '', '', '2024-10-24 05:12:55', '2024-10-24 05:12:55', '', 176, 'http://localhost/luna/site/wp-content/uploads/2024/10/detailed-four-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(199, 1, '2024-10-24 05:12:57', '2024-10-24 05:12:57', '', 'detailed-six', '', 'inherit', 'open', 'closed', '', 'detailed-six', '', '', '2024-10-24 05:12:57', '2024-10-24 05:12:57', '', 176, 'http://localhost/luna/site/wp-content/uploads/2024/10/detailed-six.jpg', 0, 'attachment', 'image/jpeg', 0),
(200, 1, '2024-10-24 05:15:56', '2024-10-24 05:15:56', 'A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.\r\n\r\nI know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.\r\n\r\nIt is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer.\r\n\r\nAnd I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape', 'Kristen Osborne', '', 'inherit', 'closed', 'closed', '', '176-revision-v1', '', '', '2024-10-24 05:15:56', '2024-10-24 05:15:56', '', 176, 'http://localhost/luna/site/?p=200', 0, 'revision', '', 0),
(201, 1, '2024-10-24 05:25:21', '2024-10-24 05:25:21', 'A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.\r\n\r\nI know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.\r\n\r\nIt is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer.\r\n\r\nAnd I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape', 'Vi Rodriguez', '', 'publish', 'open', 'closed', '123', 'vi-rodriguez', '', '', '2024-11-04 07:12:00', '2024-11-04 07:12:00', '', 0, 'http://localhost/luna/site/outfit/kristen-osborne-copy/', 0, 'outfit', '', 0),
(202, 1, '2024-10-24 05:25:40', '2024-10-24 05:25:40', 'A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.\r\n\r\nI know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.\r\n\r\nIt is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer.\r\n\r\nAnd I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape', 'Vi Rodriguez', '', 'inherit', 'closed', 'closed', '', '201-revision-v1', '', '', '2024-10-24 05:25:40', '2024-10-24 05:25:40', '', 201, 'http://localhost/luna/site/?p=202', 0, 'revision', '', 0),
(203, 1, '2024-10-24 05:26:06', '2024-10-24 05:26:06', '', 'img-six', '', 'inherit', 'open', 'closed', '', 'img-six', '', '', '2024-10-24 05:26:06', '2024-10-24 05:26:06', '', 201, 'http://localhost/luna/site/wp-content/uploads/2024/10/img-six.jpg', 0, 'attachment', 'image/jpeg', 0),
(204, 1, '2024-10-24 05:26:15', '2024-10-24 05:26:15', 'A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.\r\n\r\nI know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.\r\n\r\nIt is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer.\r\n\r\nAnd I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape', 'Vi Rodriguez', '', 'inherit', 'closed', 'closed', '', '201-revision-v1', '', '', '2024-10-24 05:26:15', '2024-10-24 05:26:15', '', 201, 'http://localhost/luna/site/?p=204', 0, 'revision', '', 0),
(205, 1, '2024-10-24 05:59:43', '2024-10-24 05:59:43', 'In today’s competitive fashion industry, a strong lookbook is key to standing out. Whether you’re launching a new collection or updating your wardrobe, a lookbook stylist can be the difference between ordinary and extraordinary. Here’s why every brand, big or small, needs a professional stylist for their lookbook:\r\n\r\n<strong>Creates a Lasting Impression:</strong> A stylist ensures that every piece in your collection is presented in the most flattering way, leaving a lasting impression on potential buyers or followers.\r\n\r\n<strong>Consistency in Style:</strong> With a professional stylist, your lookbook will have a consistent theme, color scheme, and styling, creating a strong, unified brand identity.\r\n\r\n<strong>Maximizing Visual Appeal:</strong> A stylist knows how to highlight the best features of each garment or accessory, ensuring they shine in photos and grab the attention of your audience.\r\n\r\n<strong>Target Audience Focused:</strong> A lookbook stylist tailors the outfits and aesthetics to appeal directly to your target demographic, ensuring the styles resonate with the right audience.\r\n\r\n<strong>Enhancing Marketing Efforts:</strong> A beautifully styled lookbook can be used across multiple marketing channels, from your website to social media, helping to attract more attention and boost sales.\r\n\r\nUltimately, a professional lookbook stylist takes the pressure off, giving you a polished, high-quality visual portfolio that can transform your fashion collection or personal wardrobe into something truly remarkable.', 'The Power of a Lookbook Stylist: Why Every Brand Needs One', '', 'publish', 'open', 'closed', '', 'he-power-of-a-lookbook-stylist-why-every-brand-needs-one', '', '', '2024-10-25 06:28:40', '2024-10-25 06:28:40', '', 0, 'http://localhost/luna/site/?post_type=blogs&#038;p=205', 0, 'blogs', '', 0),
(207, 1, '2024-10-24 05:59:43', '2024-10-24 05:59:43', '<p>This post could delve into the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity. nto the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity.nto the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity. </p>\r\n<ul>\r\n<li>logo design, and overall</li>\r\n<li>Brand Identity</li>\r\n</ul>', 'Building a Brand Identity', '', 'inherit', 'closed', 'closed', '', '205-revision-v1', '', '', '2024-10-24 05:59:43', '2024-10-24 05:59:43', '', 205, 'http://localhost/luna/site/?p=207', 0, 'revision', '', 0),
(208, 1, '2024-10-24 06:09:53', '2024-10-24 06:09:53', 'In the fast-paced world of fashion, staying relevant and on-trend can be a challenge. That\'s where a lookbook stylist comes in! A lookbook stylist not only curates outfits but also creates a cohesive visual story that showcases your personal style, brand identity, or seasonal collections. Here\'s why hiring a lookbook stylist can elevate your fashion game:\r\n\r\n<strong>Professional Expertise:</strong> Lookbook stylists have a deep understanding of fashion trends, color palettes, and garment combinations that will make you stand out.\r\n\r\n<strong>Brand Storytelling:</strong> Whether you\'re an individual or a brand, a stylist helps in telling your story through fashion, using each look to represent a mood or message.\r\n\r\n<strong>Time-Saving:</strong> Let’s face it, styling a cohesive lookbook takes time and creativity. Hiring a stylist allows you to focus on other aspects of your business or personal brand.\r\n\r\n<strong>Access to Exclusive Pieces:</strong> Stylists often have connections in the fashion industry, giving them access to unique and high-end pieces that can elevate your collection.\r\n\r\n<strong>A Polished Look:</strong> A professional stylist ensures that each outfit and accessory works together seamlessly, creating a visually appealing and cohesive lookbook that captures attention.\r\n\r\nFrom conceptualizing the overall aesthetic to selecting individual items, a lookbook stylist helps bring your fashion vision to life.', 'Elevate Your Fashion Game: Why You Need a Lookbook Stylist', 'In the fast-paced world of fashion, staying relevant and on-trend can be a challenge.', 'publish', 'open', 'closed', '', 'elevate-your-fashion-game-why-you-need-a-lookbook-stylist', '', '', '2024-10-25 06:27:56', '2024-10-25 06:27:56', '', 0, 'http://localhost/luna/site/blogs/building-a-brand-identity-copy/', 0, 'blogs', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(209, 1, '2024-10-24 06:10:10', '2024-10-24 06:10:10', '<p>This post could delve into the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity. nto the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity.nto the essential elements of brand styling, including color theory, typography, logo design, and overall visual identity. </p>\r\n<ul>\r\n<li>logo design, and overall</li>\r\n<li>Brand Identity</li>\r\n</ul>', 'Building a Brand Identity', '', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', '2024-10-24 06:10:10', '2024-10-24 06:10:10', '', 208, 'http://localhost/luna/site/?p=209', 0, 'revision', '', 0),
(210, 1, '2024-10-24 06:16:15', '2024-10-24 06:16:15', '<p>A few things I would like to know about your personal style, preferences, and occasion details. This will give me a starting point, and a direction to follow while I curate a look book for you. Please answer as accurately as you can. My outfit picks for you will be solely based on the response you give me for these questions. :)</p>', 'Styling Questionnaire', '', 'publish', 'closed', 'closed', '', 'styling-questionnaire', '', '', '2024-10-25 11:54:45', '2024-10-25 11:54:45', '', 0, 'http://localhost/luna/site/?page_id=210', 0, 'page', '', 0),
(211, 1, '2024-10-24 06:16:15', '2024-10-24 06:16:15', '<p>A few things I would like to know about your personal style, preferences, and occasion details. This will give me a starting point, and a direction to follow while I curate a look book for you. Please answer as accurately as you can. My outfit picks for you will be solely based on the response you give me for these questions. :)</p>', 'Styling Questionnaire', '', 'inherit', 'closed', 'closed', '', '210-revision-v1', '', '', '2024-10-24 06:16:15', '2024-10-24 06:16:15', '', 210, 'http://localhost/luna/site/?p=211', 0, 'revision', '', 0),
(212, 1, '2024-10-24 07:47:18', '2024-10-24 07:47:18', '{"blogname":{"value":"Lune by Bhagya","type":"option","user_id":1,"date_modified_gmt":"2024-10-24 07:36:29"},"blogdescription":{"value":"We see personal style as more than mere clothing\\u2014it\'s a language of its own, a silent yet powerful expression of who you are and how you move through the world.","type":"option","user_id":1,"date_modified_gmt":"2024-10-24 07:36:29"}}', '', '', 'trash', 'closed', 'closed', '', '75f8f545-7a54-4816-b98f-fd4fc2b340fc', '', '', '2024-10-24 07:47:18', '2024-10-24 07:47:18', '', 0, 'https://localhost/luna/site/?p=212', 0, 'customize_changeset', '', 0),
(213, 1, '2024-10-24 07:48:43', '2024-10-24 07:48:43', '', 'lune', '', 'inherit', 'open', 'closed', '', 'lune', '', '', '2024-10-24 07:48:43', '2024-10-24 07:48:43', '', 0, 'https://localhost/luna/site/wp-content/uploads/2024/10/lune.png', 0, 'attachment', 'image/png', 0),
(214, 1, '2024-10-24 07:48:46', '2024-10-24 07:48:46', 'https://localhost/luna/site/wp-content/uploads/2024/10/cropped-lune.png', 'cropped-lune.png', '', 'inherit', 'open', 'closed', '', 'cropped-lune-png', '', '', '2024-10-24 07:48:46', '2024-10-24 07:48:46', '', 213, 'https://localhost/luna/site/wp-content/uploads/2024/10/cropped-lune.png', 0, 'attachment', 'image/png', 0),
(215, 1, '2024-10-24 07:48:50', '2024-10-24 07:48:50', '{"site_icon":{"value":214,"type":"option","user_id":1,"date_modified_gmt":"2024-10-24 07:48:50"}}', '', '', 'trash', 'closed', 'closed', '', '36c015d2-0dcb-445f-aef4-459d2f1e20f7', '', '', '2024-10-24 07:48:50', '2024-10-24 07:48:50', '', 0, 'https://localhost/luna/site/36c015d2-0dcb-445f-aef4-459d2f1e20f7/', 0, 'customize_changeset', '', 0),
(216, 1, '2024-10-24 12:53:15', '2024-10-24 12:53:15', '', 'contact-image', '', 'inherit', 'open', 'closed', '', 'contact-image', '', '', '2024-10-24 12:53:15', '2024-10-24 12:53:15', '', 25, 'https://localhost/luna/site/wp-content/uploads/2024/10/contact-image.jpg', 0, 'attachment', 'image/jpeg', 0),
(217, 1, '2024-10-24 13:48:18', '2024-10-24 13:48:18', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-10-24 13:48:18', '2024-10-24 13:48:18', '', 6, 'https://localhost/luna/site/?p=217', 0, 'revision', '', 0),
(218, 1, '2024-10-24 14:04:49', '2024-10-24 14:04:49', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:17:"template-blog.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Blog Page Settings', 'blog-page-settings', 'publish', 'closed', 'closed', '', 'group_671a537310747', '', '', '2024-10-24 14:04:49', '2024-10-24 14:04:49', '', 0, 'https://localhost/luna/site/?post_type=acf-field-group&#038;p=218', 0, 'acf-field-group', '', 0),
(219, 1, '2024-10-24 14:04:49', '2024-10-24 14:04:49', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Page Title', 'page_title', 'publish', 'closed', 'closed', '', 'field_671a5393b6210', '', '', '2024-10-24 14:04:49', '2024-10-24 14:04:49', '', 218, 'https://localhost/luna/site/?post_type=acf-field&p=219', 0, 'acf-field', '', 0),
(220, 1, '2024-10-24 14:04:49', '2024-10-24 14:04:49', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Scrolling Text', 'scrolling_text', 'publish', 'closed', 'closed', '', 'field_671a53a1b6211', '', '', '2024-10-24 14:04:49', '2024-10-24 14:04:49', '', 218, 'https://localhost/luna/site/?post_type=acf-field&p=220', 1, 'acf-field', '', 0),
(221, 1, '2024-10-24 14:04:49', '2024-10-24 14:04:49', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'sc_text', 'publish', 'closed', 'closed', '', 'field_671a53f3b6212', '', '', '2024-10-24 14:04:49', '2024-10-24 14:04:49', '', 220, 'https://localhost/luna/site/?post_type=acf-field&p=221', 0, 'acf-field', '', 0),
(222, 1, '2024-10-24 14:05:42', '2024-10-24 14:05:42', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2024-10-24 14:05:42', '2024-10-24 14:05:42', '', 36, 'https://localhost/luna/site/?p=222', 0, 'revision', '', 0),
(223, 1, '2024-11-06 08:58:14', '2024-10-25 04:03:41', ' ', '', '', 'publish', 'closed', 'closed', '', '223', '', '', '2024-11-06 08:58:14', '2024-11-06 08:58:14', '', 0, 'https://localhost/luna/site/?p=223', 5, 'nav_menu_item', '', 0),
(224, 1, '2024-11-06 08:58:14', '2024-10-25 04:03:59', '', 'Blogs', '', 'publish', 'closed', 'closed', '', '224', '', '', '2024-11-06 08:58:14', '2024-11-06 08:58:14', '', 0, 'https://localhost/luna/site/?p=224', 7, 'nav_menu_item', '', 0),
(225, 1, '2024-10-25 05:00:18', '2024-10-25 05:00:18', 'In the fast-paced world of fashion, staying relevant and on-trend can be a challenge. That\'s where a lookbook stylist comes in! A lookbook stylist not only curates outfits but also creates a cohesive visual story that showcases your personal style, brand identity, or seasonal collections. Here\'s why hiring a lookbook stylist can elevate your fashion game:\n\n<strong>Professional Expertise:</strong> Lookbook stylists have a deep understanding of fashion trends, color palettes, and garment combinations that will make you stand out.\n\n<strong>Brand Storytelling:</strong> Whether you\'re an individual or a brand, a stylist helps in telling your story through fashion, using each look to represent a mood or message.\n\n<strong>Time-Saving:</strong> Let’s face it, styling a cohesive lookbook takes time and creativity. Hiring a stylist allows you to focus on other aspects of your business or personal brand.\n\n<strong>Access to Exclusive Pieces:</strong> Stylists often have connections in the fashion industry, giving them access to unique and high-end pieces that can elevate your collection.\n\n<strong>A Polished Look:</strong> A professional stylist ensures that each outfit and accessory works together seamlessly, creating a visually appealing and cohesive lookbook that captures attention.\n\nFrom conceptualizing the overall aesthetic to selecting individual items, a lookbook stylist helps bring your fashion vision to life.', 'Elevate Your Fashion Game: Why You Need a Lookbook Stylist', 'In the fast-paced world of fashion, staying relevant and on-trend can be a challenge.', 'inherit', 'closed', 'closed', '', '208-autosave-v1', '', '', '2024-10-25 05:00:18', '2024-10-25 05:00:18', '', 208, 'https://localhost/luna/site/?p=225', 0, 'revision', '', 0),
(226, 1, '2024-10-25 05:00:31', '2024-10-25 05:00:31', 'In the fast-paced world of fashion, staying relevant and on-trend can be a challenge. That\'s where a lookbook stylist comes in! A lookbook stylist not only curates outfits but also creates a cohesive visual story that showcases your personal style, brand identity, or seasonal collections. Here\'s why hiring a lookbook stylist can elevate your fashion game:\r\n\r\n<strong>Professional Expertise:</strong> Lookbook stylists have a deep understanding of fashion trends, color palettes, and garment combinations that will make you stand out.\r\n\r\n<strong>Brand Storytelling:</strong> Whether you\'re an individual or a brand, a stylist helps in telling your story through fashion, using each look to represent a mood or message.\r\n\r\n<strong>Time-Saving:</strong> Let’s face it, styling a cohesive lookbook takes time and creativity. Hiring a stylist allows you to focus on other aspects of your business or personal brand.\r\n\r\n<strong>Access to Exclusive Pieces:</strong> Stylists often have connections in the fashion industry, giving them access to unique and high-end pieces that can elevate your collection.\r\n\r\n<strong>A Polished Look:</strong> A professional stylist ensures that each outfit and accessory works together seamlessly, creating a visually appealing and cohesive lookbook that captures attention.\r\n\r\nFrom conceptualizing the overall aesthetic to selecting individual items, a lookbook stylist helps bring your fashion vision to life.', 'Elevate Your Fashion Game: Why You Need a Lookbook Stylist', 'In the fast-paced world of fashion, staying relevant and on-trend can be a challenge.', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', '2024-10-25 05:00:31', '2024-10-25 05:00:31', '', 208, 'https://localhost/luna/site/?p=226', 0, 'revision', '', 0),
(227, 1, '2024-10-25 05:01:43', '2024-10-25 05:01:43', 'In today’s competitive fashion industry, a strong lookbook is key to standing out. Whether you’re launching a new collection or updating your wardrobe, a lookbook stylist can be the difference between ordinary and extraordinary. Here’s why every brand, big or small, needs a professional stylist for their lookbook:\n\n<strong>Creates a Lasting Impression:</strong> A stylist ensures that every piece in your collection is presented in the most flattering way, leaving a lasting impression on potential buyers or followers.\n\n<strong>Consistency in Style:</strong> With a professional stylist, your lookbook will have a consistent theme, color scheme, and styling, creating a strong, unified brand identity.\n\n<strong>Maximizing Visual Appeal:</strong> A stylist knows how to highlight the best features of each garment or accessory, ensuring they shine in photos and grab the attention of your audience.\n\n<strong>Target Audience Focused:</strong> A lookbook stylist tailors the outfits and aesthetics to appeal directly to your target demographic, ensuring the styles resonate with the right audience.\n\nEnhancing Marketing Efforts: A beautifully styled lookbook can be used across multiple marketing channels, from your website to social media, helping to attract more attention and boost sales.\n\nUltimately, a professional lookbook stylist takes the pressure off, giving you a polished, high-quality visual portfolio that can transform your fashion collection or personal wardrobe into something truly remarkable.', 'The Power of a Lookbook Stylist: Why Every Brand Needs One', '', 'inherit', 'closed', 'closed', '', '205-autosave-v1', '', '', '2024-10-25 05:01:43', '2024-10-25 05:01:43', '', 205, 'https://localhost/luna/site/?p=227', 0, 'revision', '', 0),
(228, 1, '2024-10-25 05:01:47', '2024-10-25 05:01:47', 'In today’s competitive fashion industry, a strong lookbook is key to standing out. Whether you’re launching a new collection or updating your wardrobe, a lookbook stylist can be the difference between ordinary and extraordinary. Here’s why every brand, big or small, needs a professional stylist for their lookbook:\r\n\r\n<strong>Creates a Lasting Impression:</strong> A stylist ensures that every piece in your collection is presented in the most flattering way, leaving a lasting impression on potential buyers or followers.\r\n\r\n<strong>Consistency in Style:</strong> With a professional stylist, your lookbook will have a consistent theme, color scheme, and styling, creating a strong, unified brand identity.\r\n\r\n<strong>Maximizing Visual Appeal:</strong> A stylist knows how to highlight the best features of each garment or accessory, ensuring they shine in photos and grab the attention of your audience.\r\n\r\n<strong>Target Audience Focused:</strong> A lookbook stylist tailors the outfits and aesthetics to appeal directly to your target demographic, ensuring the styles resonate with the right audience.\r\n\r\n<strong>Enhancing Marketing Efforts:</strong> A beautifully styled lookbook can be used across multiple marketing channels, from your website to social media, helping to attract more attention and boost sales.\r\n\r\nUltimately, a professional lookbook stylist takes the pressure off, giving you a polished, high-quality visual portfolio that can transform your fashion collection or personal wardrobe into something truly remarkable.', 'The Power of a Lookbook Stylist: Why Every Brand Needs One', '', 'inherit', 'closed', 'closed', '', '205-revision-v1', '', '', '2024-10-25 05:01:47', '2024-10-25 05:01:47', '', 205, 'https://localhost/luna/site/?p=228', 0, 'revision', '', 0),
(229, 1, '2024-10-25 05:52:38', '2024-10-25 05:52:38', '<h1>My name is <span>Bhagya</span></h1>\r\n<p>I\'m a qualified fashion stylist with over 6 years of experience and a degree in fashion merchandising. I\'m also a certified color analyst, and seasoned fashion journalist, with a keen eye for putting together OOTDs. Clearly, I live and breathe fashion!</p>\r\n<p>At the heart of Lune by Bhagya is also my mother who, like most mothers, is a powerhouse of a manager! She keeps the engine running, while also taking the role of a shopping consultant in my projects!</p>\r\n<p>Together, we are a passionate mother-daughter duo, who are on a quest to helping men and women feel more confident in their own skin! We celebrate flaws and tailor outfit looks that embrace your unique features! Our styling solutions will change the way you feel about yourself, period.</p>', 'About Lune by Bhagya', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2024-10-25 05:52:38', '2024-10-25 05:52:38', '', 8, 'https://localhost/luna/site/?p=229', 0, 'revision', '', 0),
(230, 1, '2024-10-25 06:27:01', '2024-10-25 06:27:01', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"blogs";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Blog Date', 'blog-date', 'publish', 'closed', 'closed', '', 'group_671b3a0e7b562', '', '', '2024-10-25 06:27:01', '2024-10-25 06:27:01', '', 0, 'https://localhost/luna/site/?post_type=acf-field-group&#038;p=230', 0, 'acf-field-group', '', 0),
(231, 1, '2024-10-25 06:27:01', '2024-10-25 06:27:01', 'a:8:{s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:5:"d/m/Y";s:13:"return_format";s:5:"d/m/Y";s:9:"first_day";i:1;}', 'Date', 'blog_date', 'publish', 'closed', 'closed', '', 'field_671b3a1ab62ed', '', '', '2024-10-25 06:27:01', '2024-10-25 06:27:01', '', 230, 'https://localhost/luna/site/?post_type=acf-field&p=231', 0, 'acf-field', '', 0),
(232, 1, '2024-10-25 06:27:56', '2024-10-25 06:27:56', 'In the fast-paced world of fashion, staying relevant and on-trend can be a challenge. That\'s where a lookbook stylist comes in! A lookbook stylist not only curates outfits but also creates a cohesive visual story that showcases your personal style, brand identity, or seasonal collections. Here\'s why hiring a lookbook stylist can elevate your fashion game:\r\n\r\n<strong>Professional Expertise:</strong> Lookbook stylists have a deep understanding of fashion trends, color palettes, and garment combinations that will make you stand out.\r\n\r\n<strong>Brand Storytelling:</strong> Whether you\'re an individual or a brand, a stylist helps in telling your story through fashion, using each look to represent a mood or message.\r\n\r\n<strong>Time-Saving:</strong> Let’s face it, styling a cohesive lookbook takes time and creativity. Hiring a stylist allows you to focus on other aspects of your business or personal brand.\r\n\r\n<strong>Access to Exclusive Pieces:</strong> Stylists often have connections in the fashion industry, giving them access to unique and high-end pieces that can elevate your collection.\r\n\r\n<strong>A Polished Look:</strong> A professional stylist ensures that each outfit and accessory works together seamlessly, creating a visually appealing and cohesive lookbook that captures attention.\r\n\r\nFrom conceptualizing the overall aesthetic to selecting individual items, a lookbook stylist helps bring your fashion vision to life.', 'Elevate Your Fashion Game: Why You Need a Lookbook Stylist', 'In the fast-paced world of fashion, staying relevant and on-trend can be a challenge.', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', '2024-10-25 06:27:56', '2024-10-25 06:27:56', '', 208, 'https://localhost/luna/site/?p=232', 0, 'revision', '', 0),
(233, 1, '2024-10-25 06:28:40', '2024-10-25 06:28:40', 'In today’s competitive fashion industry, a strong lookbook is key to standing out. Whether you’re launching a new collection or updating your wardrobe, a lookbook stylist can be the difference between ordinary and extraordinary. Here’s why every brand, big or small, needs a professional stylist for their lookbook:\r\n\r\n<strong>Creates a Lasting Impression:</strong> A stylist ensures that every piece in your collection is presented in the most flattering way, leaving a lasting impression on potential buyers or followers.\r\n\r\n<strong>Consistency in Style:</strong> With a professional stylist, your lookbook will have a consistent theme, color scheme, and styling, creating a strong, unified brand identity.\r\n\r\n<strong>Maximizing Visual Appeal:</strong> A stylist knows how to highlight the best features of each garment or accessory, ensuring they shine in photos and grab the attention of your audience.\r\n\r\n<strong>Target Audience Focused:</strong> A lookbook stylist tailors the outfits and aesthetics to appeal directly to your target demographic, ensuring the styles resonate with the right audience.\r\n\r\n<strong>Enhancing Marketing Efforts:</strong> A beautifully styled lookbook can be used across multiple marketing channels, from your website to social media, helping to attract more attention and boost sales.\r\n\r\nUltimately, a professional lookbook stylist takes the pressure off, giving you a polished, high-quality visual portfolio that can transform your fashion collection or personal wardrobe into something truly remarkable.', 'The Power of a Lookbook Stylist: Why Every Brand Needs One', '', 'inherit', 'closed', 'closed', '', '205-revision-v1', '', '', '2024-10-25 06:28:40', '2024-10-25 06:28:40', '', 205, 'https://localhost/luna/site/?p=233', 0, 'revision', '', 0),
(234, 1, '2024-10-25 06:46:16', '2024-10-25 06:46:16', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:16:"template-faq.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'FAQ Page', 'faq-page', 'publish', 'closed', 'closed', '', 'group_671b3d9ca9330', '', '', '2024-10-25 06:46:23', '2024-10-25 06:46:23', '', 0, 'https://localhost/luna/site/?post_type=acf-field-group&#038;p=234', 0, 'acf-field-group', '', 0),
(235, 1, '2024-10-25 06:46:16', '2024-10-25 06:46:16', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Page Title', 'page_title', 'publish', 'closed', 'closed', '', 'field_671b3dac2232c', '', '', '2024-10-25 06:46:16', '2024-10-25 06:46:16', '', 234, 'https://localhost/luna/site/?post_type=acf-field&p=235', 0, 'acf-field', '', 0),
(236, 1, '2024-10-25 06:46:16', '2024-10-25 06:46:16', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'FAQ\'s', 'det_faqs', 'publish', 'closed', 'closed', '', 'field_671b3e662232d', '', '', '2024-10-25 06:46:16', '2024-10-25 06:46:16', '', 234, 'https://localhost/luna/site/?post_type=acf-field&p=236', 1, 'acf-field', '', 0),
(237, 1, '2024-10-25 06:46:16', '2024-10-25 06:46:16', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Question', 'faq_question', 'publish', 'closed', 'closed', '', 'field_671b3e862232e', '', '', '2024-10-25 06:46:16', '2024-10-25 06:46:16', '', 236, 'https://localhost/luna/site/?post_type=acf-field&p=237', 0, 'acf-field', '', 0),
(238, 1, '2024-10-25 06:46:16', '2024-10-25 06:46:16', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Answer', 'faq_answer', 'publish', 'closed', 'closed', '', 'field_671b3ea52232f', '', '', '2024-10-25 06:46:16', '2024-10-25 06:46:16', '', 236, 'https://localhost/luna/site/?post_type=acf-field&p=238', 1, 'acf-field', '', 0),
(239, 1, '2024-10-25 06:48:09', '2024-10-25 06:48:09', '<div class="faq">\r\n    <h3 class="faq-question">What is your return policy?</h3>\r\n    <div class="faq-answer">\r\n      <p>We offer a 30-day return policy on all items. Please ensure that the items are in their original condition and packaging.</p>\r\n    </div>\r\n  </div>\r\n\r\n  <div class="faq">\r\n    <h3 class="faq-question">Do you offer international shipping?</h3>\r\n    <div class="faq-answer">\r\n      <p>Yes, we ship to most countries around the world. Shipping fees and delivery times vary by location.</p>\r\n    </div>\r\n  </div>\r\n\r\n  <div class="faq">\r\n    <h3 class="faq-question">How can I track my order?</h3>\r\n    <div class="faq-answer">\r\n      <p>Once your order has shipped, you will receive an email with a tracking link to monitor the status of your delivery.</p>\r\n    </div>\r\n  </div>', 'FAQs', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2024-10-25 06:48:09', '2024-10-25 06:48:09', '', 22, 'https://localhost/luna/site/?p=239', 0, 'revision', '', 0),
(240, 1, '2024-10-25 07:00:46', '2024-10-25 07:00:46', '<div class="input-group">\r\n                <label for="name">Your Email* </label>[email* email-760 id:email placeholder "type here"]<span class="focus-border"></span>\r\n            </div>\r\n              <div class="input-group">\r\n                <label for="name">What is your name and occupation?* </label>[text* text-name id:name "type here"]<span class="focus-border"></span>\r\n            </div>\r\n            <div class="input-group">\r\n<label for="name">Please mention your height, weight, and skin complexion* </label>[text* text-height id:height "type here"]<span class="focus-border"></span>\r\n            </div>\r\n            <div class="input-group">\r\n                <label for="name">What is the occasion for which you need me to style you? Is it an event, a life episode, etc.? </label>[text* text-style id:style "type here"]<span class="focus-border"></span>\r\n            </div>\r\n            <div class="input-group">\r\n                <label for="name">Is there a theme or color palette to follow for the occasion/life series? If yes, please describe.  </label>[text* text-theme id:theme "type here"]<span class="focus-border"></span>\r\n            </div>\r\n            <div class="input-group">\r\n                <label for="name">Do you need links to buy, or just a picture-focused lookbook?* </label>[text* text-link placeholder "Upload 1 supported file: image. Max 100 MB."]<label for="file-upload" class="custom-file-upload">upload</label>[file file-lookbook limit:10mb filetypes:jpg|png id:look]<span class="focus-border"></span>\r\n            </div>            \r\n            <p>How would you describe your body shape?</p> \r\n             <div class="radio-group">\r\n[radio radio-bodyshape use_label_element default:1 "straight (more or less rectangular)" "triangle (narrow shoulders and wider hips)" "pear (narrow torso and wider hips)" "hourglass (wide shoulders and hips with a smaller waist)" "apple (narrow shoulders and hips with a wider middle portion)" "inverted triangle (wide shoulders and narrow hips)" "i\'m not sure"]        \r\n    </div>       \r\n       <p>Please provide an approximate list of your main measurements (Tip: The size of the top/shirt you usually buy will give you your shoulder/bust measurements, the size of the bottom wear will give you your waist/hip measurements) Alternatively, you can list the sizes of the top wear, bottom wear, footwear that you usually wear. Provide: Shoulder, bust, waist, hip, foot length </p>\r\n       <div class="input-group">\r\n[text* text-measurements id:measurements placeholder "type here"]<span class="focus-border"></span>\r\n            </div>\r\n            <div class="input-group">\r\n              <label for="name">Is there any part of your body that you are insecure about and would like not highlighted? E.g. a tummy, bulky arms, a heavy bust. etc.?</label>[text* text-insecure id:insecure placeholder "type here"]<span class="focus-border"></span>\r\n            </div>\r\n            <div class="input-group">\r\n              <label for="name">Is there any part of your body that you love and would like highlighted?E.g. your height, legs, arms. etc.?</label>[text* text-highlight id:highlight placeholder "type here"]<span class="focus-border"></span>\r\n            </div>\r\n                  <div class="input-group">\r\n              <label for="name">What are some brands and department stores you regularly purchase from? (E.g. Zara, ASOS, Nordstorm)</label>[text* text-brands id:brands placeholder "type here"]\r\n                <span class="focus-border"></span>\r\n            </div>\r\n             <div class="input-group">\r\n              <label for="name">If you are comfortable, please leave the name of the city and country you live in. This will help me curate products online that are available in your city.</label>[text* text-city id:city placeholder "type here"]<span class="focus-border"></span>\r\n            </div>\r\n            <div class="input-group">\r\n              <label for="name">Would you prefer a dressed up or a dressed down look for the occasion?*</label>[text* text-prefer id:prefer placeholder "type here"]<span class="focus-border"></span>\r\n            </div>\r\n              <div class="input-group">\r\n              <label for="name">Would you call yourself a minimalist (fewer accessories and details), or a maximalist (more accessories and details)?*</label>[text* text-call id:call placeholder "type here"]<span class="focus-border"></span>\r\n            </div>            \r\n            <p>What are some colors you typically incline towards. A quick look in your wardrobe will give you an idea.</p>\r\n            <div class="checkbox-container">\r\n[checkbox checkbox-colors use_label_element "i agree to the terms and conditions" "cool tones - blues, purples, greens" "colorful - colorful prints, outfits in many colors" "warm tones - yellows, oranges, reds"]       \r\n            </div>\r\n             <div class="input-group">\r\n              <label for="name">For the occasion, would you like to maintain your personal style or try something different?*</label>[text* text-maintain id:maintain placeholder "type here"]<span class="focus-border"></span>\r\n            </div>\r\n              <div class="radio-group">\r\n              <p>How comfortable are you to step out of your comfort zone?*</p>      \r\n        [radio radio-comfortzone id:comfirtzone use_label_element default:1 "not at all" "1" "2" "3" "4" "5" "quite comfortable - in the mood to experiment and adapt"]   \r\n    </div>\r\n           <div class="input-group">\r\n                <label for="name">If you have a vision in mind, please attach a few reference pictures of looks you can see yourself in. This will help me curate a look that you are more likely to love.</label>[text* text-reference id:reference placeholder "Upload 1 supported file: image. Max 100 MB."]<label for="file-upload" class="custom-file-upload">upload</label>[file file-refpicture limit:10mb filetypes:jpg|png id:refpicture]<span class="focus-border"></span>\r\n            </div>\r\n                 <div class="checkbox-container">\r\n                 <p>For the occasion or life episode, what is your priority?*</p>\r\n       [checkbox* checkbox-priority id:priority use_label_element "being comfortable and peaceful" "looking stylish and put together" "looking on-trend" "other:"]\r\n            </div>\r\n               <div class="radio-group">\r\n              <p>What is your preferred fit of outfits in general?*</p>   \r\n       [radio radio-fit id:fit use_label_element default:1 "loose and airy" "well-fitted" "something in between"]                \r\n    </div>\r\n            <div class="input-group">\r\n              <label for="name">Is there any other detail about yourself, your fashion preferences, or your personal requirements for this occasion that you would like me to consider when curating looks for you?*</label>[text* text-detail id:detail placeholder "type here"]<span class="focus-border"></span>\r\n            </div>\r\n          \r\n           \r\n      [submit "Submit"]\n1\n[_site_title] "[your-subject]"\n[_site_title] <wordpress@mwduat.com>\n[_site_admin_email]\nFrom: [your-name] [email-760]\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [email-760]\n\n\n\n\n[_site_title] "[your-subject]"\n[_site_title] <wordpress@mwduat.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [_site_admin_email]\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nPlease fill out this field.\nThis field has a too long input.\nThis field has a too short input.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe uploaded file is too large.\nThere was an error uploading the file.\nPlease enter a date in YYYY-MM-DD format.\nThis field has a too early date.\nThis field has a too late date.\nPlease enter a number.\nThis field has a too small number.\nThis field has a too large number.\nThe answer to the quiz is incorrect.\nPlease enter an email address.\nPlease enter a URL.\nPlease enter a telephone number.', 'Contact Styling', '', 'publish', 'closed', 'closed', '', 'contact-styling', '', '', '2024-10-25 08:20:03', '2024-10-25 08:20:03', '', 0, 'https://localhost/luna/site/?post_type=wpcf7_contact_form&#038;p=240', 0, 'wpcf7_contact_form', '', 0),
(241, 1, '2024-10-25 08:22:40', '2024-10-25 08:22:40', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Footer Contact Settings', 'footer_contact_settings', 'publish', 'closed', 'closed', '', 'field_671b554520a77', '', '', '2024-10-25 09:50:57', '2024-10-25 09:50:57', '', 111, 'https://localhost/luna/site/?post_type=acf-field&#038;p=241', 2, 'acf-field', '', 0),
(242, 1, '2024-10-25 09:16:28', '2024-10-25 09:16:28', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Scrolling Text', 'ft_scrolling_text', 'publish', 'closed', 'closed', '', 'field_671b61a437385', '', '', '2024-10-25 09:43:21', '2024-10-25 09:43:21', '', 111, 'https://localhost/luna/site/?post_type=acf-field&#038;p=242', 3, 'acf-field', '', 0),
(243, 1, '2024-10-25 09:16:28', '2024-10-25 09:16:28', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text', 'fs_text', 'publish', 'closed', 'closed', '', 'field_671b61cc37386', '', '', '2024-10-25 09:16:28', '2024-10-25 09:16:28', '', 242, 'https://localhost/luna/site/?post_type=acf-field&p=243', 0, 'acf-field', '', 0),
(244, 1, '2024-10-25 09:40:52', '2024-10-25 09:40:52', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Contact Number', 'ft_contact_number', 'publish', 'closed', 'closed', '', 'field_671b673036083', '', '', '2024-10-25 09:43:21', '2024-10-25 09:43:21', '', 111, 'https://localhost/luna/site/?post_type=acf-field&#038;p=244', 5, 'acf-field', '', 0),
(245, 1, '2024-10-25 09:40:52', '2024-10-25 09:40:52', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Email Id', 'ft_email_id', 'publish', 'closed', 'closed', '', 'field_671b674236084', '', '', '2024-10-25 09:43:21', '2024-10-25 09:43:21', '', 111, 'https://localhost/luna/site/?post_type=acf-field&#038;p=245', 7, 'acf-field', '', 0),
(246, 1, '2024-10-25 09:40:52', '2024-10-25 09:40:52', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Copyright Text', 'copyright_text', 'publish', 'closed', 'closed', '', 'field_671b676536085', '', '', '2024-10-25 09:43:21', '2024-10-25 09:43:21', '', 111, 'https://localhost/luna/site/?post_type=acf-field&#038;p=246', 9, 'acf-field', '', 0),
(247, 1, '2024-10-25 09:41:37', '2024-10-25 09:41:37', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Contact Icon', 'ft_contact_icon', 'publish', 'closed', 'closed', '', 'field_671b67ab04050', '', '', '2024-10-25 09:43:21', '2024-10-25 09:43:21', '', 111, 'https://localhost/luna/site/?post_type=acf-field&#038;p=247', 6, 'acf-field', '', 0),
(248, 1, '2024-10-25 09:41:37', '2024-10-25 09:41:37', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Email Icon', 'ft_email_icon', 'publish', 'closed', 'closed', '', 'field_671b67bd04051', '', '', '2024-10-25 09:43:21', '2024-10-25 09:43:21', '', 111, 'https://localhost/luna/site/?post_type=acf-field&#038;p=248', 8, 'acf-field', '', 0),
(249, 1, '2024-10-25 09:42:46', '2024-10-25 09:42:46', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Contact Settings', 'contact_settings', 'publish', 'closed', 'closed', '', 'field_671b67ec57d57', '', '', '2024-10-25 09:43:21', '2024-10-25 09:43:21', '', 111, 'https://localhost/luna/site/?post_type=acf-field&#038;p=249', 4, 'acf-field', '', 0),
(250, 1, '2024-10-25 09:43:20', '2024-10-25 09:43:20', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Logo Settings', 'logo_settings', 'publish', 'closed', 'closed', '', 'field_671b681de6ccf', '', '', '2024-10-25 09:43:20', '2024-10-25 09:43:20', '', 111, 'https://localhost/luna/site/?post_type=acf-field&p=250', 0, 'acf-field', '', 0),
(251, 1, '2024-10-25 11:14:25', '2024-10-25 11:14:25', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:20:"template-contact.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Contact Page Settings', 'contact-page-settings', 'publish', 'closed', 'closed', '', 'group_671b7a7de7cba', '', '', '2024-10-25 11:22:09', '2024-10-25 11:22:09', '', 0, 'https://localhost/luna/site/?post_type=acf-field-group&#038;p=251', 0, 'acf-field-group', '', 0),
(252, 1, '2024-10-25 11:15:08', '2024-10-25 11:15:08', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Heading', 'contact_heading', 'publish', 'closed', 'closed', '', 'field_671b7da8ebb4f', '', '', '2024-10-25 11:15:08', '2024-10-25 11:15:08', '', 251, 'https://localhost/luna/site/?post_type=acf-field&p=252', 0, 'acf-field', '', 0),
(253, 1, '2024-10-25 11:16:03', '2024-10-25 11:16:03', '<p>I’d love to hear from you! Whether you have questions about my styling services, need personalized fashion advice, or are ready to begin your style journey, feel free to reach out</p>', 'Contact', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2024-10-25 11:16:03', '2024-10-25 11:16:03', '', 25, 'https://localhost/luna/site/?p=253', 0, 'revision', '', 0),
(254, 1, '2024-10-25 11:19:54', '2024-10-25 11:19:54', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Contact Number', 'cn_number', 'publish', 'closed', 'closed', '', 'field_671b7e658f701', '', '', '2024-10-25 11:19:54', '2024-10-25 11:19:54', '', 251, 'https://localhost/luna/site/?post_type=acf-field&p=254', 1, 'acf-field', '', 0),
(255, 1, '2024-10-25 11:19:54', '2024-10-25 11:19:54', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Email ID', 'cn_email_id', 'publish', 'closed', 'closed', '', 'field_671b7e868f702', '', '', '2024-10-25 11:22:09', '2024-10-25 11:22:09', '', 251, 'https://localhost/luna/site/?post_type=acf-field&#038;p=255', 3, 'acf-field', '', 0),
(256, 1, '2024-10-25 11:19:54', '2024-10-25 11:19:54', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Form Heading', 'form_heading', 'publish', 'closed', 'closed', '', 'field_671b7eac8f703', '', '', '2024-10-25 11:22:09', '2024-10-25 11:22:09', '', 251, 'https://localhost/luna/site/?post_type=acf-field&#038;p=256', 5, 'acf-field', '', 0),
(257, 1, '2024-10-25 11:19:54', '2024-10-25 11:19:54', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Contact Form', 'contact_form', 'publish', 'closed', 'closed', '', 'field_671b7ecc8f704', '', '', '2024-10-25 11:22:09', '2024-10-25 11:22:09', '', 251, 'https://localhost/luna/site/?post_type=acf-field&#038;p=257', 6, 'acf-field', '', 0),
(258, 1, '2024-10-25 11:21:19', '2024-10-25 11:21:19', '<p>I’d love to hear from you! Whether you have questions about my styling services, need personalized fashion advice, or are ready to begin your style journey, feel free to reach out</p>', 'Contact', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2024-10-25 11:21:19', '2024-10-25 11:21:19', '', 25, 'https://localhost/luna/site/?p=258', 0, 'revision', '', 0),
(259, 1, '2024-10-25 11:22:09', '2024-10-25 11:22:09', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Contact Icon', 'cn_number_icon', 'publish', 'closed', 'closed', '', 'field_671b7f41a2988', '', '', '2024-10-25 11:22:09', '2024-10-25 11:22:09', '', 251, 'https://localhost/luna/site/?post_type=acf-field&p=259', 2, 'acf-field', '', 0),
(260, 1, '2024-10-25 11:22:09', '2024-10-25 11:22:09', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Email Icon', 'cn_email_icon', 'publish', 'closed', 'closed', '', 'field_671b7f4fa2989', '', '', '2024-10-25 11:22:09', '2024-10-25 11:22:09', '', 251, 'https://localhost/luna/site/?post_type=acf-field&p=260', 4, 'acf-field', '', 0),
(261, 1, '2024-10-25 11:23:27', '2024-10-25 11:23:27', '<p>I’d love to hear from you! Whether you have questions about my styling services, need personalized fashion advice, or are ready to begin your style journey, feel free to reach out</p>', 'Contact', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2024-10-25 11:23:27', '2024-10-25 11:23:27', '', 25, 'https://localhost/luna/site/?p=261', 0, 'revision', '', 0),
(262, 1, '2024-10-25 11:45:02', '2024-10-25 11:45:02', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-10-25 11:45:02', '2024-10-25 11:45:02', '', 6, 'https://localhost/luna/site/?p=262', 0, 'revision', '', 0),
(263, 1, '2024-10-25 11:53:38', '2024-10-25 11:53:38', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:27:"template-stylingcontact.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Form Shortcode', 'form-shortcode', 'publish', 'closed', 'closed', '', 'group_671b86985c894', '', '', '2024-10-25 11:53:39', '2024-10-25 11:53:39', '', 0, 'https://localhost/luna/site/?post_type=acf-field-group&#038;p=263', 0, 'acf-field-group', '', 0),
(264, 1, '2024-10-25 11:53:38', '2024-10-25 11:53:38', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Contact Form', 'st_contact_form', 'publish', 'closed', 'closed', '', 'field_671b869f6c69e', '', '', '2024-10-25 11:53:38', '2024-10-25 11:53:38', '', 263, 'https://localhost/luna/site/?post_type=acf-field&p=264', 0, 'acf-field', '', 0),
(265, 1, '2024-10-25 11:54:45', '2024-10-25 11:54:45', '<p>A few things I would like to know about your personal style, preferences, and occasion details. This will give me a starting point, and a direction to follow while I curate a look book for you. Please answer as accurately as you can. My outfit picks for you will be solely based on the response you give me for these questions. :)</p>', 'Styling Questionnaire', '', 'inherit', 'closed', 'closed', '', '210-revision-v1', '', '', '2024-10-25 11:54:45', '2024-10-25 11:54:45', '', 210, 'https://localhost/luna/site/?p=265', 0, 'revision', '', 0),
(267, 1, '2024-10-25 11:56:55', '2024-10-25 11:56:55', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'o_button_text', 'publish', 'closed', 'closed', '', 'field_671b8764f7b1a', '', '', '2024-10-25 11:59:47', '2024-10-25 11:59:47', '', 269, 'https://localhost/luna/site/?post_type=acf-field&#038;p=267', 0, 'acf-field', '', 0),
(268, 1, '2024-10-25 11:56:55', '2024-10-25 11:56:55', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Button Link', 'o_button_link', 'publish', 'closed', 'closed', '', 'field_671b8771f7b1b', '', '', '2024-10-25 11:59:47', '2024-10-25 11:59:47', '', 269, 'https://localhost/luna/site/?post_type=acf-field&#038;p=268', 1, 'acf-field', '', 0),
(269, 1, '2024-10-25 11:59:04', '2024-10-25 11:59:04', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:19:"template-outfit.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Portfolio Page', 'portfolio-page', 'publish', 'closed', 'closed', '', 'group_671b87c94e519', '', '', '2024-10-25 11:59:47', '2024-10-25 11:59:47', '', 0, 'https://localhost/luna/site/?post_type=acf-field-group&#038;p=269', 0, 'acf-field-group', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(271, 1, '2024-10-25 12:00:56', '2024-10-25 12:00:56', '<h2>Curated Outfit Collages</h2>\r\n<p>Explore our collection of curated outfit collages, each designed to inspire and simplify your wardrobe choices. Whether you\'re looking for casual chic, office elegance, or special occasion glam, these collages provide versatile looks that blend fashion and functionality. Find the perfect ensemble for any moment, all thoughtfully styled to reflect your unique taste.\r\n', 'Portfolio', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2024-10-25 12:00:56', '2024-10-25 12:00:56', '', 20, 'https://localhost/luna/site/?p=271', 0, 'revision', '', 0),
(272, 1, '2024-10-25 12:04:34', '2024-10-25 12:04:34', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Outfit Detail Page', 'outfit_detail_page', 'publish', 'closed', 'closed', '', 'field_671b88f488ea6', '', '', '2024-10-25 12:04:34', '2024-10-25 12:04:34', '', 111, 'https://localhost/luna/site/?post_type=acf-field&p=272', 10, 'acf-field', '', 0),
(273, 1, '2024-10-25 12:04:34', '2024-10-25 12:04:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Title', 'ot_button_title', 'publish', 'closed', 'closed', '', 'field_671b890a88ea7', '', '', '2024-10-25 12:04:34', '2024-10-25 12:04:34', '', 111, 'https://localhost/luna/site/?post_type=acf-field&p=273', 11, 'acf-field', '', 0),
(274, 1, '2024-10-25 12:04:34', '2024-10-25 12:04:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Button Text', 'ot_button_text', 'publish', 'closed', 'closed', '', 'field_671b892188ea8', '', '', '2024-10-25 12:04:34', '2024-10-25 12:04:34', '', 111, 'https://localhost/luna/site/?post_type=acf-field&p=274', 12, 'acf-field', '', 0),
(275, 1, '2024-10-25 12:04:34', '2024-10-25 12:04:34', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Button Link', 'ot_button_link', 'publish', 'closed', 'closed', '', 'field_671b892a88ea9', '', '', '2024-10-25 12:07:38', '2024-10-25 12:07:38', '', 111, 'https://localhost/luna/site/?post_type=acf-field&#038;p=275', 13, 'acf-field', '', 0),
(277, 1, '2024-11-03 05:48:35', '2024-11-03 05:48:35', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-11-03 05:48:35', '2024-11-03 05:48:35', '', 6, 'https://localhost/luna/site/?p=277', 0, 'revision', '', 0),
(278, 1, '2024-11-03 05:57:48', '2024-11-03 05:57:48', '', 'Services', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2024-11-03 05:57:48', '2024-11-03 05:57:48', '', 10, 'https://localhost/luna/site/?p=278', 0, 'revision', '', 0),
(279, 1, '2024-11-03 05:59:35', '2024-11-03 05:59:35', '<h2>Curated Outfit Collages</h2>\r\n<p>Explore our collection of curated outfit collages, each designed to inspire and simplify your wardrobe choices. Whether you\'re looking for casual chic, office elegance, or special occasion glam, these collages provide versatile looks that blend fashion and functionality. Find the perfect ensemble for any moment, all thoughtfully styled to reflect your unique taste.\r\n', 'Portfolio', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2024-11-03 05:59:35', '2024-11-03 05:59:35', '', 20, 'https://localhost/luna/site/?p=279', 0, 'revision', '', 0),
(280, 1, '2024-11-03 06:00:07', '2024-11-03 06:00:07', '<p>I’d love to hear from you! Whether you have questions about my styling services, need personalized fashion advice, or are ready to begin your style journey, feel free to reach out</p>', 'Reach out me', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2024-11-03 06:00:07', '2024-11-03 06:00:07', '', 25, 'https://localhost/luna/site/?p=280', 0, 'revision', '', 0),
(281, 1, '2024-11-06 08:57:34', '2024-11-03 06:02:14', '', 'Outfit Portfolio', '', 'publish', 'closed', 'closed', '', 'outfit-portfolio', '', '', '2024-11-06 08:57:34', '2024-11-06 08:57:34', '', 0, 'https://localhost/luna/site/?p=281', 3, 'nav_menu_item', '', 0),
(282, 1, '2024-11-03 06:08:59', '2024-11-03 06:08:59', '<p>I’d love to hear from you! Whether you have questions about my styling services, need personalized fashion advice, or are ready to begin your style journey, feel free to reach out</p>', 'Reach out me', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2024-11-03 06:08:59', '2024-11-03 06:08:59', '', 25, 'https://localhost/luna/site/?p=282', 0, 'revision', '', 0),
(283, 1, '2024-11-03 06:18:55', '2024-11-03 06:18:55', '<h2>Curated Outfit Collages</h2>\r\n<p>Explore our collection of curated outfit collages, each designed to inspire and simplify your wardrobe choices. Whether you\'re looking for casual chic, office elegance, or special occasion glam, these collages provide versatile looks that blend fashion and functionality. Find the perfect ensemble for any moment, all thoughtfully styled to reflect your unique taste.\r\n', 'Portfolio', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2024-11-03 06:18:55', '2024-11-03 06:18:55', '', 20, 'https://localhost/luna/site/?p=283', 0, 'revision', '', 0),
(284, 1, '2024-11-03 06:19:23', '2024-11-03 06:19:23', '<h2>Curated Outfit Collages</h2>\r\n<p>Explore our collection of curated outfit collages, each designed to inspire and simplify your wardrobe choices. Whether you\'re looking for casual chic, office elegance, or special occasion glam, these collages provide versatile looks that blend fashion and functionality. Find the perfect ensemble for any moment, all thoughtfully styled to reflect your unique taste.\r\n', 'Portfolio', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2024-11-03 06:19:23', '2024-11-03 06:19:23', '', 20, 'https://localhost/luna/site/?p=284', 0, 'revision', '', 0),
(285, 1, '2024-11-04 09:06:48', '2024-11-04 09:06:48', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Link', 'service_link', 'publish', 'closed', 'closed', '', 'field_67288e8d0a639', '', '', '2024-11-04 09:06:48', '2024-11-04 09:06:48', '', 119, 'https://localhost/luna/site/?post_type=acf-field&p=285', 3, 'acf-field', '', 0),
(286, 1, '2024-11-04 09:07:49', '2024-11-04 09:07:49', '', 'Services', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2024-11-04 09:07:49', '2024-11-04 09:07:49', '', 10, 'https://localhost/luna/site/?p=286', 0, 'revision', '', 0),
(287, 1, '2024-11-05 07:35:28', '2024-11-05 07:35:28', 'A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.\r\n\r\nI know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.\r\n\r\nIt is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer.\r\n\r\nAnd I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape', 'Vi Rodriguez new', '', 'publish', 'open', 'closed', '123', 'vi-rodriguez-new', '', '', '2024-11-05 07:38:35', '2024-11-05 07:38:35', '', 0, 'https://localhost/luna/site/outfit/vi-rodriguez-copy/', 0, 'outfit', '', 0),
(288, 1, '2024-11-05 07:38:05', '2024-11-05 07:38:05', 'A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.\r\n\r\nI know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.\r\n\r\nIt is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer.\r\n\r\nAnd I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape', 'Vi Rodriguez Copy', '', 'inherit', 'closed', 'closed', '', '287-revision-v1', '', '', '2024-11-05 07:38:05', '2024-11-05 07:38:05', '', 287, 'https://localhost/luna/site/?p=288', 0, 'revision', '', 0),
(289, 1, '2024-11-05 07:38:35', '2024-11-05 07:38:35', 'A very elegant, sophisticated and simple pencil dress for work. It has a high neck so it will conceal your tattoos.\r\n\r\nI know it is not the straight silhouette that you usually wear to conceal your midsection, but this dress has plaid prints which creates an illusionary effect. Hence, it will perfectly hide your midsection and highlight the good parts of your body. On top of that it also has pleated details, which will further help hide your unflattering areas and yet accentuate your feminine figure.\r\n\r\nIt is also sleeveless, which will help show off your shoulder. A little bit of skin show is the best way to make your body appear slimmer.\r\n\r\nAnd I’m saying that only because you seem insecure about your body, which you totally shouldn’t be. It’s the era of inclusivity and there’s nothing wrong with any body size or shape', 'Vi Rodriguez new', '', 'inherit', 'closed', 'closed', '', '287-revision-v1', '', '', '2024-11-05 07:38:35', '2024-11-05 07:38:35', '', 287, 'https://localhost/luna/site/?p=289', 0, 'revision', '', 0),
(290, 1, '2024-11-05 07:46:17', '2024-11-05 07:46:17', '<p>At Lune by Bhagya, we offer a range of hand-curated, quick and no-commitment styling packages designed to suit your personal style journey. Whether you need a quick style refresh or a comprehensive wardrobe overhaul, our packages provide expert guidance and personalized looks for every occasion. Explore our Silver, Gold, and Diamond options to find the perfect match for your fashion needs, and let us help you elevate your wardrobe with elegance and ease.</p>\n                     ', 'Styling Packages', '', 'inherit', 'closed', 'closed', '', '18-autosave-v1', '', '', '2024-11-05 07:46:17', '2024-11-05 07:46:17', '', 18, 'https://localhost/luna/site/?p=290', 0, 'revision', '', 0),
(291, 1, '2024-11-05 07:46:32', '2024-11-05 07:46:32', '<p>At Lune by Bhagya, we offer a range of hand-curated, no-commitment quick and easy styling packages designed to suit your personal style journey. Whether you need a quick style refresh or a comprehensive wardrobe overhaul, our packages provide expert guidance and personalized looks for every occasion. Explore our Silver, Gold, and Diamond options to find the perfect match for your fashion needs, and let us help you elevate your wardrobe with elegance and ease.</p>\r\n                     ', 'Styling Packages', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2024-11-05 07:46:32', '2024-11-05 07:46:32', '', 18, 'https://localhost/luna/site/?p=291', 0, 'revision', '', 0),
(292, 1, '2024-11-05 07:46:52', '2024-11-05 07:46:52', '<p>At Lune by Bhagya, we offer a range of hand-curated, no-commitment, quick and easy styling packages designed to suit your personal style journey. Whether you need a quick style refresh or a comprehensive wardrobe overhaul, our packages provide expert guidance and personalized looks for every occasion. Explore our Silver, Gold, and Diamond options to find the perfect match for your fashion needs, and let us help you elevate your wardrobe with elegance and ease.</p>\r\n                     ', 'Styling Packages', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2024-11-05 07:46:52', '2024-11-05 07:46:52', '', 18, 'https://localhost/luna/site/?p=292', 0, 'revision', '', 0),
(293, 1, '2024-11-06 08:58:45', '2024-11-06 08:58:45', '<p>I’d love to hear from you! Whether you have questions about my styling services, need personalized fashion advice, or are ready to begin your style journey, feel free to reach out</p>', 'Connect With Me', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2024-11-06 08:58:45', '2024-11-06 08:58:45', '', 25, 'https://localhost/luna/site/?p=293', 0, 'revision', '', 0),
(294, 1, '2024-11-06 09:06:21', '2024-11-06 09:06:21', '<h2>Curated Outfit Collages</h2>\r\n<p>Explore our collection of curated outfit collages, each designed to inspire and simplify your wardrobe choices. Whether you\'re looking for casual chic, office elegance, or special occasion glam, these collages provide versatile looks that blend fashion and functionality. Find the perfect ensemble for any moment, all thoughtfully styled to reflect your unique taste.\r\n', 'Portfolio', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2024-11-06 09:06:21', '2024-11-06 09:06:21', '', 20, 'https://localhost/luna/site/?p=294', 0, 'revision', '', 0),
(295, 1, '2024-11-14 13:37:30', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-11-14 13:37:30', '0000-00-00 00:00:00', '', 0, 'https://localhost/luna/site/?p=295', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(29, 2, 0),
(30, 2, 0),
(31, 2, 0),
(32, 2, 0),
(33, 2, 0),
(35, 2, 0),
(39, 3, 0),
(40, 3, 0),
(41, 3, 0),
(42, 3, 0),
(43, 3, 0),
(44, 3, 0),
(45, 3, 0),
(46, 3, 0),
(47, 4, 0),
(48, 4, 0),
(125, 2, 0),
(126, 1, 0),
(223, 2, 0),
(224, 2, 0),
(281, 4, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 9),
(3, 3, 'nav_menu', '', 0, 8),
(4, 4, 'nav_menu', '', 0, 3) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Header Menu', 'header-menu', 0),
(3, 'Footer Menu', 'footer-menu', 0),
(4, 'Top Menu', 'top-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin@luna'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:"bfa909dfc76f74f1d901c012468b8909f7e9b5f41796b482c0067e04c78be0f5";a:4:{s:10:"expiration";i:1732001046;s:2:"ip";s:12:"49.47.197.84";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";s:5:"login";i:1730791446;}s:64:"7b87a196137b8df90ffa2027bc9783bda8c18f1c77ce9f8e655b01860478351b";a:4:{s:10:"expiration";i:1731764248;s:2:"ip";s:11:"1.39.79.252";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36";s:5:"login";i:1731591448;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '295'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:6:{i:0;s:19:"add-post-type-blogs";i:1;s:22:"add-post-type-services";i:2;s:19:"add-post-type-press";i:3;s:24:"add-post-type-newsletter";i:4;s:12:"add-post_tag";i:5;s:22:"add-service_categories";}'),
(22, 1, 'wp_yoast_notifications', 'a:3:{i:0;a:2:{s:7:"message";s:339:"<p>We see that you enabled automatic updates for WordPress. We recommend that you do this for Yoast SEO as well. This way we can guarantee that WordPress and Yoast SEO will continue to run smoothly together. <a href="http://localhost/luna/site/wp-admin/plugins.php">Go to your plugins overview to enable auto-updates for Yoast SEO.</a></p>";s:7:"options";a:10:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-auto-update";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":10:{s:2:"ID";s:1:"1";s:10:"user_login";s:10:"admin@luna";s:9:"user_pass";s:34:"$P$BpTEoK7DlwSBsXCA2RCs3l5wbReHNr.";s:13:"user_nicename";s:9:"adminluna";s:10:"user_email";s:20:"deepsonart@gmail.com";s:8:"user_url";s:26:"http://localhost/luna/site";s:15:"user_registered";s:19:"2024-10-18 07:11:44";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:10:"admin@luna";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:15:"wp_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;}s:5:"nonce";N;s:8:"priority";d:0.8;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}i:1;a:2:{s:7:"message";s:480:"<p><strong>Huge SEO Issue: You&#039;re blocking access to robots.</strong> If you want search engines to show this site in their results, you must <a href="http://localhost/luna/site/wp-admin/options-reading.php">go to your Reading Settings</a> and uncheck the box for Search Engine Visibility. <button type="button" id="robotsmessage-dismiss-button" class="button-link hide-if-no-js" data-nonce="1e9b30c00e">I don&#039;t want this site to show in the search results.</button></p>";s:7:"options";a:10:{s:4:"type";s:5:"error";s:2:"id";s:32:"wpseo-search-engines-discouraged";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":10:{s:2:"ID";s:1:"1";s:10:"user_login";s:10:"admin@luna";s:9:"user_pass";s:34:"$P$BpTEoK7DlwSBsXCA2RCs3l5wbReHNr.";s:13:"user_nicename";s:9:"adminluna";s:10:"user_email";s:20:"deepsonart@gmail.com";s:8:"user_url";s:26:"http://localhost/luna/site";s:15:"user_registered";s:19:"2024-10-18 07:11:44";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:10:"admin@luna";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:15:"wp_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;}s:5:"nonce";N;s:8:"priority";i:1;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}i:2;a:2:{s:7:"message";O:61:"Yoast\\WP\\SEO\\Presenters\\Admin\\Indexing_Notification_Presenter":6:{s:18:"\0*\0total_unindexed";i:26;s:9:"\0*\0reason";s:26:"permalink_settings_changed";s:20:"\0*\0short_link_helper";O:38:"Yoast\\WP\\SEO\\Helpers\\Short_Link_Helper":2:{s:17:"\0*\0options_helper";O:35:"Yoast\\WP\\SEO\\Helpers\\Options_Helper":0:{}s:17:"\0*\0product_helper";O:35:"Yoast\\WP\\SEO\\Helpers\\Product_Helper":0:{}}s:15:"total_unindexed";i:26;s:6:"reason";s:26:"permalink_settings_changed";s:17:"short_link_helper";O:38:"Yoast\\WP\\SEO\\Helpers\\Short_Link_Helper":4:{s:17:"\0*\0options_helper";r:199;s:17:"\0*\0product_helper";r:200;s:14:"options_helper";O:35:"Yoast\\WP\\SEO\\Helpers\\Options_Helper":0:{}s:14:"product_helper";O:35:"Yoast\\WP\\SEO\\Helpers\\Product_Helper":0:{}}}s:7:"options";a:10:{s:4:"type";s:7:"warning";s:2:"id";s:13:"wpseo-reindex";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":10:{s:2:"ID";s:1:"1";s:10:"user_login";s:10:"admin@luna";s:9:"user_pass";s:34:"$P$BpTEoK7DlwSBsXCA2RCs3l5wbReHNr.";s:13:"user_nicename";s:9:"adminluna";s:10:"user_email";s:20:"deepsonart@gmail.com";s:8:"user_url";s:26:"http://localhost/luna/site";s:15:"user_registered";s:19:"2024-10-18 07:11:44";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:10:"admin@luna";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:15:"wp_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;}s:5:"nonce";N;s:8:"priority";d:0.8;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}}'),
(23, 1, 'nav_menu_recently_edited', '2'),
(24, 1, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:70:"commentstatusdiv,commentsdiv,slugdiv,authordiv,revisionsdiv,wpseo_meta";s:8:"advanced";s:0:"";}'),
(25, 1, 'screen_layout_page', '2'),
(26, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(27, 1, 'wp_user-settings-time', '1729706712'),
(28, 1, 'meta-box-order_outfit', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:22:"submitdiv,postimagediv";s:6:"normal";s:106:"acf-group_6719d45fb625b,wpseo_meta,revisionsdiv,postexcerpt,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(29, 1, 'screen_layout_outfit', '2'),
(30, 1, 'wfls-last-login', '1731591448'),
(31, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"1.39.79.0";}'),
(32, 1, 'meta-box-order_blogs', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:22:"submitdiv,postimagediv";s:6:"normal";s:106:"acf-group_671b3a0e7b562,wpseo_meta,revisionsdiv,postexcerpt,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(33, 1, 'screen_layout_blogs', '2') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin@luna', '$P$BpTEoK7DlwSBsXCA2RCs3l5wbReHNr.', 'adminluna', 'deepsonart@gmail.com', 'http://localhost/luna/site', '2024-10-18 07:11:44', '', 0, 'admin@luna') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfblockediplog`
#

DROP TABLE IF EXISTS `wp_wfblockediplog`;


#
# Table structure of table `wp_wfblockediplog`
#

CREATE TABLE `wp_wfblockediplog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `countryCode` varchar(2) NOT NULL,
  `blockCount` int(10) unsigned NOT NULL DEFAULT 0,
  `unixday` int(10) unsigned NOT NULL,
  `blockType` varchar(50) NOT NULL DEFAULT 'generic',
  PRIMARY KEY (`IP`,`unixday`,`blockType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfblockediplog`
#

#
# End of data contents of table `wp_wfblockediplog`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfblocks7`
#

DROP TABLE IF EXISTS `wp_wfblocks7`;


#
# Table structure of table `wp_wfblocks7`
#

CREATE TABLE `wp_wfblocks7` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT 0,
  `blockedHits` int(10) unsigned DEFAULT 0,
  `expiration` bigint(20) unsigned NOT NULL DEFAULT 0,
  `parameters` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `IP` (`IP`),
  KEY `expiration` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfblocks7`
#

#
# End of data contents of table `wp_wfblocks7`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfconfig`
#

DROP TABLE IF EXISTS `wp_wfconfig`;


#
# Table structure of table `wp_wfconfig`
#

CREATE TABLE `wp_wfconfig` (
  `name` varchar(100) NOT NULL,
  `val` longblob DEFAULT NULL,
  `autoload` enum('no','yes') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfconfig`
#
INSERT INTO `wp_wfconfig` ( `name`, `val`, `autoload`) VALUES
('activatingIP', '::1', 'yes'),
('actUpdateInterval', '2', 'yes'),
('addCacheComment', '0', 'yes'),
('advancedCommentScanning', '1', 'yes'),
('ajaxWatcherDisabled_admin', '0', 'yes'),
('ajaxWatcherDisabled_front', '0', 'yes'),
('alertEmails', '', 'yes'),
('alertOn_adminLogin', '1', 'yes'),
('alertOn_block', '1', 'yes'),
('alertOn_breachLogin', '1', 'yes'),
('alertOn_firstAdminLoginOnly', '0', 'yes'),
('alertOn_firstNonAdminLoginOnly', '0', 'yes'),
('alertOn_loginLockout', '1', 'yes'),
('alertOn_lostPasswdForm', '1', 'yes'),
('alertOn_nonAdminLogin', '0', 'yes'),
('alertOn_scanIssues', '1', 'yes'),
('alertOn_severityLevel', '25', 'yes'),
('alertOn_throttle', '0', 'yes'),
('alertOn_update', '0', 'yes'),
('alertOn_wafDeactivated', '1', 'yes'),
('alertOn_wordfenceDeactivated', '1', 'yes'),
('alert_maxHourly', '0', 'yes'),
('allowed404s', '/favicon.ico\n/apple-touch-icon*.png\n/*@2x.png\n/browserconfig.xml', 'yes'),
('allowed404s6116Migration', '1', 'yes'),
('allowHTTPSCaching', '0', 'yes'),
('allowLegacy2FA', '0', 'yes'),
('allowMySQLi', '1', 'yes'),
('allScansScheduled', 'a:0:{}', 'yes'),
('apiKey', '', 'yes'),
('autoBlockScanners', '1', 'yes'),
('autoUpdate', '0', 'yes'),
('autoUpdateAttempts', '0', 'yes'),
('bannedURLs', '', 'yes'),
('blockCustomText', '', 'yes'),
('blockedTime', '300', 'yes'),
('blocks702Migration', '1', 'yes'),
('cacheType', 'disabled', 'yes'),
('cbl_action', 'block', 'yes'),
('cbl_bypassRedirDest', '', 'yes'),
('cbl_bypassRedirURL', '', 'yes'),
('cbl_bypassViewURL', '', 'yes'),
('cbl_cookieVal', '67120b67292d2', 'yes'),
('cbl_loggedInBlocked', '', 'yes'),
('cbl_redirURL', '', 'yes'),
('cbl_restOfSiteBlocked', '1', 'yes'),
('checkSpamIP', '1', 'yes'),
('config701Migration', '1', 'yes'),
('config720Migration', '1', 'yes'),
('dbTest', 'a:1:{s:5:"nonce";s:64:"587a088d62bdd5b79c56bef986b11449bb6ca9a68140d675eb604ba3f724f9db";}', 'no'),
('dbVersion', '10.6.19-MariaDB-cll-lve', 'yes'),
('debugOn', '0', 'yes'),
('deleteTablesOnDeact', '0', 'yes'),
('detectProxyNonce', 'da61b0f132181a58f018ebcdd6d4b6c82dc4255d3151343a7a2044ae0cfa365a', 'no'),
('detectProxyRecommendation', '', 'no'),
('diagnosticsWflogsRemovalHistory', '[]', 'no'),
('disableCodeExecutionUploads', '0', 'yes'),
('disableConfigCaching', '0', 'yes'),
('disableWAFIPBlocking', '0', 'yes'),
('dismissAutoPrependNotice', '0', 'yes'),
('displayAutomaticBlocks', '1', 'yes'),
('displayTopLevelBlocking', '0', 'yes'),
('displayTopLevelLiveTraffic', '0', 'yes'),
('displayTopLevelOptions', '1', 'yes'),
('email_summary_dashboard_widget_enabled', '1', 'yes'),
('email_summary_enabled', '1', 'yes'),
('email_summary_excluded_directories', 'wp-content/cache,wp-content/wflogs', 'yes'),
('email_summary_interval', 'weekly', 'yes'),
('enableRemoteIpLookup', '1', 'yes'),
('encKey', '5ee1dcd10274871d', 'yes'),
('fileContentsGSB6315Migration', '1', 'yes'),
('firewallEnabled', '1', 'yes'),
('hasKeyConflict', '0', 'yes'),
('howGetIPs', '', 'yes'),
('howGetIPs_trusted_proxies', '', 'yes'),
('isPaid', '', 'yes'),
('keyType', 'free', 'yes'),
('lastAdminLogin', 'a:6:{s:6:"userID";i:1;s:8:"username";s:10:"admin@luna";s:9:"firstName";s:0:"";s:8:"lastName";s:0:"";s:4:"time";s:30:"Thu 14th November @ 01:37:28PM";s:2:"IP";s:11:"1.39.79.252";}', 'yes'),
('lastBlockAggregation', '1731578439', 'yes'),
('lastDailyCron', '1731578439', 'yes'),
('lastNotificationID', '17', 'no'),
('lastPermissionsTemplateCheck', '1731581756', 'yes'),
('liveActivityPauseEnabled', '1', 'yes'),
('liveTrafficEnabled', '0', 'yes'),
('liveTraf_displayExpandedRecords', '0', 'no'),
('liveTraf_ignoreIPs', '', 'yes'),
('liveTraf_ignorePublishers', '1', 'yes'),
('liveTraf_ignoreUA', '', 'yes'),
('liveTraf_ignoreUsers', '', 'yes'),
('liveTraf_maxAge', '30', 'yes'),
('liveTraf_maxRows', '2000', 'yes'),
('loginSecurityEnabled', '1', 'yes'),
('loginSec_blockAdminReg', '1', 'yes'),
('loginSec_breachPasswds', 'admins', 'yes'),
('loginSec_breachPasswds_enabled', '1', 'yes'),
('loginSec_countFailMins', '240', 'yes'),
('loginSec_disableApplicationPasswords', '1', 'yes'),
('loginSec_disableAuthorScan', '1', 'yes'),
('loginSec_disableOEmbedAuthor', '0', 'yes'),
('loginSec_enableSeparateTwoFactor', '', 'yes'),
('loginSec_lockInvalidUsers', '0', 'yes') ;
INSERT INTO `wp_wfconfig` ( `name`, `val`, `autoload`) VALUES
('loginSec_lockoutMins', '240', 'yes'),
('loginSec_maskLoginErrors', '1', 'yes'),
('loginSec_maxFailures', '20', 'yes'),
('loginSec_maxForgotPasswd', '20', 'yes'),
('loginSec_requireAdminTwoFactor', '0', 'yes'),
('loginSec_strongPasswds', 'pubs', 'yes'),
('loginSec_strongPasswds_enabled', '1', 'yes'),
('loginSec_userBlacklist', '', 'yes'),
('longEncKey', '8cadd47d529eea084689223977fd07228a6d1ff40c08e1b66ff33dae1f476275', 'yes'),
('lowResourceScansEnabled', '0', 'yes'),
('manualScanType', 'onceDaily', 'yes'),
('max404Crawlers', 'DISABLED', 'yes'),
('max404Crawlers_action', 'throttle', 'yes'),
('max404Humans', 'DISABLED', 'yes'),
('max404Humans_action', 'throttle', 'yes'),
('maxExecutionTime', '0', 'yes'),
('maxGlobalRequests', 'DISABLED', 'yes'),
('maxGlobalRequests_action', 'throttle', 'yes'),
('maxMem', '256', 'yes'),
('maxRequestsCrawlers', 'DISABLED', 'yes'),
('maxRequestsCrawlers_action', 'throttle', 'yes'),
('maxRequestsHumans', 'DISABLED', 'yes'),
('maxRequestsHumans_action', 'throttle', 'yes'),
('migration636_email_summary_excluded_directories', '1', 'no'),
('needsNewTour_blocking', '1', 'yes'),
('needsNewTour_dashboard', '1', 'yes'),
('needsNewTour_firewall', '1', 'yes'),
('needsNewTour_livetraffic', '1', 'yes'),
('needsNewTour_loginsecurity', '1', 'yes'),
('needsNewTour_scan', '1', 'yes'),
('needsUpgradeTour_blocking', '0', 'yes'),
('needsUpgradeTour_dashboard', '0', 'yes'),
('needsUpgradeTour_firewall', '0', 'yes'),
('needsUpgradeTour_livetraffic', '0', 'yes'),
('needsUpgradeTour_loginsecurity', '0', 'yes'),
('needsUpgradeTour_scan', '0', 'yes'),
('neverBlockBG', 'neverBlockVerified', 'yes'),
('notification_blogHighlights', '1', 'yes'),
('notification_productUpdates', '1', 'yes'),
('notification_promotions', '1', 'yes'),
('notification_scanStatus', '1', 'yes'),
('notification_securityAlerts', '1', 'yes'),
('notification_updatesNeeded', '1', 'yes'),
('onboardingAttempt1', 'skipped', 'yes'),
('onboardingAttempt2', '', 'no'),
('onboardingAttempt3', '', 'no'),
('onboardingAttempt3Initial', '0', 'yes'),
('onboardingDelayedAt', '0', 'yes'),
('other_blockBadPOST', '0', 'yes'),
('other_bypassLitespeedNoabort', '0', 'yes'),
('other_hideWPVersion', '0', 'yes'),
('other_pwStrengthOnUpdate', '1', 'yes'),
('other_scanComments', '1', 'yes'),
('other_scanOutside', '0', 'yes'),
('other_WFNet', '1', 'yes'),
('previousWflogsFileList', '["config-transient.php","config.php",".htaccess","ips.php","template.php","config-synced.php","config-livewaf.php","attack-data.php","rules.php","GeoLite2-Country.mmdb"]', 'yes'),
('scansEnabled_checkGSB', '1', 'yes'),
('scansEnabled_checkHowGetIPs', '1', 'yes'),
('scansEnabled_checkReadableConfig', '1', 'yes'),
('scansEnabled_comments', '1', 'yes'),
('scansEnabled_core', '1', 'yes'),
('scansEnabled_coreUnknown', '1', 'yes'),
('scansEnabled_diskSpace', '1', 'yes'),
('scansEnabled_fileContents', '1', 'yes'),
('scansEnabled_fileContentsGSB', '1', 'yes'),
('scansEnabled_geoipSupport', '1', 'yes'),
('scansEnabled_highSense', '0', 'yes'),
('scansEnabled_malware', '1', 'yes'),
('scansEnabled_oldVersions', '1', 'yes'),
('scansEnabled_options', '1', 'yes'),
('scansEnabled_passwds', '1', 'yes'),
('scansEnabled_plugins', '0', 'yes'),
('scansEnabled_posts', '1', 'yes'),
('scansEnabled_scanImages', '0', 'yes'),
('scansEnabled_suspectedFiles', '1', 'yes'),
('scansEnabled_suspiciousAdminUsers', '1', 'yes'),
('scansEnabled_suspiciousOptions', '1', 'yes'),
('scansEnabled_themes', '0', 'yes'),
('scansEnabled_wafStatus', '1', 'yes'),
('scansEnabled_wpscan_directoryListingEnabled', '1', 'yes'),
('scansEnabled_wpscan_fullPathDisclosure', '1', 'yes'),
('scanType', 'standard', 'yes'),
('scan_exclude', '', 'yes'),
('scan_force_ipv4_start', '0', 'yes'),
('scan_include_extra', '', 'yes'),
('scan_maxDuration', '', 'yes'),
('scan_maxIssues', '1000', 'yes'),
('scan_max_resume_attempts', '2', 'yes'),
('schedMode', 'auto', 'yes'),
('schedStartHour', '8', 'yes'),
('scheduledScansEnabled', '1', 'yes'),
('serverDNS', '1731578438;10800;208.109.227.196', 'yes'),
('showAdminBarMenu', '1', 'yes'),
('spamvertizeCheck', '1', 'yes'),
('ssl_verify', '1', 'yes'),
('startScansRemotely', '0', 'yes'),
('supportContent', '[]', 'no'),
('supportHash', '', 'no'),
('timeoffset_wf', '0', 'yes'),
('timeoffset_wf_updated', '1731591706', 'yes') ;
INSERT INTO `wp_wfconfig` ( `name`, `val`, `autoload`) VALUES
('totalAlertsSent', '7', 'yes'),
('totalLoginHits', '23', 'yes'),
('totalLogins', '7', 'yes'),
('touppBypassNextCheck', '0', 'yes'),
('touppPromptNeeded', '1', 'yes'),
('vulnerabilities_plugin', 'a:8:{i:0;a:4:{s:4:"slug";s:14:"classic-editor";s:11:"fromVersion";s:5:"1.6.3";s:10:"vulnerable";b:0;s:9:"toVersion";s:5:"1.6.5";}i:1;a:4:{s:4:"slug";s:14:"contact-form-7";s:11:"fromVersion";s:5:"5.7.7";s:10:"vulnerable";b:0;s:9:"toVersion";s:3:"6.0";}i:2;a:4:{s:4:"slug";s:15:"post-duplicator";s:11:"fromVersion";s:4:"2.31";s:10:"vulnerable";b:0;s:9:"toVersion";s:4:"2.36";}i:3;a:4:{s:4:"slug";s:9:"wordfence";s:11:"fromVersion";s:5:"7.9.3";s:10:"vulnerable";b:0;s:9:"toVersion";s:5:"8.0.0";}i:4;a:4:{s:4:"slug";s:13:"wp-migrate-db";s:11:"fromVersion";s:5:"2.6.7";s:10:"vulnerable";b:0;s:9:"toVersion";s:6:"2.6.11";}i:5;a:4:{s:4:"slug";s:13:"wordpress-seo";s:11:"fromVersion";s:6:"19.7.1";s:10:"vulnerable";b:0;s:9:"toVersion";s:4:"23.8";}i:6;a:4:{s:4:"slug";s:26:"advanced-custom-fields-pro";s:11:"fromVersion";s:5:"5.9.5";s:10:"vulnerable";b:0;s:9:"toVersion";s:6:"6.3.11";}i:7;a:3:{s:4:"slug";s:15:"wp-file-manager";s:11:"fromVersion";s:3:"8.0";s:10:"vulnerable";b:0;}}', 'yes'),
('vulnerabilities_theme', 'a:1:{i:0;a:4:{s:4:"slug";s:4:"luna";s:9:"toVersion";s:5:"1.1.8";s:11:"fromVersion";s:0:"";s:10:"vulnerable";b:0;}}', 'yes'),
('wafAlertInterval', '600', 'yes'),
('wafAlertOnAttacks', '1', 'yes'),
('wafAlertThreshold', '100', 'yes'),
('wafAlertWhitelist', '', 'yes'),
('waf_status', 'enabled', 'yes'),
('whitelisted', '', 'yes'),
('whitelistedServices', '[]', 'yes'),
('whitelistHash', '', 'no'),
('whitelistPresets', '[]', 'no'),
('wordfenceI18n', '1', 'yes'),
('wordpressPluginVersions', 'a:8:{s:26:"advanced-custom-fields-pro";s:5:"5.9.5";s:14:"classic-editor";s:5:"1.6.3";s:14:"contact-form-7";s:5:"5.7.7";s:15:"post-duplicator";s:4:"2.31";s:9:"wordfence";s:5:"7.9.3";s:15:"wp-file-manager";s:3:"8.0";s:13:"wp-migrate-db";s:5:"2.6.7";s:13:"wordpress-seo";s:6:"19.7.1";}', 'yes'),
('wordpressThemeVersions', 'a:2:{s:4:"luna";s:0:"";s:16:"twentytwentyfive";s:3:"1.0";}', 'yes'),
('wordpressVersion', '6.7', 'yes'),
('wp_home_url', 'https://localhost/luna/site', 'yes'),
('wp_site_url', 'https://localhost/luna/site', 'yes') ;

#
# End of data contents of table `wp_wfconfig`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfcrawlers`
#

DROP TABLE IF EXISTS `wp_wfcrawlers`;


#
# Table structure of table `wp_wfcrawlers`
#

CREATE TABLE `wp_wfcrawlers` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `patternSig` binary(16) NOT NULL,
  `status` char(8) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  `PTR` varchar(255) DEFAULT '',
  PRIMARY KEY (`IP`,`patternSig`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfcrawlers`
#

#
# End of data contents of table `wp_wfcrawlers`
# --------------------------------------------------------



#
# Delete any existing table `wp_wffilechanges`
#

DROP TABLE IF EXISTS `wp_wffilechanges`;


#
# Table structure of table `wp_wffilechanges`
#

CREATE TABLE `wp_wffilechanges` (
  `filenameHash` char(64) NOT NULL,
  `file` varchar(1000) NOT NULL,
  `md5` char(32) NOT NULL,
  PRIMARY KEY (`filenameHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wffilechanges`
#

#
# End of data contents of table `wp_wffilechanges`
# --------------------------------------------------------



#
# Delete any existing table `wp_wffilemods`
#

DROP TABLE IF EXISTS `wp_wffilemods`;


#
# Table structure of table `wp_wffilemods`
#

CREATE TABLE `wp_wffilemods` (
  `filenameMD5` binary(16) NOT NULL,
  `filename` varchar(1000) NOT NULL,
  `real_path` text NOT NULL,
  `knownFile` tinyint(3) unsigned NOT NULL,
  `oldMD5` binary(16) NOT NULL,
  `newMD5` binary(16) NOT NULL,
  `SHAC` binary(32) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `stoppedOnSignature` varchar(255) NOT NULL DEFAULT '',
  `stoppedOnPosition` int(10) unsigned NOT NULL DEFAULT 0,
  `isSafeFile` varchar(1) NOT NULL DEFAULT '?',
  PRIMARY KEY (`filenameMD5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wffilemods`
#

#
# End of data contents of table `wp_wffilemods`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfhits`
#

DROP TABLE IF EXISTS `wp_wfhits`;


#
# Table structure of table `wp_wfhits`
#

CREATE TABLE `wp_wfhits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attackLogTime` double(17,6) unsigned NOT NULL,
  `ctime` double(17,6) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `jsRun` tinyint(4) DEFAULT 0,
  `statusCode` int(11) NOT NULL DEFAULT 200,
  `isGoogle` tinyint(4) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `newVisit` tinyint(3) unsigned NOT NULL,
  `URL` text DEFAULT NULL,
  `referer` text DEFAULT NULL,
  `UA` text DEFAULT NULL,
  `action` varchar(64) NOT NULL DEFAULT '',
  `actionDescription` text DEFAULT NULL,
  `actionData` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`IP`,`ctime`),
  KEY `attackLogTime` (`attackLogTime`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfhits`
#
INSERT INTO `wp_wfhits` ( `id`, `attackLogTime`, `ctime`, `IP`, `jsRun`, `statusCode`, `isGoogle`, `userID`, `newVisit`, `URL`, `referer`, `UA`, `action`, `actionDescription`, `actionData`) VALUES
(1, '0.000000', '1729755278.628907', UNHEX('00000000000000000000FFFF3125E333'), 0, 302, 0, 1, 0, 'https://localhost/luna/site/wp-login.php', 'https://localhost/luna/site/wp-login.php?redirect_to=https%3A%2F%2Fmwduat.com%2Flbb%2Fsite%2Fwp-admin%2F&reauth=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 'loginOK', NULL, NULL),
(2, '0.000000', '1729772478.054634', UNHEX('00000000000000000000FFFF3125E333'), 0, 302, 0, 1, 0, 'https://localhost/luna/site/wp-login.php', 'https://localhost/luna/site/wp-login.php?redirect_to=https%3A%2F%2Fmwduat.com%2Flbb%2Fsite%2Fwp-admin%2F&reauth=1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 'loginOK', NULL, NULL),
(3, '0.000000', '1729774331.444572', UNHEX('00000000000000000000FFFF01274E9B'), 0, 302, 0, 1, 0, 'https://localhost/luna/site/wp-login.php', 'https://localhost/luna/site/wp-login.php?redirect_to=https%3A%2F%2Fmwduat.com%2Flbb%2Fsite%2Fwp-admin%2F&reauth=1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 'loginOK', NULL, NULL),
(4, '0.000000', '1729830848.932564', UNHEX('00000000000000000000FFFF983BDEA3'), 0, 302, 0, 1, 0, 'https://localhost/luna/site/wp-login.php', 'https://localhost/luna/site/wp-login.php?redirect_to=https%3A%2F%2Fmwduat.com%2Flbb%2Fsite%2Fwp-admin%2F&reauth=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15', 'loginOK', NULL, NULL),
(5, '0.000000', '1730703342.792472', UNHEX('00000000000000000000FFFF75F1BDB3'), 0, 200, 0, 1, 0, 'https://localhost/luna/site/wp-login.php', 'https://localhost/luna/site/wp-login.php?redirect_to=https%3A%2F%2Fmwduat.com%2Flbb%2Fsite%2Fwp-admin%2F&reauth=1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 'loginFailValidUsername', NULL, NULL),
(6, '0.000000', '1730703355.824720', UNHEX('00000000000000000000FFFF75F1BDB3'), 0, 200, 0, 1, 0, 'https://localhost/luna/site/wp-login.php', 'https://localhost/luna/site/wp-login.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 'loginFailValidUsername', NULL, NULL),
(7, '0.000000', '1730703370.687592', UNHEX('00000000000000000000FFFF75F1BDB3'), 0, 200, 0, 1, 0, 'https://localhost/luna/site/wp-login.php', 'https://localhost/luna/site/wp-login.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 'loginFailValidUsername', NULL, NULL),
(8, '0.000000', '1730703417.052570', UNHEX('00000000000000000000FFFF75F1BDB3'), 0, 302, 0, 1, 0, 'https://localhost/luna/site/wp-login.php', 'https://localhost/luna/site/wp-login.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 'loginOK', NULL, NULL),
(9, '0.000000', '1730791446.201697', UNHEX('00000000000000000000FFFF312FC554'), 0, 302, 0, 1, 0, 'https://localhost/luna/site/wp-login.php', 'https://localhost/luna/site/wp-login.php?redirect_to=https%3A%2F%2Fmwduat.com%2Flbb%2Fsite%2Fwp-admin%2F&reauth=1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', 'loginOK', NULL, NULL),
(10, '0.000000', '1731591448.196072', UNHEX('00000000000000000000FFFF01274FFC'), 0, 302, 0, 1, 0, 'https://localhost/luna/site/wp-login.php', 'https://localhost/luna/site/wp-login.php?redirect_to=https%3A%2F%2Fmwduat.com%2Flbb%2Fsite%2Fwp-admin%2F&reauth=1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 'loginOK', NULL, NULL) ;

#
# End of data contents of table `wp_wfhits`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfhoover`
#

DROP TABLE IF EXISTS `wp_wfhoover`;


#
# Table structure of table `wp_wfhoover`
#

CREATE TABLE `wp_wfhoover` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` text DEFAULT NULL,
  `host` text DEFAULT NULL,
  `path` text DEFAULT NULL,
  `hostKey` varbinary(124) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k2` (`hostKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfhoover`
#

#
# End of data contents of table `wp_wfhoover`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfissues`
#

DROP TABLE IF EXISTS `wp_wfissues`;


#
# Table structure of table `wp_wfissues`
#

CREATE TABLE `wp_wfissues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL,
  `lastUpdated` int(10) unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lastUpdated` (`lastUpdated`),
  KEY `status` (`status`),
  KEY `ignoreP` (`ignoreP`),
  KEY `ignoreC` (`ignoreC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfissues`
#

#
# End of data contents of table `wp_wfissues`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfknownfilelist`
#

DROP TABLE IF EXISTS `wp_wfknownfilelist`;


#
# Table structure of table `wp_wfknownfilelist`
#

CREATE TABLE `wp_wfknownfilelist` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `path` text NOT NULL,
  `wordpress_path` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfknownfilelist`
#

#
# End of data contents of table `wp_wfknownfilelist`
# --------------------------------------------------------



#
# Delete any existing table `wp_wflivetraffichuman`
#

DROP TABLE IF EXISTS `wp_wflivetraffichuman`;


#
# Table structure of table `wp_wflivetraffichuman`
#

CREATE TABLE `wp_wflivetraffichuman` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `identifier` binary(32) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `expiration` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`,`identifier`),
  KEY `expiration` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wflivetraffichuman`
#

#
# End of data contents of table `wp_wflivetraffichuman`
# --------------------------------------------------------



#
# Delete any existing table `wp_wflocs`
#

DROP TABLE IF EXISTS `wp_wflocs`;


#
# Table structure of table `wp_wflocs`
#

CREATE TABLE `wp_wflocs` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `failed` tinyint(3) unsigned NOT NULL,
  `city` varchar(255) DEFAULT '',
  `region` varchar(255) DEFAULT '',
  `countryName` varchar(255) DEFAULT '',
  `countryCode` char(2) DEFAULT '',
  `lat` float(10,7) DEFAULT 0.0000000,
  `lon` float(10,7) DEFAULT 0.0000000,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wflocs`
#

#
# End of data contents of table `wp_wflocs`
# --------------------------------------------------------



#
# Delete any existing table `wp_wflogins`
#

DROP TABLE IF EXISTS `wp_wflogins`;


#
# Table structure of table `wp_wflogins`
#

CREATE TABLE `wp_wflogins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hitID` int(11) DEFAULT NULL,
  `ctime` double(17,6) unsigned NOT NULL,
  `fail` tinyint(3) unsigned NOT NULL,
  `action` varchar(40) NOT NULL,
  `username` varchar(255) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `UA` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k1` (`IP`,`fail`),
  KEY `hitID` (`hitID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wflogins`
#
INSERT INTO `wp_wflogins` ( `id`, `hitID`, `ctime`, `fail`, `action`, `username`, `userID`, `IP`, `UA`) VALUES
(1, 1, '1729755279.036959', 0, 'loginOK', 'admin@luna', 1, UNHEX('00000000000000000000FFFF3125E333'), 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'),
(2, 2, '1729772478.549290', 0, 'loginOK', 'admin@luna', 1, UNHEX('00000000000000000000FFFF3125E333'), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'),
(3, 3, '1729774331.537466', 0, 'loginOK', 'admin@luna', 1, UNHEX('00000000000000000000FFFF01274E9B'), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'),
(4, 4, '1729830849.344676', 0, 'loginOK', 'admin@luna', 1, UNHEX('00000000000000000000FFFF983BDEA3'), 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15'),
(5, 5, '1730703343.234326', 1, 'loginFailValidUsername', 'admin@luna', 1, UNHEX('00000000000000000000FFFF75F1BDB3'), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'),
(6, 6, '1730703355.967178', 1, 'loginFailValidUsername', 'admin@luna', 1, UNHEX('00000000000000000000FFFF75F1BDB3'), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'),
(7, 7, '1730703370.789358', 1, 'loginFailValidUsername', 'admin@luna', 1, UNHEX('00000000000000000000FFFF75F1BDB3'), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'),
(8, 8, '1730703417.463805', 0, 'loginOK', 'admin@luna', 1, UNHEX('00000000000000000000FFFF75F1BDB3'), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'),
(9, 9, '1730791446.641149', 0, 'loginOK', 'admin@luna', 1, UNHEX('00000000000000000000FFFF312FC554'), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'),
(10, 10, '1731591448.766054', 0, 'loginOK', 'admin@luna', 1, UNHEX('00000000000000000000FFFF01274FFC'), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36') ;

#
# End of data contents of table `wp_wflogins`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfls_2fa_secrets`
#

DROP TABLE IF EXISTS `wp_wfls_2fa_secrets`;


#
# Table structure of table `wp_wfls_2fa_secrets`
#

CREATE TABLE `wp_wfls_2fa_secrets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `secret` tinyblob NOT NULL,
  `recovery` blob NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `vtime` int(10) unsigned NOT NULL,
  `mode` enum('authenticator') NOT NULL DEFAULT 'authenticator',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfls_2fa_secrets`
#

#
# End of data contents of table `wp_wfls_2fa_secrets`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfls_role_counts`
#

DROP TABLE IF EXISTS `wp_wfls_role_counts`;


#
# Table structure of table `wp_wfls_role_counts`
#

CREATE TABLE `wp_wfls_role_counts` (
  `serialized_roles` varbinary(255) NOT NULL,
  `two_factor_inactive` tinyint(1) NOT NULL,
  `user_count` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`serialized_roles`,`two_factor_inactive`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


#
# Data contents of table `wp_wfls_role_counts`
#

#
# End of data contents of table `wp_wfls_role_counts`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfls_settings`
#

DROP TABLE IF EXISTS `wp_wfls_settings`;


#
# Table structure of table `wp_wfls_settings`
#

CREATE TABLE `wp_wfls_settings` (
  `name` varchar(191) NOT NULL DEFAULT '',
  `value` longblob DEFAULT NULL,
  `autoload` enum('no','yes') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfls_settings`
#
INSERT INTO `wp_wfls_settings` ( `name`, `value`, `autoload`) VALUES
('2fa-user-grace-period', '10', 'yes'),
('allow-disabling-ntp', '1', 'yes'),
('allow-xml-rpc', '1', 'yes'),
('captcha-stats', '{"counts":[0,0,0,0,0,0,0,0,0,0,0],"avg":0}', 'yes'),
('delete-deactivation', '', 'yes'),
('disable-temporary-tables', '0', 'yes'),
('enable-auth-captcha', '', 'yes'),
('enable-login-history-columns', '1', 'yes'),
('enable-shortcode', '', 'yes'),
('enable-woocommerce-account-integration', '', 'yes'),
('enable-woocommerce-integration', '', 'yes'),
('global-notices', '[]', 'yes'),
('ip-source', '', 'yes'),
('ip-trusted-proxies', '', 'yes'),
('last-secret-refresh', '1729235678', 'yes'),
('ntp-failure-count', '3', 'yes'),
('ntp-offset', '0', 'yes'),
('recaptcha-threshold', '0.5', 'yes'),
('remember-device', '', 'yes'),
('remember-device-duration', '2592000', 'yes'),
('require-2fa-grace-period-enabled', '', 'yes'),
('require-2fa.administrator', '', 'yes'),
('schema-version', '2', 'yes'),
('shared-hash-secret', '1500379fd0e3d55719a0511f3e2ac0d07fe3892a97e344428706564bb8839b12', 'yes'),
('shared-symmetric-secret', '1d63c8294c83c560d0e914d2df227dd2742f962ad6605e6fa47fb152ed1bcc67', 'yes'),
('stack-ui-columns', '1', 'yes'),
('use-ntp', '', 'yes'),
('user-count-query-state', '0', 'yes'),
('whitelisted', '', 'yes'),
('xmlrpc-enabled', '1', 'yes') ;

#
# End of data contents of table `wp_wfls_settings`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfnotifications`
#

DROP TABLE IF EXISTS `wp_wfnotifications`;


#
# Table structure of table `wp_wfnotifications`
#

CREATE TABLE `wp_wfnotifications` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `new` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `category` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT 1000,
  `ctime` int(10) unsigned NOT NULL,
  `html` text NOT NULL,
  `links` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfnotifications`
#
INSERT INTO `wp_wfnotifications` ( `id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES
('site-AEAAAAA', 1, 'wfplugin_updates', 502, 1731591708, '<a href="https://localhost/luna/site/wp-admin/update-core.php">Updates are available for 7 plugins and 1 theme</a>', '[]') ;

#
# End of data contents of table `wp_wfnotifications`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfpendingissues`
#

DROP TABLE IF EXISTS `wp_wfpendingissues`;


#
# Table structure of table `wp_wfpendingissues`
#

CREATE TABLE `wp_wfpendingissues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL,
  `lastUpdated` int(10) unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lastUpdated` (`lastUpdated`),
  KEY `status` (`status`),
  KEY `ignoreP` (`ignoreP`),
  KEY `ignoreC` (`ignoreC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfpendingissues`
#

#
# End of data contents of table `wp_wfpendingissues`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfreversecache`
#

DROP TABLE IF EXISTS `wp_wfreversecache`;


#
# Table structure of table `wp_wfreversecache`
#

CREATE TABLE `wp_wfreversecache` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `host` varchar(255) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfreversecache`
#

#
# End of data contents of table `wp_wfreversecache`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfsnipcache`
#

DROP TABLE IF EXISTS `wp_wfsnipcache`;


#
# Table structure of table `wp_wfsnipcache`
#

CREATE TABLE `wp_wfsnipcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IP` varchar(45) NOT NULL DEFAULT '',
  `expiration` timestamp NOT NULL DEFAULT current_timestamp(),
  `body` varchar(255) NOT NULL DEFAULT '',
  `count` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `expiration` (`expiration`),
  KEY `IP` (`IP`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfsnipcache`
#

#
# End of data contents of table `wp_wfsnipcache`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfstatus`
#

DROP TABLE IF EXISTS `wp_wfstatus`;


#
# Table structure of table `wp_wfstatus`
#

CREATE TABLE `wp_wfstatus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `type` char(5) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfstatus`
#

#
# End of data contents of table `wp_wfstatus`
# --------------------------------------------------------



#
# Delete any existing table `wp_wftrafficrates`
#

DROP TABLE IF EXISTS `wp_wftrafficrates`;


#
# Table structure of table `wp_wftrafficrates`
#

CREATE TABLE `wp_wftrafficrates` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hitType` enum('hit','404') NOT NULL DEFAULT 'hit',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`,`hitType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wftrafficrates`
#

#
# End of data contents of table `wp_wftrafficrates`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfwaffailures`
#

DROP TABLE IF EXISTS `wp_wfwaffailures`;


#
# Table structure of table `wp_wfwaffailures`
#

CREATE TABLE `wp_wfwaffailures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `throwable` text NOT NULL,
  `rule_id` int(10) unsigned DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_wfwaffailures`
#

#
# End of data contents of table `wp_wfwaffailures`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpfm_backup`
#

DROP TABLE IF EXISTS `wp_wpfm_backup`;


#
# Table structure of table `wp_wpfm_backup`
#

CREATE TABLE `wp_wpfm_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_name` text DEFAULT NULL,
  `backup_date` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wpfm_backup`
#

#
# End of data contents of table `wp_wpfm_backup`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable`
#

DROP TABLE IF EXISTS `wp_yoast_indexable`;


#
# Table structure of table `wp_yoast_indexable`
#

CREATE TABLE `wp_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext DEFAULT NULL,
  `permalink_hash` varchar(40) DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) NOT NULL,
  `object_sub_type` varchar(32) DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `breadcrumb_title` text DEFAULT NULL,
  `post_status` varchar(20) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT 0,
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext DEFAULT NULL,
  `primary_focus_keyword` varchar(191) DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT 0,
  `is_robots_noindex` tinyint(1) DEFAULT 0,
  `is_robots_nofollow` tinyint(1) DEFAULT 0,
  `is_robots_noarchive` tinyint(1) DEFAULT 0,
  `is_robots_noimageindex` tinyint(1) DEFAULT 0,
  `is_robots_nosnippet` tinyint(1) DEFAULT 0,
  `twitter_title` text DEFAULT NULL,
  `twitter_image` longtext DEFAULT NULL,
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image_id` varchar(191) DEFAULT NULL,
  `twitter_image_source` text DEFAULT NULL,
  `open_graph_title` text DEFAULT NULL,
  `open_graph_description` longtext DEFAULT NULL,
  `open_graph_image` longtext DEFAULT NULL,
  `open_graph_image_id` varchar(191) DEFAULT NULL,
  `open_graph_image_source` text DEFAULT NULL,
  `open_graph_image_meta` mediumtext DEFAULT NULL,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  `schema_page_type` varchar(64) DEFAULT NULL,
  `schema_article_type` varchar(64) DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT 0,
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `object_last_modified` datetime DEFAULT NULL,
  `object_published_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`),
  KEY `published_sitemap_index` (`object_published_at`,`is_robots_noindex`,`object_type`,`object_sub_type`)
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_indexable`
#
INSERT INTO `wp_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(1, 'https://localhost/luna/site/author/adminluna/', '45:1eadc2fc3b71db1817423d2fcf29388f', 1, 'user', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 'https://secure.gravatar.com/avatar/a75754f8efe37b6f24c7b24472a0f469?s=500&d=mm&r=g', NULL, NULL, 'gravatar-image', NULL, NULL, 'https://secure.gravatar.com/avatar/a75754f8efe37b6f24c7b24472a0f469?s=500&d=mm&r=g', NULL, 'gravatar-image', NULL, NULL, NULL, NULL, '2024-10-18 07:16:51', '2024-11-06 09:06:21', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 09:06:21', '2024-10-18 07:11:46'),
(2, 'https://localhost/luna/site/?page_id=3', '38:1805dd496738aeb390c1c447459d5d56', 3, 'post', 'page', 1, 0, NULL, NULL, 'Privacy Policy', 'draft', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:16:52', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-18 07:11:46', '2024-10-18 07:11:46'),
(3, 'https://localhost/luna/site/sample-page/', '40:23f08e9ce3026a2e201e8ac7b5ff9cc9', 2, 'post', 'page', 1, 0, NULL, NULL, 'Sample Page', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-10-18 07:16:52', '2024-10-24 07:35:05', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-18 07:11:46', '2024-10-18 07:11:46'),
(4, 'https://localhost/luna/site/hello-world/', '40:e95dbe35cb986153bf73069cb253a253', 1, 'post', 'post', 1, 0, NULL, NULL, 'Hello world!', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-18 07:16:52', '2024-10-25 04:00:05', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-18 07:11:46', '2024-10-18 07:11:46'),
(5, 'https://localhost/luna/site/category/uncategorized/', '51:6ebc92b044cba45df47f66e9bdee9ce8', 1, 'term', 'category', NULL, NULL, NULL, NULL, 'Uncategorized', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-18 07:16:53', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-18 07:11:46', '2024-10-18 07:11:46'),
(6, NULL, NULL, NULL, 'system-page', '404', NULL, NULL, 'Page not found %%sep%% %%sitename%%', NULL, 'Error 404: Page not found', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:16:53', '2024-10-24 08:11:11', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(7, NULL, NULL, NULL, 'system-page', 'search-result', NULL, NULL, 'You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:16:53', '2024-10-24 12:52:12', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(8, NULL, NULL, NULL, 'date-archive', NULL, NULL, NULL, '%%date%% %%page%% %%sep%% %%sitename%%', '', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:16:53', '2024-10-24 12:52:12', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(9, 'https://localhost/luna/site/', '28:747285e77a0ed0a20f1b9df4d54504a7', NULL, 'home-page', NULL, NULL, NULL, '%%sitename%% %%page%% %%sep%% %%sitedesc%%', 'We see personal style as more than mere clothing—it&#039;s a language of its own, a silent yet powerful expression of who you are and how you move through the world.', 'Home', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '%%sitename%%', '', '', '0', NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:16:54', '2024-11-06 09:06:21', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 09:06:21', '2024-10-18 07:11:46'),
(10, 'https://localhost/luna/site/blogs/', '34:12c23e4ba8666dfae5da6d2387dd3c37', NULL, 'post-type-archive', 'blogs', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Blogs', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:16:54', '2024-10-25 06:28:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 06:28:40', '2024-10-24 05:59:43'),
(11, NULL, NULL, NULL, 'post-type-archive', 'services', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Services', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:16:54', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(12, NULL, NULL, NULL, 'post-type-archive', 'press', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Press', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:16:54', '2024-10-18 12:51:31', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(13, NULL, NULL, NULL, 'post-type-archive', 'newsletter', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Newsletter', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:16:55', '2024-10-18 12:51:31', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(14, 'https://localhost/luna/site/', '28:747285e77a0ed0a20f1b9df4d54504a7', 6, 'post', 'page', 1, 0, NULL, NULL, 'Home', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-18 07:21:36', '2024-11-03 05:48:36', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2024-11-03 05:48:35', '2024-10-18 07:17:50'),
(15, 'https://localhost/luna/site/about-lune-by-bhagya/', '49:b0b0662da343989e96993880c19f174b', 8, 'post', 'page', 1, 0, NULL, NULL, 'About Lune by Bhagya', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/about-page-e1729835608376.jpg', NULL, '113', 'featured-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/about-page-e1729835608376.jpg', '113', 'featured-image', '{"width":443,"height":637,"filesize":310319,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/about-page-e1729835608376.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/about-page-e1729835608376.jpg","size":"full","id":113,"alt":"","pixels":282191,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-10-18 07:21:36', '2024-10-25 05:53:34', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-10-25 05:53:34', '2024-10-18 07:18:44'),
(16, NULL, NULL, NULL, 'post-type-archive', 'blogs', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Blogs', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:21:38', '2024-10-22 14:42:09', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(17, NULL, NULL, NULL, 'post-type-archive', 'services', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Services', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:21:38', '2024-10-22 14:42:09', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(18, NULL, NULL, NULL, 'post-type-archive', 'press', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Press', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:21:38', '2024-10-22 14:42:09', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(19, NULL, NULL, NULL, 'post-type-archive', 'newsletter', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Newsletter', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-18 07:21:38', '2024-10-22 14:42:09', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(20, 'https://localhost/luna/site/services/', '37:45613710c6271059244e5bcd1c6ff47a', 10, 'post', 'page', 1, 0, NULL, NULL, 'Services', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-18 07:23:50', '2024-11-04 09:07:49', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2024-11-04 09:07:49', '2024-10-18 07:23:53'),
(21, NULL, NULL, NULL, 'post-type-archive', 'blogs', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Blogs', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-22 09:22:08', '2024-10-23 23:51:06', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(22, NULL, NULL, NULL, 'post-type-archive', 'services', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Services', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-22 09:22:09', '2024-10-23 23:51:06', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(23, NULL, NULL, NULL, 'post-type-archive', 'press', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Press', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-22 09:22:09', '2024-10-23 23:51:06', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(24, NULL, NULL, NULL, 'post-type-archive', 'newsletter', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Newsletter', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-22 09:22:09', '2024-10-23 23:51:06', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(25, NULL, NULL, 15, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Home', 'draft', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 04:45:27', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, NULL, NULL, 16, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'draft', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 04:45:29', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, NULL, NULL, 17, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'draft', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 04:45:30', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, 'https://localhost/luna/site/styling-packages/', '45:06a868975c25d63df9aa6504493deec6', 18, 'post', 'page', 1, 0, NULL, NULL, 'Styling Packages', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 04:48:04', '2024-11-05 07:46:52', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-11-05 07:46:52', '2024-10-23 04:48:03'),
(29, 'https://localhost/luna/site/portfolio/', '38:77ef81569e1c134ddeb9bc0033a4a84a', 20, 'post', 'page', 1, 0, NULL, NULL, 'Portfolio', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 04:49:06', '2024-11-06 09:06:21', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-11-06 09:06:21', '2024-10-23 04:49:06'),
(30, 'https://localhost/luna/site/faqs/', '33:50ce408b9dfd785ea8db51f1a239ec99', 22, 'post', 'page', 1, 0, NULL, NULL, 'FAQs', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 04:50:19', '2024-10-25 06:48:10', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-10-25 06:48:09', '2024-10-23 04:50:18'),
(31, 'https://localhost/luna/site/connect-with-me/', '44:9d24c7cc7df6ded7bd7048d43017d7bc', 25, 'post', 'page', 1, 0, NULL, NULL, 'Connect With Me', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/contact-image.jpg', NULL, '216', 'featured-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/contact-image.jpg', '216', 'featured-image', '{"width":438,"height":587,"filesize":317724,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/contact-image.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/contact-image.jpg","size":"full","id":216,"alt":"","pixels":257106,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-10-23 05:05:59', '2024-11-06 08:59:45', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-11-06 08:59:45', '2024-10-23 05:06:22'),
(32, NULL, NULL, 28, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Home', 'draft', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 05:09:55', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, 'https://localhost/luna/site/29/', '31:271a076edbc114be753b034711cfae87', 29, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:09:57', '2024-11-06 08:58:14', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:58:14', '2024-10-23 05:11:17'),
(34, 'https://localhost/luna/site/30/', '31:6ab3832662b771953cad8af7d0d110df', 30, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Connect With Me', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:09:58', '2024-11-06 08:58:14', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:58:14', '2024-10-23 05:11:22'),
(35, 'https://localhost/luna/site/31/', '31:e41b7f3174d2ddf21911badffc7ec43d', 31, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:09:59', '2024-11-06 08:58:14', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:58:14', '2024-10-23 05:11:22'),
(36, 'https://localhost/luna/site/32/', '31:615e89b2df5f9b4931c7569302219e9d', 32, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:10:00', '2024-11-06 08:58:14', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:58:14', '2024-10-23 05:11:16'),
(37, 'https://localhost/luna/site/33/', '31:342a28e4609b1f029f353cc407f0be49', 33, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Outfit Portfolio', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:10:00', '2024-11-06 08:58:14', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:58:14', '2024-10-23 05:11:21'),
(39, 'https://localhost/luna/site/35/', '31:48357763a7ee5d58eb07e19038ddc29b', 35, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:10:02', '2024-11-06 08:58:14', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:58:14', '2024-10-23 05:11:20'),
(40, 'https://localhost/luna/site/blog/', '33:d61953e59a26208c3f9105eff2dcab72', 36, 'post', 'page', 1, 0, NULL, NULL, 'Blog', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:18:14', '2024-10-24 14:05:42', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2024-10-24 14:05:42', '2024-10-23 05:18:20'),
(41, NULL, NULL, 38, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Home', 'draft', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 05:19:33', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(42, 'https://localhost/luna/site/39/', '31:c2452bba40f7432af09a172690b7004b', 39, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:19:34', '2024-11-06 08:57:57', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:57', '2024-10-23 05:22:24'),
(43, 'https://localhost/luna/site/40/', '31:ad0c5e44e355b499bf0fb94c9a27382b', 40, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Blogs', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:19:35', '2024-11-06 08:57:57', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:57', '2024-10-23 05:22:29'),
(44, 'https://localhost/luna/site/41/', '31:950cc2015e6ee32e608d625887762877', 41, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Connect With Me', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:19:37', '2024-11-06 08:57:57', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:57', '2024-10-23 05:22:30'),
(45, 'https://localhost/luna/site/42/', '31:9a6963b0150b5899be6b85fd039cac60', 42, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:19:38', '2024-11-06 08:57:57', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:57', '2024-10-23 05:22:28'),
(46, 'https://localhost/luna/site/43/', '31:9428ffcde7f313ecdc4656fd17c1644e', 43, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Outfit Portfolio', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:19:38', '2024-11-06 08:57:57', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:57', '2024-10-23 05:22:27'),
(47, 'https://localhost/luna/site/44/', '31:deecf209f9135b8f9ee75363d0ada862', 44, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Styling Services', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:19:39', '2024-11-06 08:57:57', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:57', '2024-10-23 05:22:24'),
(48, 'https://localhost/luna/site/45/', '31:58ceaa80e1338d83372250208f48948e', 45, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:19:40', '2024-11-06 08:57:57', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:57', '2024-10-23 05:22:26'),
(49, 'https://localhost/luna/site/46/', '31:471e564b5541af64b20338a9eecfe099', 46, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:19:58', '2024-11-06 08:57:57', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:57', '2024-10-23 05:22:22'),
(50, 'https://localhost/luna/site/our-styling-packages/', '49:bf2655dbf47d9a09d2f3dee9a0ea10b4', 47, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Styling Packages', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:24:38', '2024-11-06 08:57:34', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:34', '2024-10-23 05:27:58'),
(51, 'https://localhost/luna/site/styling-services/', '45:00190b58d1135753bcb635ecb4ff4c0e', 48, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Styling Services', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:27:50', '2024-11-06 08:57:34', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:34', '2024-10-23 05:27:59'),
(52, 'https://localhost/luna/site/?post_type=acf-field-group&p=49', '59:51aaa13eec593da0c4637e0c4154b3f9', 49, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Home Page Settings', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:55:36', '2024-10-24 14:02:24', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-23 17:40:53', '2024-10-23 05:55:36'),
(53, NULL, NULL, 50, 'post', 'acf-field', 1, 49, NULL, NULL, 'Banner Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:55:37', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 05:55:36', '2024-10-23 05:55:36'),
(54, NULL, NULL, 51, 'post', 'acf-field', 1, 49, NULL, NULL, 'Banner Logo', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:55:37', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 05:55:37', '2024-10-23 05:55:37'),
(55, NULL, NULL, 52, 'post', 'acf-field', 1, 49, NULL, NULL, 'Banner Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:55:38', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 05:55:38', '2024-10-23 05:55:38'),
(56, NULL, NULL, 53, 'post', 'acf-field', 1, 49, NULL, NULL, 'Banner Image', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:55:38', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 05:55:38', '2024-10-23 05:55:38'),
(57, NULL, NULL, 54, 'post', 'acf-field', 1, 49, NULL, NULL, 'Content', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:55:39', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 05:55:39', '2024-10-23 05:55:39'),
(58, NULL, NULL, 55, 'post', 'acf-field', 1, 49, NULL, NULL, 'Service Content', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:55:39', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 05:55:39', '2024-10-23 05:55:39'),
(59, NULL, NULL, 56, 'post', 'acf-field', 1, 49, NULL, NULL, 'Link text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:55:40', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 05:55:40', '2024-10-23 05:55:40'),
(60, NULL, NULL, 57, 'post', 'acf-field', 1, 49, NULL, NULL, 'Link Url', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 05:55:40', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 05:55:40', '2024-10-23 05:55:40'),
(61, 'https://localhost/luna/site/wp-content/uploads/2024/10/text-logo.svg', '68:a00c028ddc3136895ba7e0e1dcd13e83', 58, 'post', 'attachment', 1, 6, NULL, NULL, 'text-logo', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 05:58:09', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 05:58:08', '2024-10-23 05:58:08'),
(62, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-one.png', '66:7dad5eb3ceea2fde76d4a1914865e8a5', 59, 'post', 'attachment', 1, 6, NULL, NULL, 'img-one', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-one.png', NULL, '59', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-one.png', '59', 'attachment-image', '{"width":580,"height":720,"filesize":826937,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/img-one.png","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/img-one.png","size":"full","id":59,"alt":"","pixels":417600,"type":"image\\/png"}', NULL, NULL, NULL, '2024-10-23 05:59:14', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 05:59:14', '2024-10-23 05:59:14'),
(63, NULL, NULL, 61, 'post', 'acf-field', 1, 49, NULL, NULL, 'Scrolling Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 06:14:11', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 06:14:11', '2024-10-23 06:14:11'),
(64, NULL, NULL, 62, 'post', 'acf-field', 1, 49, NULL, NULL, 'Big Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 06:14:12', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 06:14:12', '2024-10-23 06:14:12'),
(65, NULL, NULL, 63, 'post', 'acf-field', 1, 62, NULL, NULL, 'Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 06:14:12', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 06:14:12', '2024-10-23 06:14:12'),
(66, NULL, NULL, 64, 'post', 'acf-field', 1, 49, NULL, NULL, 'Small Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 06:14:13', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 06:14:13', '2024-10-23 06:14:13'),
(67, NULL, NULL, 65, 'post', 'acf-field', 1, 64, NULL, NULL, 'Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 06:14:13', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 06:14:13', '2024-10-23 06:14:13'),
(68, NULL, NULL, 67, 'post', 'acf-field', 1, 49, NULL, NULL, 'Package Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:10:48', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 17:10:47', '2024-10-23 17:10:47'),
(69, NULL, NULL, 68, 'post', 'acf-field', 1, 49, NULL, NULL, 'Packages', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:10:48', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:10:48', '2024-10-23 17:10:48'),
(70, NULL, NULL, 69, 'post', 'acf-field', 1, 68, NULL, NULL, 'Image', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:10:49', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:10:49', '2024-10-23 17:10:49'),
(71, NULL, NULL, 70, 'post', 'acf-field', 1, 68, NULL, NULL, 'Name', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:10:50', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:10:49', '2024-10-23 17:10:49'),
(72, NULL, NULL, 71, 'post', 'acf-field', 1, 68, NULL, NULL, 'Content', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:10:50', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:10:50', '2024-10-23 17:10:50'),
(73, NULL, NULL, 72, 'post', 'acf-field', 1, 68, NULL, NULL, 'Price', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:10:51', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:10:50', '2024-10-23 17:10:50'),
(74, NULL, NULL, 73, 'post', 'acf-field', 1, 68, NULL, NULL, 'Book Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:10:51', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:10:51', '2024-10-23 17:10:51'),
(75, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-four.jpg', '67:a3586fa369849127c3b8ca8c764ef921', 74, 'post', 'attachment', 1, 6, NULL, NULL, 'img-four', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-four.jpg', NULL, '74', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-four.jpg', '74', 'attachment-image', '{"width":501,"height":470,"filesize":130369,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/img-four.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/img-four.jpg","size":"full","id":74,"alt":"","pixels":235470,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-23 17:12:29', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 17:12:29', '2024-10-23 17:12:29'),
(76, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-three.jpg', '68:489e7e7bb162255907e1e37d2a433cf9', 75, 'post', 'attachment', 1, 6, NULL, NULL, 'img-three', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-three.jpg', NULL, '75', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-three.jpg', '75', 'attachment-image', '{"width":501,"height":470,"filesize":131527,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/img-three.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/img-three.jpg","size":"full","id":75,"alt":"","pixels":235470,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-23 17:12:32', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 17:12:31', '2024-10-23 17:12:31'),
(77, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-two.jpg', '66:441cbd59cb45ea29bc7005b742156842', 76, 'post', 'attachment', 1, 6, NULL, NULL, 'img-two', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-two.jpg', NULL, '76', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-two.jpg', '76', 'attachment-image', '{"width":501,"height":470,"filesize":88922,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/img-two.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/img-two.jpg","size":"full","id":76,"alt":"","pixels":235470,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-23 17:12:34', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 17:12:33', '2024-10-23 17:12:33'),
(78, NULL, NULL, 78, 'post', 'acf-field', 1, 49, NULL, NULL, 'Button Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:22:30', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 17:22:30', '2024-10-23 17:22:30'),
(79, NULL, NULL, 79, 'post', 'acf-field', 1, 49, NULL, NULL, 'Button Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:22:30', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:22:30', '2024-10-23 17:22:30'),
(80, NULL, NULL, 81, 'post', 'acf-field', 1, 49, NULL, NULL, 'Video Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:25:56', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 17:25:56', '2024-10-23 17:25:56'),
(81, NULL, NULL, 82, 'post', 'acf-field', 1, 49, NULL, NULL, 'Add Video', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:25:57', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 17:26:23', '2024-10-23 17:25:57'),
(82, NULL, NULL, 83, 'post', 'acf-field', 1, 49, NULL, NULL, 'Background Image', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:25:58', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 17:26:22', '2024-10-23 17:25:57'),
(83, 'https://localhost/luna/site/wp-content/uploads/2024/10/banner-three.jpg', '71:bd1e87f1011daff17eee90d0cd3bfa52', 84, 'post', 'attachment', 1, 6, NULL, NULL, 'banner-three', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/banner-three.jpg', NULL, '84', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/banner-three.jpg', '84', 'attachment-image', '{"width":1440,"height":875,"filesize":1177156,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/banner-three.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/banner-three.jpg","size":"full","id":84,"alt":"","pixels":1260000,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-23 17:26:41', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 17:26:41', '2024-10-23 17:26:41'),
(84, 'https://localhost/luna/site/wp-content/uploads/2024/10/video.mp4', '64:d7712fb638cda17eed1c75a8bacaf701', 85, 'post', 'attachment', 1, 6, NULL, NULL, 'video', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 17:27:03', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 17:27:02', '2024-10-23 17:27:02'),
(85, NULL, NULL, 87, 'post', 'acf-field', 1, 49, NULL, NULL, 'Testimonial Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:32:47', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 17:32:47', '2024-10-23 17:32:47'),
(86, NULL, NULL, 88, 'post', 'acf-field', 1, 49, NULL, NULL, 'Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:32:48', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:32:47', '2024-10-23 17:32:47'),
(87, NULL, NULL, 89, 'post', 'acf-field', 1, 49, NULL, NULL, 'Image', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:32:48', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:32:48', '2024-10-23 17:32:48'),
(88, NULL, NULL, 90, 'post', 'acf-field', 1, 49, NULL, NULL, 'Image Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:32:49', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:32:49', '2024-10-23 17:32:49'),
(89, NULL, NULL, 91, 'post', 'acf-field', 1, 49, NULL, NULL, 'Content', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:32:50', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:32:50', '2024-10-23 17:32:50'),
(90, NULL, NULL, 92, 'post', 'acf-field', 1, 49, NULL, NULL, 'Name', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:32:51', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:32:51', '2024-10-23 17:32:51'),
(91, NULL, NULL, 93, 'post', 'acf-field', 1, 49, NULL, NULL, 'Insights Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:35:32', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 17:35:32', '2024-10-23 17:35:32'),
(92, NULL, NULL, 94, 'post', 'acf-field', 1, 49, NULL, NULL, 'Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:35:33', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:35:32', '2024-10-23 17:35:32'),
(93, NULL, NULL, 95, 'post', 'acf-field', 1, 49, NULL, NULL, 'Insights', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:35:33', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:35:33', '2024-10-23 17:35:33'),
(94, NULL, NULL, 96, 'post', 'acf-field', 1, 95, NULL, NULL, 'Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:35:34', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 17:40:47', '2024-10-23 17:35:34'),
(95, NULL, NULL, 97, 'post', 'acf-field', 1, 95, NULL, NULL, 'Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:35:34', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 17:40:48', '2024-10-23 17:35:34'),
(96, NULL, NULL, 98, 'post', 'acf-field', 1, 49, NULL, NULL, 'Blog Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:40:49', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 17:40:48', '2024-10-23 17:40:48'),
(97, NULL, NULL, 99, 'post', 'acf-field', 1, 49, NULL, NULL, 'Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:40:49', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:40:49', '2024-10-23 17:40:49'),
(98, NULL, NULL, 100, 'post', 'acf-field', 1, 49, NULL, NULL, 'Blogs', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:40:50', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:40:50', '2024-10-23 17:40:50'),
(99, NULL, NULL, 101, 'post', 'acf-field', 1, 100, NULL, NULL, 'Image', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:40:50', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:40:50', '2024-10-23 17:40:50'),
(100, NULL, NULL, 102, 'post', 'acf-field', 1, 100, NULL, NULL, 'Date', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:40:51', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:40:50', '2024-10-23 17:40:50'),
(101, NULL, NULL, 103, 'post', 'acf-field', 1, 100, NULL, NULL, 'Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:40:51', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:40:51', '2024-10-23 17:40:51') ;
INSERT INTO `wp_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(102, NULL, NULL, 104, 'post', 'acf-field', 1, 100, NULL, NULL, 'Content', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:40:52', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:40:51', '2024-10-23 17:40:51'),
(103, NULL, NULL, 105, 'post', 'acf-field', 1, 100, NULL, NULL, 'Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 17:40:53', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 17:40:52', '2024-10-23 17:40:52'),
(104, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-five.jpg', '67:ad5ff9e86f0b0db372496fc0750baa38', 106, 'post', 'attachment', 1, 6, NULL, NULL, 'img-five', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-five.jpg', NULL, '106', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-five.jpg', '106', 'attachment-image', '{"width":623,"height":574,"filesize":206067,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/img-five.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/img-five.jpg","size":"full","id":106,"alt":"","pixels":357602,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-23 17:42:13', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 17:42:12', '2024-10-23 17:42:12'),
(105, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-four.jpg', '72:61203601a73a2fb5c26ea11f1e5c1757', 107, 'post', 'attachment', 1, 6, NULL, NULL, 'detailed-four', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-four.jpg', NULL, '107', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-four.jpg', '107', 'attachment-image', '{"width":371,"height":351,"filesize":55621,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/detailed-four.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/detailed-four.jpg","size":"full","id":107,"alt":"","pixels":130221,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-23 17:44:09', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 17:44:08', '2024-10-23 17:44:08'),
(106, 'https://localhost/luna/site/?post_type=acf-field-group&p=111', '60:a3b4a23d7bfa0d9e29d390671415c401', 111, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Theme General Settings', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:13:27', '2024-10-25 12:07:38', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 12:07:38', '2024-10-23 18:13:26'),
(107, 'https://localhost/luna/site/?post_type=acf-field&p=112', '54:9e67187e28428707a08d63b23d766c18', 112, 'post', 'acf-field', 1, 111, NULL, NULL, 'Site Logo', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:13:27', '2024-10-25 09:43:20', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 09:43:20', '2024-10-23 18:13:26'),
(108, 'https://localhost/luna/site/wp-content/uploads/2024/10/about-page.jpg', '69:ff76677da1ae29a78e6e6702dedcb205', 113, 'post', 'attachment', 1, 8, NULL, NULL, 'about-page', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/about-page.jpg', NULL, '113', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/about-page.jpg', '113', 'attachment-image', '{"width":457,"height":644,"filesize":310319,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/about-page.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/about-page.jpg","size":"full","id":113,"alt":"","pixels":294308,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-23 18:16:28', '2024-10-25 05:52:38', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 18:16:27', '2024-10-23 18:16:27'),
(109, NULL, NULL, NULL, 'post-type-archive', 'blogs', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Blogs', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 18:21:18', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(110, NULL, NULL, NULL, 'post-type-archive', 'services', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Services', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 18:21:19', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(111, NULL, NULL, NULL, 'post-type-archive', 'press', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Press', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 18:21:20', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(112, NULL, NULL, NULL, 'post-type-archive', 'newsletter', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Newsletter', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-23 18:21:20', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL),
(113, 'https://localhost/luna/site/?post_type=acf-field-group&p=114', '60:2e71325dca1619c1c48183e4edc6ba27', 114, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Service Page Settings', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:31:34', '2024-11-04 09:06:48', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-04 09:06:48', '2024-10-23 18:31:34'),
(114, NULL, NULL, 115, 'post', 'acf-field', 1, 114, NULL, NULL, 'Banner Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:31:34', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 18:31:34', '2024-10-23 18:31:34'),
(115, NULL, NULL, 116, 'post', 'acf-field', 1, 114, NULL, NULL, 'Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:31:35', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 18:31:35', '2024-10-23 18:31:35'),
(116, NULL, NULL, 117, 'post', 'acf-field', 1, 114, NULL, NULL, 'Scrolling Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:31:36', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 18:31:35', '2024-10-23 18:31:35'),
(117, NULL, NULL, 118, 'post', 'acf-field', 1, 117, NULL, NULL, 'Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:31:36', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 18:31:36', '2024-10-23 18:31:36'),
(118, 'https://localhost/luna/site/?post_type=acf-field&p=119', '54:d3ef83539496e0766d7d3a8e6ffeea7a', 119, 'post', 'acf-field', 1, 114, NULL, NULL, 'Services', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:31:37', '2024-11-04 09:06:48', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-23 18:33:11', '2024-10-23 18:31:37'),
(119, NULL, NULL, 120, 'post', 'acf-field', 1, 119, NULL, NULL, 'Service Name', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:31:38', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 18:31:38', '2024-10-23 18:31:38'),
(120, NULL, NULL, 121, 'post', 'acf-field', 1, 119, NULL, NULL, 'Description', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:31:39', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 18:31:38', '2024-10-23 18:31:38'),
(121, NULL, NULL, 122, 'post', 'acf-field', 1, 119, NULL, NULL, 'Price', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:31:39', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 18:31:39', '2024-10-23 18:31:39'),
(122, NULL, NULL, 123, 'post', 'acf-field', 1, 114, NULL, NULL, 'Services Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:33:11', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 18:33:10', '2024-10-23 18:33:10'),
(123, 'https://localhost/luna/site/125/', '32:f3cea66b72ce1795251cb398a0ee76ae', 125, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Styling Services', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:55:20', '2024-11-06 08:58:14', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:58:14', '2024-10-23 18:55:42'),
(124, NULL, NULL, 126, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Home Page Settings (copy)', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:51', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:09:22', '2024-10-23 19:00:30'),
(125, NULL, NULL, 127, 'post', 'acf-field', 1, 126, NULL, NULL, 'Banner Section', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:51', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:24', '2024-10-23 18:59:51'),
(126, NULL, NULL, 128, 'post', 'acf-field', 1, 126, NULL, NULL, 'Banner Logo', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:52', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:24', '2024-10-23 18:59:52'),
(127, NULL, NULL, 129, 'post', 'acf-field', 1, 126, NULL, NULL, 'Banner Text', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:52', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:25', '2024-10-23 18:59:52'),
(128, NULL, NULL, 130, 'post', 'acf-field', 1, 126, NULL, NULL, 'Banner Image', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:53', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:25', '2024-10-23 18:59:53'),
(129, NULL, NULL, 131, 'post', 'acf-field', 1, 126, NULL, NULL, 'Content', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:54', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:26', '2024-10-23 18:59:54'),
(130, NULL, NULL, 132, 'post', 'acf-field', 1, 126, NULL, NULL, 'Service Content', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:55', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:27', '2024-10-23 18:59:55'),
(131, NULL, NULL, 133, 'post', 'acf-field', 1, 126, NULL, NULL, 'Link text', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:56', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:28', '2024-10-23 18:59:56'),
(132, NULL, NULL, 134, 'post', 'acf-field', 1, 126, NULL, NULL, 'Link Url', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:56', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:28', '2024-10-23 18:59:56'),
(133, NULL, NULL, 135, 'post', 'acf-field', 1, 126, NULL, NULL, 'Scrolling Section', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:57', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:30', '2024-10-23 18:59:57'),
(134, NULL, NULL, 136, 'post', 'acf-field', 1, 126, NULL, NULL, 'Big Text', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:58', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:30', '2024-10-23 18:59:57'),
(135, NULL, NULL, 137, 'post', 'acf-field', 1, 136, NULL, NULL, 'Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 18:59:59', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 18:59:59', '2024-10-23 18:59:59'),
(136, NULL, NULL, 138, 'post', 'acf-field', 1, 126, NULL, NULL, 'Small Text', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:01', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:31', '2024-10-23 19:00:00'),
(137, NULL, NULL, 139, 'post', 'acf-field', 1, 138, NULL, NULL, 'Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:02', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:02', '2024-10-23 19:00:02'),
(138, NULL, NULL, 140, 'post', 'acf-field', 1, 126, NULL, NULL, 'Package Section', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:03', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:32', '2024-10-23 19:00:03'),
(139, NULL, NULL, 141, 'post', 'acf-field', 1, 126, NULL, NULL, 'Packages', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:03', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:33', '2024-10-23 19:00:03'),
(140, NULL, NULL, 142, 'post', 'acf-field', 1, 141, NULL, NULL, 'Image', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:04', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:04', '2024-10-23 19:00:04'),
(141, NULL, NULL, 143, 'post', 'acf-field', 1, 141, NULL, NULL, 'Name', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:04', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:04', '2024-10-23 19:00:04'),
(142, NULL, NULL, 144, 'post', 'acf-field', 1, 141, NULL, NULL, 'Content', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:05', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:05', '2024-10-23 19:00:05'),
(143, NULL, NULL, 145, 'post', 'acf-field', 1, 141, NULL, NULL, 'Price', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:06', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:05', '2024-10-23 19:00:05'),
(144, NULL, NULL, 146, 'post', 'acf-field', 1, 141, NULL, NULL, 'Book Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:06', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:06', '2024-10-23 19:00:06'),
(145, NULL, NULL, 147, 'post', 'acf-field', 1, 126, NULL, NULL, 'Button Text', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:07', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:33', '2024-10-23 19:00:07'),
(146, NULL, NULL, 148, 'post', 'acf-field', 1, 126, NULL, NULL, 'Button Link', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:08', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:34', '2024-10-23 19:00:07'),
(147, NULL, NULL, 149, 'post', 'acf-field', 1, 126, NULL, NULL, 'Video Section', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:09', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:35', '2024-10-23 19:00:09'),
(148, NULL, NULL, 150, 'post', 'acf-field', 1, 126, NULL, NULL, 'Background Image', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:11', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:35', '2024-10-23 19:00:10'),
(149, NULL, NULL, 151, 'post', 'acf-field', 1, 126, NULL, NULL, 'Add Video', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:11', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:37', '2024-10-23 19:00:11'),
(150, NULL, NULL, 152, 'post', 'acf-field', 1, 126, NULL, NULL, 'Testimonial Section', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:12', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:37', '2024-10-23 19:00:12'),
(151, NULL, NULL, 153, 'post', 'acf-field', 1, 126, NULL, NULL, 'Title', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:13', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:39', '2024-10-23 19:00:12'),
(152, NULL, NULL, 154, 'post', 'acf-field', 1, 126, NULL, NULL, 'Image', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:13', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:39', '2024-10-23 19:00:13'),
(153, NULL, NULL, 155, 'post', 'acf-field', 1, 126, NULL, NULL, 'Image Text', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:14', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:40', '2024-10-23 19:00:14'),
(154, NULL, NULL, 156, 'post', 'acf-field', 1, 126, NULL, NULL, 'Content', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:15', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:41', '2024-10-23 19:00:15'),
(155, NULL, NULL, 157, 'post', 'acf-field', 1, 126, NULL, NULL, 'Name', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:16', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:42', '2024-10-23 19:00:16'),
(156, NULL, NULL, 158, 'post', 'acf-field', 1, 126, NULL, NULL, 'Insights Section', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:17', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:42', '2024-10-23 19:00:17'),
(157, NULL, NULL, 159, 'post', 'acf-field', 1, 126, NULL, NULL, 'Title', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:18', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:43', '2024-10-23 19:00:18'),
(158, NULL, NULL, 160, 'post', 'acf-field', 1, 126, NULL, NULL, 'Insights', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:19', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:44', '2024-10-23 19:00:19'),
(159, NULL, NULL, 161, 'post', 'acf-field', 1, 160, NULL, NULL, 'Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:20', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:20', '2024-10-23 19:00:20'),
(160, NULL, NULL, 162, 'post', 'acf-field', 1, 160, NULL, NULL, 'Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:21', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:20', '2024-10-23 19:00:20'),
(161, NULL, NULL, 163, 'post', 'acf-field', 1, 126, NULL, NULL, 'Blog Section', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:22', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:46', '2024-10-23 19:00:22'),
(162, NULL, NULL, 164, 'post', 'acf-field', 1, 126, NULL, NULL, 'Title', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:23', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:46', '2024-10-23 19:00:22'),
(163, NULL, NULL, 165, 'post', 'acf-field', 1, 126, NULL, NULL, 'Blogs', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:23', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-23 19:09:47', '2024-10-23 19:00:23'),
(164, NULL, NULL, 166, 'post', 'acf-field', 1, 165, NULL, NULL, 'Image', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:24', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:24', '2024-10-23 19:00:24'),
(165, NULL, NULL, 167, 'post', 'acf-field', 1, 165, NULL, NULL, 'Date', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:26', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:25', '2024-10-23 19:00:25'),
(166, NULL, NULL, 168, 'post', 'acf-field', 1, 165, NULL, NULL, 'Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:26', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:26', '2024-10-23 19:00:26'),
(167, NULL, NULL, 169, 'post', 'acf-field', 1, 165, NULL, NULL, 'Content', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:27', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:27', '2024-10-23 19:00:27'),
(168, NULL, NULL, 170, 'post', 'acf-field', 1, 165, NULL, NULL, 'Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:00:28', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:00:27', '2024-10-23 19:00:27'),
(169, NULL, NULL, 174, 'post', 'wpcf7_contact_form', 1, 0, NULL, NULL, 'Contact', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-23 19:33:14', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-23 19:44:51', '2024-10-23 19:33:14'),
(170, 'https://localhost/luna/site/outfit/kristen-osborne/', '51:ef2c6d3a11b1acd9bedba2248ceb14da', 176, 'post', 'outfit', 1, 0, NULL, NULL, 'Kristen Osborne', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-one.jpg', NULL, '178', 'featured-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-one.jpg', '178', 'featured-image', '{"width":583,"height":1054,"filesize":318208,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/detailed-one.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/detailed-one.jpg","size":"full","id":178,"alt":"","pixels":614482,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-10-24 04:48:33', '2024-11-04 15:38:07', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-11-04 15:38:07', '2024-10-24 04:48:32'),
(171, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-one.jpg', '71:fb8190236bce559a5d295819c2625c21', 178, 'post', 'attachment', 1, 176, NULL, NULL, 'detailed-one', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-one.jpg', NULL, '178', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-one.jpg', '178', 'attachment-image', '{"width":583,"height":1054,"filesize":318208,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/detailed-one.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/detailed-one.jpg","size":"full","id":178,"alt":"","pixels":614482,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-24 04:51:18', '2024-11-04 08:38:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 04:51:18', '2024-10-24 04:51:18'),
(172, 'https://localhost/luna/site/outfit/', '35:a707771ab434ec789e7560224871cfc0', NULL, 'post-type-archive', 'outfit', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Outfits', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-24 04:56:11', '2024-11-05 07:38:36', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-05 07:38:35', '2024-10-24 04:48:32'),
(173, 'https://localhost/luna/site/?post_type=acf-field-group&p=182', '60:801b8b361354ccfe458d728361685840', 182, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Outfit Details', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:06:07', '2024-10-25 11:59:37', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 11:59:37', '2024-10-24 05:06:06'),
(174, NULL, NULL, 183, 'post', 'acf-field', 1, 182, NULL, NULL, 'Thumbnail Image Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:06:07', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-24 05:06:06', '2024-10-24 05:06:06'),
(175, NULL, NULL, 184, 'post', 'acf-field', 1, 182, NULL, NULL, 'Thumbnail Image', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:06:08', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-24 05:06:07', '2024-10-24 05:06:07'),
(176, NULL, NULL, 185, 'post', 'acf-field', 1, 182, NULL, NULL, 'Position', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:06:08', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-24 05:06:08', '2024-10-24 05:06:08'),
(177, NULL, NULL, 186, 'post', 'acf-field', 1, 182, NULL, NULL, 'Image Gallery Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:06:09', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-24 05:06:09', '2024-10-24 05:06:09'),
(178, NULL, NULL, 187, 'post', 'acf-field', 1, 182, NULL, NULL, 'Gallery Images', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:06:09', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-24 05:06:09', '2024-10-24 05:06:09'),
(179, NULL, NULL, 188, 'post', 'acf-field', 1, 187, NULL, NULL, 'Image', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:06:10', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-24 05:06:09', '2024-10-24 05:06:09'),
(180, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-seven.jpg', '68:477f39d2f4255dcc3b686c3ad7c7f7a2', 189, 'post', 'attachment', 1, 176, NULL, NULL, 'img-seven', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-seven.jpg', NULL, '189', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-seven.jpg', '189', 'attachment-image', '{"width":550,"height":517,"filesize":209466,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/img-seven.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/img-seven.jpg","size":"full","id":189,"alt":"","pixels":284350,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-24 05:07:38', '2024-11-04 08:38:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 05:07:38', '2024-10-24 05:07:38'),
(181, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-three.jpg', '73:99c87fd4ea1eb75f07cfdb964404f8c6', 190, 'post', 'attachment', 1, 176, NULL, NULL, 'detailed-three', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-three.jpg', NULL, '190', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-three.jpg', '190', 'attachment-image', '{"width":300,"height":332,"filesize":48627,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/detailed-three.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/detailed-three.jpg","size":"full","id":190,"alt":"","pixels":99600,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-24 05:08:26', '2024-11-04 08:38:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 05:08:26', '2024-10-24 05:08:26'),
(182, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-two.jpg', '71:e9844c0710fcc81ed03225b2c1d6389b', 191, 'post', 'attachment', 1, 176, NULL, NULL, 'detailed-two', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-two.jpg', NULL, '191', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-two.jpg', '191', 'attachment-image', '{"width":267,"height":332,"filesize":44108,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/detailed-two.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/detailed-two.jpg","size":"full","id":191,"alt":"","pixels":88644,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-24 05:08:28', '2024-11-04 08:38:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 05:08:28', '2024-10-24 05:08:28'),
(183, NULL, NULL, 193, 'post', 'acf-field', 1, 182, NULL, NULL, 'Outfit Ideas', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:10:37', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-24 05:12:13', '2024-10-24 05:10:37'),
(184, NULL, NULL, 194, 'post', 'acf-field', 1, 193, NULL, NULL, 'Image', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:10:38', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-24 05:10:38', '2024-10-24 05:10:38'),
(185, NULL, NULL, 195, 'post', 'acf-field', 1, 193, NULL, NULL, 'Details', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:10:39', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 0, NULL, 0, '2024-10-24 05:10:39', '2024-10-24 05:10:39'),
(186, NULL, NULL, 196, 'post', 'acf-field', 1, 182, NULL, NULL, 'Outfit Ideas Section', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 05:12:13', '2024-10-24 00:32:40', 1, NULL, NULL, NULL, NULL, 1, NULL, 0, '2024-10-24 05:12:12', '2024-10-24 05:12:12'),
(187, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-five.jpg', '72:bdd237ca26dd4975c78f696bd2b9c5d4', 197, 'post', 'attachment', 1, 176, NULL, NULL, 'detailed-five', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-five.jpg', NULL, '197', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-five.jpg', '197', 'attachment-image', '{"width":371,"height":351,"filesize":38092,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/detailed-five.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/detailed-five.jpg","size":"full","id":197,"alt":"","pixels":130221,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-24 05:12:53', '2024-11-04 08:38:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 05:12:52', '2024-10-24 05:12:52'),
(188, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-four-1.jpg', '74:5ca495427608efaab8599911c80f34a3', 198, 'post', 'attachment', 1, 176, NULL, NULL, 'detailed-four', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-four-1.jpg', NULL, '198', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-four-1.jpg', '198', 'attachment-image', '{"width":371,"height":351,"filesize":55621,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/detailed-four-1.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/detailed-four-1.jpg","size":"full","id":198,"alt":"","pixels":130221,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-24 05:12:55', '2024-11-04 08:38:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 05:12:55', '2024-10-24 05:12:55'),
(189, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-six.jpg', '71:ef5f10d5320431ec9b17fcc439d04713', 199, 'post', 'attachment', 1, 176, NULL, NULL, 'detailed-six', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-six.jpg', NULL, '199', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-six.jpg', '199', 'attachment-image', '{"width":371,"height":351,"filesize":47116,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/detailed-six.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/detailed-six.jpg","size":"full","id":199,"alt":"","pixels":130221,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-24 05:12:58', '2024-11-04 08:38:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 05:12:57', '2024-10-24 05:12:57'),
(190, 'https://localhost/luna/site/outfit/vi-rodriguez/', '48:5e1c22468bc3a5954b1364515fab9489', 201, 'post', 'outfit', 1, 0, NULL, NULL, 'Vi Rodriguez', 'publish', 0, 1, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-one.jpg', NULL, '178', 'featured-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-one.jpg', '178', 'featured-image', '{"width":583,"height":1054,"filesize":318208,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/detailed-one.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/detailed-one.jpg","size":"full","id":178,"alt":"","pixels":614482,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-10-24 05:25:21', '2024-11-04 07:12:00', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-11-04 07:12:00', '2024-10-24 05:25:21'),
(191, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-six.jpg', '66:bd6d033c865735399dedbfe2a11c7492', 203, 'post', 'attachment', 1, 201, NULL, NULL, 'img-six', 'inherit', NULL, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-six.jpg', NULL, '203', 'attachment-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-six.jpg', '203', 'attachment-image', '{"width":551,"height":517,"filesize":229486,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/img-six.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/img-six.jpg","size":"full","id":203,"alt":"","pixels":284867,"type":"image\\/jpeg"}', NULL, NULL, NULL, '2024-10-24 05:26:07', '2024-11-04 00:12:00', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 05:26:06', '2024-10-24 05:26:06'),
(192, 'https://localhost/luna/site/blogs/he-power-of-a-lookbook-stylist-why-every-brand-needs-one/', '91:46c3646b5361445cd81ed82f3959f7c0', 205, 'post', 'blogs', 1, 0, NULL, NULL, 'The Power of a Lookbook Stylist: Why Every Brand Needs One', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 30, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-five.jpg', NULL, '106', 'featured-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/img-five.jpg', '106', 'featured-image', '{"width":623,"height":574,"filesize":206067,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/img-five.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/img-five.jpg","size":"full","id":106,"alt":"","pixels":357602,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-10-24 05:58:11', '2024-10-25 06:28:40', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-10-25 06:28:40', '2024-10-24 05:59:43'),
(194, 'https://localhost/luna/site/blogs/elevate-your-fashion-game-why-you-need-a-lookbook-stylist/', '92:d89f696cfbf870deb578c08a36d18a10', 208, 'post', 'blogs', 1, 0, NULL, NULL, 'Elevate Your Fashion Game: Why You Need a Lookbook Stylist', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 60, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/banner-three.jpg', NULL, '84', 'featured-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/banner-three.jpg', '84', 'featured-image', '{"width":1440,"height":875,"filesize":1177156,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/banner-three.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/banner-three.jpg","size":"full","id":84,"alt":"","pixels":1260000,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-10-24 06:09:54', '2024-10-25 06:27:56', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-10-25 06:27:56', '2024-10-24 06:09:53'),
(195, 'https://localhost/luna/site/styling-questionnaire/', '50:e6ec770eebc430810b47153c2eda46dd', 210, 'post', 'page', 1, 0, NULL, NULL, 'Styling Questionnaire', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 06:15:44', '2024-10-25 11:54:45', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-10-25 11:54:45', '2024-10-24 06:16:15'),
(196, 'https://localhost/luna/site/?p=212', '34:a1f66413f87212a9aa595be124d593e8', 212, 'post', 'customize_changeset', 1, 0, NULL, NULL, '', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-24 07:47:18', '2024-10-24 07:47:18', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-24 07:47:18', '2024-10-24 07:47:18'),
(197, 'https://localhost/luna/site/wp-content/uploads/2024/10/lune.png', '63:a05ef3c7f3b946ac4881f083d38e623b', 213, 'post', 'attachment', 1, 0, NULL, NULL, 'lune', 'inherit', 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/lune.png', NULL, '213', 'attachment-image', NULL, NULL, NULL, '213', 'attachment-image', NULL, NULL, NULL, NULL, '2024-10-24 07:48:43', '2024-10-24 07:48:43', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-24 07:48:43', '2024-10-24 07:48:43'),
(198, 'https://localhost/luna/site/wp-content/uploads/2024/10/cropped-lune.png', '71:d04e2dee98d7f96acf3a64cd9bc643f4', 214, 'post', 'attachment', 1, 213, NULL, NULL, 'cropped-lune.png', 'inherit', NULL, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/cropped-lune.png', NULL, '214', 'attachment-image', NULL, NULL, NULL, '214', 'attachment-image', NULL, NULL, NULL, NULL, '2024-10-24 07:48:46', '2024-10-24 07:48:46', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 07:48:46', '2024-10-24 07:48:46'),
(199, 'https://localhost/luna/site/?p=215', '34:da03ea5480cb7de25fd72af06f5995fe', 215, 'post', 'customize_changeset', 1, 0, NULL, NULL, '', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-24 07:48:50', '2024-10-24 07:48:50', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-24 07:48:50', '2024-10-24 07:48:50'),
(200, 'https://localhost/luna/site/blogs/', '34:12c23e4ba8666dfae5da6d2387dd3c37', NULL, 'post-type-archive', 'blogs', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Blogs', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-24 12:52:13', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-24 06:10:10', '2024-10-24 05:59:43'),
(201, 'https://localhost/luna/site/outfit/', '35:a707771ab434ec789e7560224871cfc0', NULL, 'post-type-archive', 'outfit', NULL, NULL, '%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%', '', 'Outfits', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-24 12:52:13', '2024-10-24 12:52:13', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-24 05:26:15', '2024-10-24 04:48:32'),
(202, 'https://localhost/luna/site/wp-content/uploads/2024/10/contact-image.jpg', '72:5b41b1a50b5ca4861844886c66b502e8', 216, 'post', 'attachment', 1, 25, NULL, NULL, 'contact-image', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/contact-image.jpg', NULL, '216', 'attachment-image', NULL, NULL, NULL, '216', 'attachment-image', NULL, NULL, NULL, NULL, '2024-10-24 12:53:15', '2024-10-24 12:53:15', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 12:53:15', '2024-10-24 12:53:15') ;
INSERT INTO `wp_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(203, 'https://localhost/luna/site/?post_type=acf-field-group&p=218', '60:b9816a808d60e0574f9a9950a68b883b', 218, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Blog Page Settings', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 14:04:49', '2024-10-24 14:04:49', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-24 14:04:49', '2024-10-24 14:04:49'),
(204, 'https://localhost/luna/site/?post_type=acf-field&p=219', '54:12c1d9353a638d432baaacd1cb4f04ee', 219, 'post', 'acf-field', 1, 218, NULL, NULL, 'Page Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 14:04:49', '2024-10-24 14:04:49', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-24 14:04:49', '2024-10-24 14:04:49'),
(205, 'https://localhost/luna/site/?post_type=acf-field&p=220', '54:3cfa223b8dfd605f473dfc1229d3d665', 220, 'post', 'acf-field', 1, 218, NULL, NULL, 'Scrolling Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 14:04:49', '2024-10-24 14:04:49', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-24 14:04:49', '2024-10-24 14:04:49'),
(206, 'https://localhost/luna/site/?post_type=acf-field&p=221', '54:1cd17e151fe9bb547efd32879ce30b09', 221, 'post', 'acf-field', 1, 220, NULL, NULL, 'Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-24 14:04:49', '2024-10-24 14:04:49', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-24 14:04:49', '2024-10-24 14:04:49'),
(207, 'https://localhost/luna/site/223/', '32:f26b71122398a4da4ca868e97f24ef6f', 223, 'post', 'nav_menu_item', 1, 0, NULL, NULL, '', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 04:02:34', '2024-11-06 08:58:14', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:58:14', '2024-10-25 04:03:41'),
(208, 'https://localhost/luna/site/224/', '32:657324864862ff970999e060061fe50c', 224, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Blogs', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 04:03:54', '2024-11-06 08:58:14', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:58:14', '2024-10-25 04:03:59'),
(209, 'https://localhost/luna/site/?post_type=acf-field-group&p=230', '60:f8011e0b3b6e7a615301cf60bef9dabe', 230, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Blog Date', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 06:27:01', '2024-10-25 06:27:01', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 06:27:01', '2024-10-25 06:27:01'),
(210, 'https://localhost/luna/site/?post_type=acf-field&p=231', '54:b13100f76405f65cb6f52a19179412dd', 231, 'post', 'acf-field', 1, 230, NULL, NULL, 'Date', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 06:27:01', '2024-10-25 06:27:01', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 06:27:01', '2024-10-25 06:27:01'),
(211, 'https://localhost/luna/site/?post_type=acf-field-group&p=234', '60:18e47452a2f16a4425034790b692c9ef', 234, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'FAQ Page', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 06:46:16', '2024-10-25 06:46:23', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 06:46:23', '2024-10-25 06:46:16'),
(212, 'https://localhost/luna/site/?post_type=acf-field&p=235', '54:c88fd7cc1be759c2f8cc932ab90cad76', 235, 'post', 'acf-field', 1, 234, NULL, NULL, 'Page Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 06:46:16', '2024-10-25 06:46:16', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 06:46:16', '2024-10-25 06:46:16'),
(213, 'https://localhost/luna/site/?post_type=acf-field&p=236', '54:a36867f913f85a2c38f785cef204d9b5', 236, 'post', 'acf-field', 1, 234, NULL, NULL, 'FAQ&#8217;s', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 06:46:16', '2024-10-25 06:46:16', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 06:46:16', '2024-10-25 06:46:16'),
(214, 'https://localhost/luna/site/?post_type=acf-field&p=237', '54:2d0d05ebeb36164888437c9923b95358', 237, 'post', 'acf-field', 1, 236, NULL, NULL, 'Question', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 06:46:16', '2024-10-25 06:46:16', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 06:46:16', '2024-10-25 06:46:16'),
(215, 'https://localhost/luna/site/?post_type=acf-field&p=238', '54:41e50898ec0b1c9308a72b0386a3de28', 238, 'post', 'acf-field', 1, 236, NULL, NULL, 'Answer', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 06:46:16', '2024-10-25 06:46:16', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 06:46:16', '2024-10-25 06:46:16'),
(216, 'https://localhost/luna/site/?post_type=wpcf7_contact_form&p=240', '63:b0df7e9f32d8e63709e2aacfd2f1f3fc', 240, 'post', 'wpcf7_contact_form', 1, 0, NULL, NULL, 'Contact Styling', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 07:00:46', '2024-10-25 08:20:03', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 08:20:03', '2024-10-25 07:00:46'),
(217, 'https://localhost/luna/site/?post_type=acf-field&p=241', '54:a8a17939a78834dbe46bad77ee86f605', 241, 'post', 'acf-field', 1, 111, NULL, NULL, 'Footer Contact Settings', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 08:22:40', '2024-10-25 09:50:57', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 09:50:57', '2024-10-25 08:22:40'),
(218, 'https://localhost/luna/site/?post_type=acf-field&p=242', '54:26a167afdb0084f5fc8f4539b6fc3d85', 242, 'post', 'acf-field', 1, 111, NULL, NULL, 'Scrolling Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 09:16:28', '2024-10-25 09:43:21', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 09:43:21', '2024-10-25 09:16:28'),
(219, 'https://localhost/luna/site/?post_type=acf-field&p=243', '54:2a6991f52902a09b15fb2573bf9e616d', 243, 'post', 'acf-field', 1, 242, NULL, NULL, 'Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 09:16:28', '2024-10-25 09:16:28', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 09:16:28', '2024-10-25 09:16:28'),
(220, 'https://localhost/luna/site/?post_type=acf-field&p=244', '54:ac5213d1ad5def59ac617e96d2556797', 244, 'post', 'acf-field', 1, 111, NULL, NULL, 'Contact Number', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 09:40:52', '2024-10-25 09:43:21', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 09:43:21', '2024-10-25 09:40:52'),
(221, 'https://localhost/luna/site/?post_type=acf-field&p=245', '54:7ed86e9796a14e53896ec7747d7445e8', 245, 'post', 'acf-field', 1, 111, NULL, NULL, 'Email Id', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 09:40:52', '2024-10-25 09:43:21', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 09:43:21', '2024-10-25 09:40:52'),
(222, 'https://localhost/luna/site/?post_type=acf-field&p=246', '54:514dac8eb315f7cf051958fdcb6497eb', 246, 'post', 'acf-field', 1, 111, NULL, NULL, 'Copyright Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 09:40:52', '2024-10-25 09:43:21', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 09:43:21', '2024-10-25 09:40:52'),
(223, 'https://localhost/luna/site/?post_type=acf-field&p=247', '54:41fe924c6cf8c84d9401de945a2ed4c1', 247, 'post', 'acf-field', 1, 111, NULL, NULL, 'Contact Icon', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 09:41:37', '2024-10-25 09:43:21', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 09:43:21', '2024-10-25 09:41:37'),
(224, 'https://localhost/luna/site/?post_type=acf-field&p=248', '54:7bf18336f9a4f32f36065993907473f2', 248, 'post', 'acf-field', 1, 111, NULL, NULL, 'Email Icon', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 09:41:37', '2024-10-25 09:43:21', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 09:43:21', '2024-10-25 09:41:37'),
(225, 'https://localhost/luna/site/?post_type=acf-field&p=249', '54:06876d37b429c8d3fb41bb223072fc57', 249, 'post', 'acf-field', 1, 111, NULL, NULL, 'Contact Settings', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 09:42:46', '2024-10-25 09:43:21', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 09:43:21', '2024-10-25 09:42:46'),
(226, 'https://localhost/luna/site/?post_type=acf-field&p=250', '54:af0e8263e419fa41d61e9e317d9a1e5f', 250, 'post', 'acf-field', 1, 111, NULL, NULL, 'Logo Settings', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 09:43:20', '2024-10-25 09:43:20', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 09:43:20', '2024-10-25 09:43:20'),
(227, 'https://localhost/luna/site/?post_type=acf-field-group&p=251', '60:c3d81a48317bdf3e2312e3a552e14c56', 251, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Contact Page Settings', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:14:25', '2024-10-25 11:22:09', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 11:22:09', '2024-10-25 11:14:25'),
(228, 'https://localhost/luna/site/?post_type=acf-field&p=252', '54:5cf87fce798be5b791fc22f883678a1a', 252, 'post', 'acf-field', 1, 251, NULL, NULL, 'Heading', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:15:08', '2024-10-25 11:15:08', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 11:15:08', '2024-10-25 11:15:08'),
(229, 'https://localhost/luna/site/?post_type=acf-field&p=254', '54:c8a2a3deb72b7aad13c121eea77aa43d', 254, 'post', 'acf-field', 1, 251, NULL, NULL, 'Contact Number', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:19:54', '2024-10-25 11:19:54', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 11:19:54', '2024-10-25 11:19:54'),
(230, 'https://localhost/luna/site/?post_type=acf-field&p=255', '54:bee210e3b45fb6d4656bb33b9e7b23aa', 255, 'post', 'acf-field', 1, 251, NULL, NULL, 'Email ID', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:19:54', '2024-10-25 11:22:09', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 11:22:09', '2024-10-25 11:19:54'),
(231, 'https://localhost/luna/site/?post_type=acf-field&p=256', '54:f67b47864fe78177acd0d3018006574f', 256, 'post', 'acf-field', 1, 251, NULL, NULL, 'Form Heading', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:19:54', '2024-10-25 11:22:09', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 11:22:09', '2024-10-25 11:19:54'),
(232, 'https://localhost/luna/site/?post_type=acf-field&p=257', '54:3162a67351e3ffe238b663d6880f115a', 257, 'post', 'acf-field', 1, 251, NULL, NULL, 'Contact Form', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:19:54', '2024-10-25 11:22:09', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 11:22:09', '2024-10-25 11:19:54'),
(233, 'https://localhost/luna/site/?post_type=acf-field&p=259', '54:ee35b2ae99c7064d7058607b7727dfa7', 259, 'post', 'acf-field', 1, 251, NULL, NULL, 'Contact Icon', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:22:09', '2024-10-25 11:22:09', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 11:22:09', '2024-10-25 11:22:09'),
(234, 'https://localhost/luna/site/?post_type=acf-field&p=260', '54:92417060fc0ecf02e4319bc5f5cc3a53', 260, 'post', 'acf-field', 1, 251, NULL, NULL, 'Email Icon', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:22:09', '2024-10-25 11:22:09', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 11:22:09', '2024-10-25 11:22:09'),
(235, 'https://localhost/luna/site/?post_type=acf-field-group&p=263', '60:e7bc5d154b64e3a3d27e5da694370320', 263, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Form Shortcode', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:53:39', '2024-10-25 11:53:39', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 11:53:39', '2024-10-25 11:53:38'),
(236, 'https://localhost/luna/site/?post_type=acf-field&p=264', '54:36ba4e9055addef2ae1a4a22879f12c8', 264, 'post', 'acf-field', 1, 263, NULL, NULL, 'Contact Form', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:53:39', '2024-10-25 11:53:39', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 11:53:38', '2024-10-25 11:53:38'),
(238, 'https://localhost/luna/site/?post_type=acf-field&p=267', '54:43df3951be269fa1ad915c07e7697920', 267, 'post', 'acf-field', 1, 269, NULL, NULL, 'Button Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:56:55', '2024-10-25 11:59:47', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 11:59:47', '2024-10-25 11:56:55'),
(239, 'https://localhost/luna/site/?post_type=acf-field&p=268', '54:c56780d62fef32ccb05a0a93cf8a8d8c', 268, 'post', 'acf-field', 1, 269, NULL, NULL, 'Button Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:56:55', '2024-10-25 11:59:47', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 11:59:47', '2024-10-25 11:56:55'),
(240, 'https://localhost/luna/site/?post_type=acf-field-group&p=269', '60:6e5eee3c7eeae4613c715c261553bea6', 269, 'post', 'acf-field-group', 1, 0, NULL, NULL, 'Portfolio Page', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 11:59:04', '2024-10-25 11:59:47', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 11:59:47', '2024-10-25 11:59:04'),
(242, 'https://localhost/luna/site/?post_type=acf-field&p=272', '54:fd2d27ef8edd9f9a348fb27ecd8a9e47', 272, 'post', 'acf-field', 1, 111, NULL, NULL, 'Outfit Detail Page', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 12:04:34', '2024-10-25 12:04:34', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 12:04:34', '2024-10-25 12:04:34'),
(243, 'https://localhost/luna/site/?post_type=acf-field&p=273', '54:1a5c5d89ac38efb127cc5e444e4628ac', 273, 'post', 'acf-field', 1, 111, NULL, NULL, 'Button Title', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 12:04:34', '2024-10-25 12:04:34', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 12:04:34', '2024-10-25 12:04:34'),
(244, 'https://localhost/luna/site/?post_type=acf-field&p=274', '54:43ae763be7898dc2a77928fb8f760e2c', 274, 'post', 'acf-field', 1, 111, NULL, NULL, 'Button Text', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 12:04:34', '2024-10-25 12:04:34', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-10-25 12:04:34', '2024-10-25 12:04:34'),
(245, 'https://localhost/luna/site/?post_type=acf-field&p=275', '54:cb2f25c9900c3df76795ecc2484668bc', 275, 'post', 'acf-field', 1, 111, NULL, NULL, 'Button Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-10-25 12:04:34', '2024-10-25 12:07:38', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-10-25 12:07:38', '2024-10-25 12:04:34'),
(246, 'https://localhost/luna/site/outfit-portfolio/', '45:8ccbb25014dda16bbed4b24ec4d3d544', 281, 'post', 'nav_menu_item', 1, 0, NULL, NULL, 'Outfit Portfolio', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-11-03 06:02:09', '2024-11-06 08:57:34', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2024-11-06 08:57:34', '2024-11-03 06:02:14'),
(247, 'https://localhost/luna/site/?post_type=acf-field&p=285', '54:03a9397ca0034a2bf626d7089962f0b8', 285, 'post', 'acf-field', 1, 119, NULL, NULL, 'Link', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2024-11-04 09:06:48', '2024-11-04 09:06:48', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2024-11-04 09:06:48', '2024-11-04 09:06:48'),
(248, 'https://localhost/luna/site/outfit/vi-rodriguez-new/', '52:ea525728cc32d0d205598fd35b4a2a51', 287, 'post', 'outfit', 1, 0, NULL, NULL, 'Vi Rodriguez new', 'publish', 0, 1, NULL, NULL, NULL, NULL, NULL, 90, 0, 0, 0, 0, 0, 0, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-one.jpg', NULL, '178', 'featured-image', NULL, NULL, 'https://localhost/luna/site/wp-content/uploads/2024/10/detailed-one.jpg', '178', 'featured-image', '{"width":583,"height":1054,"filesize":318208,"url":"https:\\/\\/localhost\\/luna\\/site\\/wp-content\\/uploads\\/2024\\/10\\/detailed-one.jpg","path":"\\\\\\\\\\/wp-content\\/uploads\\/2024\\/10\\/detailed-one.jpg","size":"full","id":178,"alt":"","pixels":614482,"type":"image\\/jpeg"}', 0, NULL, NULL, '2024-11-05 07:35:28', '2024-11-05 07:38:36', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2024-11-05 07:38:35', '2024-11-05 07:35:28') ;

#
# End of data contents of table `wp_yoast_indexable`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable_hierarchy`
#

DROP TABLE IF EXISTS `wp_yoast_indexable_hierarchy`;


#
# Table structure of table `wp_yoast_indexable_hierarchy`
#

CREATE TABLE `wp_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_indexable_hierarchy`
#
INSERT INTO `wp_yoast_indexable_hierarchy` ( `indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES
(2, 0, 0, 1),
(3, 0, 0, 1),
(4, 0, 0, 1),
(5, 0, 0, 1),
(9, 0, 0, 1),
(11, 0, 0, 1),
(14, 0, 0, 1),
(15, 0, 0, 1),
(20, 0, 0, 1),
(28, 0, 0, 1),
(29, 0, 0, 1),
(30, 0, 0, 1),
(31, 0, 0, 1),
(33, 0, 0, 1),
(34, 0, 0, 1),
(35, 0, 0, 1),
(36, 0, 0, 1),
(37, 0, 0, 1),
(39, 0, 0, 1),
(40, 0, 0, 1),
(42, 0, 0, 1),
(43, 0, 0, 1),
(44, 0, 0, 1),
(45, 0, 0, 1),
(46, 0, 0, 1),
(47, 0, 0, 1),
(48, 0, 0, 1),
(49, 0, 0, 1),
(50, 0, 0, 1),
(51, 0, 0, 1),
(52, 0, 0, 1),
(61, 14, 1, 1),
(62, 14, 1, 1),
(75, 14, 1, 1),
(76, 14, 1, 1),
(77, 14, 1, 1),
(81, 52, 1, 1),
(82, 52, 1, 1),
(83, 14, 1, 1),
(84, 14, 1, 1),
(94, 52, 2, 1),
(94, 93, 1, 1),
(95, 52, 2, 1),
(95, 93, 1, 1),
(104, 14, 1, 1),
(105, 14, 1, 1),
(106, 0, 0, 1),
(107, 106, 1, 1),
(108, 15, 1, 1),
(113, 0, 0, 1),
(118, 113, 1, 1),
(123, 0, 0, 1),
(124, 0, 0, 1),
(125, 124, 1, 1),
(126, 124, 1, 1),
(127, 124, 1, 1),
(128, 124, 1, 1),
(129, 124, 1, 1),
(130, 124, 1, 1),
(131, 124, 1, 1),
(132, 124, 1, 1),
(133, 124, 1, 1),
(134, 124, 1, 1),
(136, 124, 1, 1),
(138, 124, 1, 1),
(139, 124, 1, 1),
(145, 124, 1, 1),
(146, 124, 1, 1),
(147, 124, 1, 1),
(148, 124, 1, 1),
(149, 124, 1, 1),
(150, 124, 1, 1),
(151, 124, 1, 1),
(152, 124, 1, 1),
(153, 124, 1, 1),
(154, 124, 1, 1),
(155, 124, 1, 1),
(156, 124, 1, 1),
(157, 124, 1, 1),
(158, 124, 1, 1),
(161, 124, 1, 1),
(162, 124, 1, 1),
(163, 124, 1, 1),
(169, 0, 0, 1),
(170, 0, 0, 1),
(171, 170, 1, 1),
(173, 0, 0, 1),
(180, 170, 1, 1),
(181, 170, 1, 1),
(182, 170, 1, 1),
(183, 173, 1, 1),
(187, 170, 1, 1),
(188, 170, 1, 1),
(189, 170, 1, 1),
(190, 0, 0, 1),
(191, 190, 1, 1),
(192, 0, 0, 1),
(194, 0, 0, 1),
(195, 0, 0, 1),
(196, 0, 0, 1) ;
INSERT INTO `wp_yoast_indexable_hierarchy` ( `indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES
(199, 0, 0, 1),
(203, 0, 0, 1),
(207, 0, 0, 1),
(208, 0, 0, 1),
(209, 0, 0, 1),
(211, 0, 0, 1),
(216, 0, 0, 1),
(217, 106, 1, 1),
(218, 106, 1, 1),
(220, 106, 1, 1),
(221, 106, 1, 1),
(222, 106, 1, 1),
(223, 106, 1, 1),
(224, 106, 1, 1),
(225, 106, 1, 1),
(227, 0, 0, 1),
(230, 227, 1, 1),
(231, 227, 1, 1),
(232, 227, 1, 1),
(235, 0, 0, 1),
(238, 240, 1, 1),
(239, 240, 1, 1),
(240, 0, 0, 1),
(245, 106, 1, 1),
(246, 0, 0, 1),
(248, 0, 0, 1) ;

#
# End of data contents of table `wp_yoast_indexable_hierarchy`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_migrations`
#

DROP TABLE IF EXISTS `wp_yoast_migrations`;


#
# Table structure of table `wp_yoast_migrations`
#

CREATE TABLE `wp_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wp_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_migrations`
#
INSERT INTO `wp_yoast_migrations` ( `id`, `version`) VALUES
(1, '20171228151840'),
(2, '20171228151841'),
(3, '20190529075038'),
(4, '20191011111109'),
(5, '20200408101900'),
(6, '20200420073606'),
(7, '20200428123747'),
(8, '20200428194858'),
(9, '20200429105310'),
(10, '20200430075614'),
(11, '20200430150130'),
(12, '20200507054848'),
(13, '20200513133401'),
(14, '20200609154515'),
(15, '20200616130143'),
(16, '20200617122511'),
(17, '20200702141921'),
(18, '20200728095334'),
(19, '20201202144329'),
(20, '20201216124002'),
(21, '20201216141134'),
(22, '20210817092415'),
(23, '20211020091404') ;

#
# End of data contents of table `wp_yoast_migrations`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_primary_term`
#

DROP TABLE IF EXISTS `wp_yoast_primary_term`;


#
# Table structure of table `wp_yoast_primary_term`
#

CREATE TABLE `wp_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_primary_term`
#

#
# End of data contents of table `wp_yoast_primary_term`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_yoast_seo_links`;


#
# Table structure of table `wp_yoast_seo_links`
#

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;


#
# Data contents of table `wp_yoast_seo_links`
#
INSERT INTO `wp_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`, `indexable_id`, `target_indexable_id`, `height`, `width`, `size`, `language`, `region`) VALUES
(1, 'http://localhost/luna/site/wp-admin/', 2, NULL, 'internal', 3, NULL, NULL, NULL, NULL, NULL, NULL) ;

#
# End of data contents of table `wp_yoast_seo_links`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

